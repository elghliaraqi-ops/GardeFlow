# HUIM6 Planning V9.5

- Autorise les échanges de deux gardes le même jour (ex. Jour ↔ Nuit).
- L’écran d’échange n’exclut plus la date de la garde source.
- La validation Flutter accepte deux gardes distinctes même si elles ont la même date.
- La fonction Supabase `review_shift_request` permute les `shift_id` quand les deux gardes sont le même jour, afin de respecter `unique(owner_phone, date_str)`.
- Les échanges sur des dates différentes conservent le fonctionnement précédent.
- Les transferts restent inchangés.
