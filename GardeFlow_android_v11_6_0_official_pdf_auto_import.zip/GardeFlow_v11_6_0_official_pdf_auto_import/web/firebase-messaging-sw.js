/* GardeFlow — Firebase Cloud Messaging Web background service worker */
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyCdB6aJmUb_iBsrvgZqbcXsuqJEM_lL1I0',
  authDomain: 'planninghm6.firebaseapp.com',
  projectId: 'planninghm6',
  storageBucket: 'planninghm6.firebasestorage.app',
  messagingSenderId: '298887284540',
  appId: '1:298887284540:web:b8689ebd4e96cce6d24039',
  measurementId: 'G-YGY0R9NMW9'
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const data = payload.data || {};
  const title = data.title || 'GardeFlow';
  const options = {
    body: data.body || 'Nouvelle notification',
    icon: '/icons/Icon-192.png',
    badge: '/icons/Icon-192.png',
    data: { url: '/', kind: data.kind || '', resourceId: data.resourceId || '' },
  };
  self.registration.showNotification(title, options);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil((async () => {
    const windows = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of windows) {
      if ('focus' in client) {
        await client.focus();
        return;
      }
    }
    if (clients.openWindow) await clients.openWindow(url);
  })());
});
