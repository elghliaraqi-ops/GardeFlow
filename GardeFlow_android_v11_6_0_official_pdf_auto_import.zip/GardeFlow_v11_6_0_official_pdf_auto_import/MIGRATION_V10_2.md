# Passage V10 / V10.0.1 → V10.2

1. Sauvegarder la base Supabase.
2. Ouvrir **SQL Editor**.
3. Exécuter **une seule fois** `supabase/patch_v10_2_self_validation_tiles_notifications.sql`.
4. Ne pas exécuter `patch_v10_1_tiles_calendar_validation.sql` : V10.2 est cumulatif. Si V10.1 avait déjà été exécuté, V10.2 le corrige automatiquement.
5. Aucun changement Firebase/FCM n'est requis pour cette migration.
6. Relancer :

```powershell
flutter clean
flutter pub get
flutter run -d chrome
```

## Résultat métier

- Le médecin place ses propres tuiles Service/Urgences Jour, Nuit, 24H et Congé.
- Il valide ensuite son mois lui-même ; cette validation est irréversible.
- L'admin ne valide pas le calendrier mensuel.
- L'admin valide les transferts, échanges et congés.
- Seul l'admin peut supprimer une affectation d'un mois validé.
- Junior/Senior ne donne aucun droit ; seul `role='admin'` donne les permissions admin.
- L'écran Notifications propose **Nettoyer** pour retirer les rappels passés et masquer les workflows terminés, sans supprimer l'historique Supabase.
