# GardeFlow V11.4.0 — iPhone / iOS

La logique Flutter est maintenant compatible Android, Web et iOS. Les fonctions métier (planning, tuiles, échanges, transferts, congés, Supabase, astreintes partagées et PDF officiels) sont communes aux trois plateformes.

## Prérequis pour construire une app iPhone

Apple impose la compilation iOS sur **macOS avec Xcode**. Une IPA signée/App Store nécessite aussi un compte Apple Developer.

- Mac récent avec Xcode
- Flutter installé
- CocoaPods installé si Flutter le demande
- iPhone réel ou simulateur Xcode

## 1. Préparer le projet iOS

Sur le Mac, à la racine du projet :

```bash
chmod +x tool/ios.sh BUILD_IOS_UNSIGNED.sh BUILD_IOS_IPA.sh
./tool/ios.sh Prepare
```

Le script crée automatiquement le dossier `ios/` avec le Flutter installé sur le Mac puis applique :

- nom affiché **GardeFlow** ;
- Bundle ID **com.huim6.gardeflow** ;
- iOS minimum **13.0** ;
- nouveau logo GardeFlow comme icône iPhone/iPad ;
- écran de lancement avec le nouveau logo ;
- permissions Appareil photo / Photos ;
- mode background `remote-notification` ;
- privacy manifest pour les préférences locales.

## 2. Firebase iOS pour les notifications push

L'app fonctionne avec Supabase sans Firebase iOS, mais les notifications push sur iPhone nécessitent la configuration suivante.

Dans Firebase, projet `planninghm6` :

1. Ajouter une application **iOS**.
2. Utiliser exactement le Bundle ID :

```text
com.huim6.gardeflow
```

3. Télécharger `GoogleService-Info.plist`.
4. Placer ce fichier **à la racine du projet GardeFlow**, au même niveau que `pubspec.yaml`.
5. Relancer :

```bash
./tool/ios.sh Prepare
```

Le script copie le plist dans Runner et l'intègre aux Resources Xcode.

Pour recevoir les push FCM sur iPhone, il faut aussi configurer APNs dans Firebase : créer une clé APNs dans Apple Developer puis l'ajouter dans Firebase > Project Settings > Cloud Messaging. Ne jamais partager la clé `.p8` ou son contenu.

## 3. Signing & Capabilities dans Xcode

Ouvrir :

```bash
open ios/Runner.xcworkspace
```

Dans **Runner > Signing & Capabilities** :

- choisir votre **Team** Apple ;
- vérifier le Bundle ID `com.huim6.gardeflow` ;
- ajouter **Push Notifications** ;
- ajouter **Background Modes** et cocher **Remote notifications** (et Background fetch si proposé).

Ces capacités dépendent du compte Apple/provisioning et ne peuvent pas être signées automatiquement dans le ZIP.

## 4. Tester sans signature de distribution

```bash
./BUILD_IOS_UNSIGNED.sh
```

Résultat :

```text
build/ios/iphoneos/Runner.app
```

Pour lancer sur un simulateur :

```bash
flutter devices
flutter run -d <id_du_simulateur>
```

## 5. Produire une IPA signée

Après avoir configuré la Team Apple dans Xcode :

```bash
./BUILD_IOS_IPA.sh
```

Résultat :

```text
build/ios/ipa/
```

La distribution TestFlight/App Store se fait ensuite avec Xcode/Transporter selon le profil de signature Apple.

## Notifications iPhone

V11.4.0 ajoute :

- enregistrement FCM avec `platform = ios` dans Supabase ;
- attente du token APNs avant de demander le token FCM ;
- navigation lors d'un tap sur une notification ;
- notifications locales/rappels via Darwin notifications ;
- pas de demande de permission au démarrage : elle apparaît au moment où les notifications sont activées pour l'utilisateur.

Aucune migration Supabase supplémentaire n'est nécessaire pour iOS.
