# Migration V11.3.0

Dans Supabase > SQL Editor, exécuter une seule fois :

`supabase/patch_v11_3_0_shared_astreinte_official_pdfs.sql`

Le patch crée :
- `public.shared_resources` ;
- le bucket privé `gardeflow-shared` ;
- les RLS de lecture pour tous les utilisateurs authentifiés ;
- les RLS d'écriture/suppression réservées aux admins.

Aucune modification de `send-push`, Firebase, VAPID ou `FCM_SERVICE_ACCOUNT_JSON`.
