# HUIM6 Planning V9.8 — Push Notifications

- Firebase Core + Firebase Messaging Web.
- Configuration du projet Firebase `planninghm6` intégrée.
- Clé VAPID publique intégrée.
- Enregistrement sécurisé des tokens FCM par utilisateur dans Supabase.
- Support de plusieurs appareils/navigateurs par médecin.
- Service worker Web pour les notifications en arrière-plan.
- Edge Function Supabase `send-push` avec FCM HTTP v1.
- Push sur transferts, échanges, congés et suppressions administrateur.
- Nettoyage des tokens FCM invalides.
- Aucun secret Firebase privé dans le code Flutter.
