# HUIM6 Planning V9.6

- L'administrateur peut supprimer une garde directement depuis le calendrier d'un médecin.
- La suppression admin fonctionne aussi pour les gardes issues d'un transfert ou d'un échange.
- Si une demande est encore en attente et référence cette garde, elle est automatiquement annulée.
- Les gardes supprimées sont archivées côté PostgreSQL (`deleted_at`) plutôt que détruites physiquement afin de conserver l'historique des transferts/échanges.
- Les gardes archivées ne sont plus chargées dans le planning Flutter.
- Une nouvelle garde peut être recréée pour le même médecin et la même date après suppression.
- Ajout de `supabase/patch_v9_6_admin_delete.sql` pour mettre à jour un projet Supabase V9.5 existant.
