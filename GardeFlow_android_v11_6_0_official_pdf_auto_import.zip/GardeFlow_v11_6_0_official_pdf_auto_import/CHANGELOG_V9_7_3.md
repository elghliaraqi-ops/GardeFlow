# V9.7.3 — Congés regroupés par médecin dans les notifications admin

- Dans l'onglet Congés des Notifications, la vue administrateur regroupe désormais les demandes par médecin.
- Chaque médecin apparaît dans un bloc dépliable avec le nombre total de demandes.
- Les médecins ayant des demandes en attente apparaissent en priorité.
- Le nombre de congés en attente est affiché sur chaque groupe.
- Les demandes en attente sont affichées avant l'historique approuvé/refusé/annulé.
- Les actions Approuver / Refuser restent disponibles demande par demande.
- La vue d'un médecin non administrateur reste inchangée.
- Aucun changement de schéma Supabase n'est nécessaire.
