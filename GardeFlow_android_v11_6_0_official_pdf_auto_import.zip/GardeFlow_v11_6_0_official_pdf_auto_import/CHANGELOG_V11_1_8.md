# GardeFlow V11.1.8

## Lisibilité des calendriers

- Refonte des cellules du calendrier personnel et de la Vue Admin.
- Le numéro du jour et les boutons d’action disposent désormais d’une ligne dédiée au-dessus de la tuile : ils ne recouvrent plus le contenu de la garde.
- La tuile de garde remplit tout l’espace restant de la case.
- Bouton de retrait (croix) plus visible dans le calendrier personnel.
- Bouton d’échange plus visible sur les calendriers validés.
- Bouton de suppression admin plus visible dans la Vue Admin.
- Libellés Service / Urgences / Jour / Nuit / 24H / Congé agrandis et adaptatifs.
- Sur très petites cases, l’icône est masquée en priorité afin de conserver un texte lisible.
- Hauteur des cases du calendrier Admin augmentée sur les écrans étroits.

Aucun changement Supabase, Firebase ou Edge Function.
