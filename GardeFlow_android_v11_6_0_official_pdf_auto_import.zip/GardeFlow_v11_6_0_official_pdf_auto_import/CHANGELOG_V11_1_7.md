# GardeFlow V11.1.7

## Vue Admin — calendrier entièrement visible

- Suppression du défilement horizontal du calendrier médecin dans la Vue Admin.
- Les 7 colonnes du mois sont toujours affichées simultanément, y compris sur Android portrait.
- Taille des cellules, espacements, libellés et icônes s’adaptent automatiquement à la largeur disponible.
- Sur très petit écran, les libellés sont abrégés intelligemment (S/U, J/N/24H) pour conserver la lisibilité sans casser la grille.
- Le bouton de suppression reste indépendant de la cellule pour éviter une suppression accidentelle au simple toucher du jour.
- Aucun changement Supabase ni Edge Function requis.
