# Correctif Android V11.3.1

Erreur corrigée :

```text
Execution failed for task ':file_picker:checkReleaseAarMetadata'
flutter_plugin_android_lifecycle requires compileSdk 36
:file_picker is currently compiled against android-34
```

Corrections :
- `file_picker` passe de `8.1.7` à `10.3.8`.
- le projet Android généré compile explicitement avec `compileSdk 36`.
- le script Android lance `flutter clean` avant `flutter pub get` et la compilation.

Aucune modification Supabase, Firebase ou métier.

## Compiler

```powershell
powershell -ExecutionPolicy Bypass -File .\BUILD_APK_RELEASE.ps1
```

Si Android SDK Platform 36 n'est pas installé, l'installer depuis Android Studio
> SDK Manager > SDK Platforms > Android API 36.
