# V11 — Refonte visuelle complète

Refonte du graphisme de toutes les pages. **Aucune fonctionnalité, règle métier,
appel Supabase ou comportement de drag-and-drop n'a été modifié.**

## 1. Système de design (`lib/theme/`)

### `app_theme.dart` — réécrit
- **Palette** : neutres repensés (fond `#F5F5F2`, encre froide `#13161A`,
  hairlines `#E3E1DA`). La grammaire métier des couleurs est **inchangée** :
  teinte = catégorie (bleu Service / rouge Urgences), luminosité = moment
  (jour / 24h / nuit), vert = Congé.
- **Échelles** : `AppSpace` (4→40, multiples de 4), `AppRadius` (10/16/22/28/pill),
  `AppShadow` (low/mid/high). Fini les 7 rayons arbitraires de l'ancienne version.
- **Typographie** : deux polices bundlées sous licence OFL —
  Space Grotesk (titres/chiffres) et Inter (texte). Échelle complète display →
  label appliquée via le `TextTheme`.
- **Composants** : thème global pour boutons, champs, dialogues, bottom sheets,
  snackbars, switches, chips, onglets. Les écrans n'ont donc plus besoin de
  restyler chaque widget à la main.

### `widgets.dart` — nouveau
Kit partagé : `AppCard`, `SoftIconButton`, `Pill`, `SectionLabel`.

## 2. Écran principal — reconstruit

**Le calendrier est désormais toujours visible en entier, sans défilement.**

Avant, six blocs à hauteur fixe s'empilaient au-dessus de la grille et
l'écrasaient. Maintenant :
- La salutation, le statut du jour et le badge de notifications tiennent sur
  **une seule ligne** de 44 px.
- Les quatre grandes cartes de navigation sont devenues des **puces compactes**
  de 40 px, défilables horizontalement — mêmes destinations.
- Le titre du mois, le statut de validation et le bouton « Valider » partagent
  **une seule ligne**. Le détail du statut passe dans un bottom sheet au tap.
- La grille occupe tout l'espace restant (`Expanded`) et calcule son ratio de
  cellule d'après la hauteur réelle disponible.

**Drag-and-drop : comportement identique.** Mêmes `Draggable<String>`, mêmes
`data: shift.id`, même `maxSimultaneousDrags`, même `DragTarget` avec
`onWillAcceptWithDetails` / `onAcceptWithDetails`, mêmes callbacks
`placeShift` / `removeShift`. Seul l'habillage change : la tuile soulevée
s'agrandit légèrement (1.06) et prend une ombre portée.

## 3. Autres écrans

| Écran | Changements |
|---|---|
| Authentification | Formulaire en carte, transition animée connexion ↔ inscription, bannières d'erreur/succès avec icône |
| Splash | Aligné sur la nouvelle typographie et les rayons |
| Réglages | Sections en cartes, avatar, déconnexion en bouton dédié |
| Annuaire | Contacts en cartes cliquables, bouton d'appel proéminent, barre de catégories en pilules |
| Astreinte | Grille et tuile d'ajout modernisées |
| Journal d'audit | Lignes en cartes avec pastille d'icône, métadonnées hiérarchisées |
| Notifications | Trois onglets en cartes, états vides illustrés, pastilles de statut unifiées |
| Transfert / échange | Garde rappelée dans une pastille colorée, erreurs avec icône |
| Vue Admin | Compteurs en cartes chiffre-d'abord, fiche médecin en carte, cellules alignées sur l'écran principal |

## 4. Détails de rédaction
- Libellés passés de `TOUT EN MAJUSCULES` à la casse normale (`SERVICE` → `Service`).
- Émojis ✅ retirés des pastilles de statut — la couleur porte déjà l'information.

## 5. À faire de votre côté

```bash
flutter pub get   # enregistre les polices ajoutées dans pubspec.yaml
flutter run
```

> Le SDK Flutter n'était pas disponible dans l'environnement de travail : le code
> n'a **pas** été compilé. Un `flutter analyze` est recommandé avant publication.

Polices ajoutées dans `assets/fonts/` (Space Grotesk + Inter, OFL 1.1,
attribution dans `assets/fonts/LICENSE_OFL.txt`).
