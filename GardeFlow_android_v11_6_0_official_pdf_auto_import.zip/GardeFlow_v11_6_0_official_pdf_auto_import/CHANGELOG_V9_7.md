# HUIM6 Planning V9.7

- Les congés ne sont plus créés directement dans le planning.
- Un congé déposé par un médecin crée une demande `pendingAdmin`.
- Le calendrier personnel affiche `Congé · en attente` jusqu'à la décision.
- Nouvel onglet `Congés` dans Notifications.
- L'administrateur voit toutes les demandes de congé et peut les approuver ou les refuser.
- Après approbation, Supabase crée automatiquement l'entrée `conge` dans le planning.
- Après refus, aucun congé validé n'est ajouté au planning.
- Le médecin peut annuler sa demande tant qu'elle est encore en attente.
- L'administrateur peut supprimer un congé approuvé depuis la vue calendrier médecin.
- La suppression conserve l'historique de la demande de congé en statut annulé.
- Le badge de notifications admin inclut les demandes de congé en attente.
- Les congés sont exclus des gardes proposées comme contrepartie d'un échange.
- Le patch V9.7 est cumulatif : il inclut aussi la suppression admin de toutes les gardes introduite en V9.6.
