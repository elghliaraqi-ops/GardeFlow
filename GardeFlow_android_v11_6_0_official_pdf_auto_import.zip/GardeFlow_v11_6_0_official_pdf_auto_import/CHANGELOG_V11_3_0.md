# GardeFlow V11.3.0

## Astreintes partagées via Supabase
- Les photos ne sont plus propres à un téléphone/compte local.
- Elles sont stockées dans le bucket privé Supabase `gardeflow-shared`.
- Tous les utilisateurs connectés voient la même galerie.
- Seul un utilisateur dont `profiles.role = 'admin'` peut ajouter ou supprimer une photo.
- La règle est imposée par les policies RLS de Supabase Storage et de `shared_resources`.

## Planning de Garde Officiel
- Nouveau bouton visible par tous dans la barre supérieure.
- Trois emplacements PDF fixes :
  - HM6 Bouskoura
  - HM6 Rabat
  - HCK Casa
- Tous les utilisateurs peuvent consulter le dernier PDF publié.
- Seul l'admin peut publier, remplacer ou retirer un PDF.
- Taille maximale prévue : 25 Mo par fichier.

## Migration
Exécuter une fois `supabase/patch_v11_3_0_shared_astreinte_official_pdfs.sql`.
Aucune mise à jour de `send-push` ou Firebase n'est nécessaire.
