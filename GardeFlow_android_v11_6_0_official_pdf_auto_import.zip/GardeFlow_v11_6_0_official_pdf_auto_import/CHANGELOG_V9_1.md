# HUIM6 Planning V9.1

- Interface inchangée : numéro de téléphone + mot de passe.
- Plus de dépendance au provider Phone de Supabase.
- Aucun OTP requis.
- Aucun SMS Provider requis.
- Supabase Auth utilise Email/Password avec une adresse technique interne dérivée du téléphone.
- Le vrai téléphone normalisé reste stocké dans `profiles.phone`.
- Les règles RLS, Realtime, transferts, échanges et calendrier admin restent inchangés.
- Message explicite si `Confirm email` est encore activé dans Supabase.
- Documentation Supabase mise à jour.
- Limite documentée : pas de récupération automatique de mot de passe sans canal réel.

## V9.3 correction identifiant technique
- Le domaine technique n'est plus codé en dur (`auth.huim6.app`).
- Il est dérivé automatiquement du vrai `SUPABASE_URL` du projet.
- Exemple : `0707099802` -> `212707099802@bqmtkdzlqfvfocxlffac.supabase.co`.
- Toujours aucun OTP, aucun SMS Provider et aucun email affiché à l'utilisateur.
