# GardeFlow V11.5.1

## Juniors d’astreinte — vue hebdomadaire par service

- La page « Juniors d’astreinte » est maintenant centrée sur la semaine.
- Navigation semaine précédente / suivante et retour rapide à la semaine actuelle.
- Regroupement principal par service.
- Dans chaque service : regroupement par établissement, puis par date.
- Affichage du nom du Junior et du type de garde de service (Jour / 24H / Nuit).
- Filtre établissement : Tous / HUIM6 de Bouskoura / HUIM6 de Rabat / HUICK de Casa.
- Seuls les plannings validés restent visibles.
- Aucun changement de schéma Supabase : le RPC V11.5.0 est réutilisé avec une plage hebdomadaire.
