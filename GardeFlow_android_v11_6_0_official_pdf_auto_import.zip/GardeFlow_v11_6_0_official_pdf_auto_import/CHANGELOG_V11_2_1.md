# GardeFlow V11.2.1 — nouveau logo partout

- Nouveau logo GardeFlow adopté comme identité visuelle principale.
- Remplacement du logo dans le splash screen et l'écran de connexion via `assets/branding/gardeflow_logo.png`.
- Remplacement de l'icône Android du launcher pour toutes les densités (`mdpi` à `xxxhdpi`).
- Remplacement de l'icône Android adaptative et de sa ressource source utilisée après régénération du dossier Android.
- Remplacement du favicon Web, des icônes PWA 192/512, des icônes maskables et de l'icône Apple Touch.
- Mise à jour du cache-busting favicon Web.
- Aucune modification Supabase, Firebase ou métier.
