# HUIM6 Planning V10.2 — tuiles, verrouillage définitif et notifications

## Concept de planning

- Retour complet au système de tuiles sur le calendrier personnel.
- **SERVICE** : Jour / 24H / Nuit.
- **URGENCES** : Jour / 24H / Nuit.
- **Congé** comme tuile distincte avec son code couleur.
- Avant validation, le médecin peut placer, remplacer ou retirer ses propres tuiles.
- Le médecin valide ensuite lui-même le mois avec confirmation explicite.
- Cette validation est **irréversible** : aucun retour en brouillon et aucune modification directe après validation.
- Après validation, les gardes peuvent évoluer uniquement via transfert/échange ou suppression administrative.

## Rôle de l'administrateur

- Suppression de la validation du calendrier complet par l'admin.
- La vue admin du calendrier devient en lecture seule.
- L'admin valide les **transferts**, **échanges** et **congés**.
- Seul l'admin peut supprimer une garde/congé déjà validé, avec motif obligatoire et audit.
- Un admin participant à sa propre demande ne peut toujours pas être son propre validateur.

## Congés

- Les tuiles Congé sont placées librement tant que le mois est en préparation.
- À la validation définitive du mois, les jours de Congé contigus deviennent automatiquement une demande de congé.
- Jusqu'à décision admin, le propriétaire et les admins voient `Congé · attente`.
- Les autres médecins ne voient le congé qu'après approbation.
- En cas de refus, seules les tuiles Congé concernées sont retirées ; le calendrier reste verrouillé.

## Junior / Senior / Admin

- **Junior** et **Senior** sont des grades médicaux purement informatifs.
- Aucun droit n'est dérivé du grade.
- Les permissions viennent exclusivement de `profiles.role`.
- Un médecin **Junior + Admin** possède tous les droits administratifs, exactement comme un Senior + Admin.

## Notifications

- Bouton **Nettoyer** visible dans l'écran Notifications.
- Suppression locale des rappels passés/envoyés.
- Masquage, pour le compte courant, des transferts/échanges/congés déjà terminés.
- Les demandes encore en attente ne sont jamais supprimées par ce nettoyage.
- L'historique métier Supabase reste intact.

## Supabase

Depuis une base V10, exécuter uniquement :

`supabase/patch_v10_2_self_validation_tiles_notifications.sql`

Le patch est cumulatif et remplace le workflow V10.1 s'il avait déjà été installé.
