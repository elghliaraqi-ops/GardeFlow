# HUIM6 Planning V8

- Séparation métier entre transfert d'une garde et échange de deux gardes.
- Sélecteur Transfert / Échange depuis une garde du calendrier.
- Pour un échange : sélection du médecin puis de sa garde précise.
- Acceptation/refus par le destinataire avant intervention de l'admin.
- Validation/rejet final par l'admin.
- L'admin voit transferts et échanges dans Notifications > Transferts / Échanges.
- Verrouillage des gardes impliquées dans une demande active.
- Contrôles de conflits répétés à la création, à l'acceptation et à la validation.
- Transfert : changement de propriétaire d'une seule garde.
- Échange : permutation atomique des propriétaires des deux gardes.
- Rappels reprogrammés pour les nouveaux propriétaires après validation.
- Compatibilité de lecture des anciennes demandes V7 : elles sont migrées comme transferts.
