# Correctif compilation Android V11.1.7.1

L'archive V11.1.7 contenait uniquement `android/app/google-services.json` et pas un projet Android Flutter complet.
Lancer `flutter build apk --release` directement pouvait donc provoquer :

`Build failed due to use of deleted Android v1 embedding.`

Cette correction ne change aucune logique de l'application.

## Compilation

Depuis PowerShell à la racine du projet :

```powershell
powershell -ExecutionPolicy Bypass -File .\BUILD_APK_RELEASE.ps1
```

Le script :
1. détecte le dossier Android incomplet ;
2. le régénère avec le Flutter installé sur le PC (embedding v2) ;
3. remet `google-services.json` ;
4. applique la configuration Firebase/notifications ;
5. exécute `flutter pub get` ;
6. compile `app-release.apk`.

Résultat :
`build\app\outputs\flutter-apk\app-release.apk`
