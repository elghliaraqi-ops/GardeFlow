# GardeFlow V11.1.5 — démarrer sur Android

Le fichier Firebase Android fourni a été vérifié et intégré à la racine et dans
`android/app/google-services.json` : projet `planninghm6`, package
`com.huim6.huim6_planning`. La première étape est déjà terminée : passer à
**2. Préparer Android sous Windows**. Le redéploiement de la fonction Supabase
et un test réel sur téléphone restent nécessaires.
Aucun APK n'a été compilé dans cet environnement : Flutter, le SDK Android et un
appareil Android n'y sont pas disponibles.

## Mise à jour du nom : GardeFlow

Le nom sous l'icône Android, le splash et l'écran de connexion deviennent
**GardeFlow**. Le script applique aussi le nouveau nom à un dossier Android déjà
généré. Le package `com.huim6.huim6_planning` et la configuration Firebase sont
conservés pour permettre la mise à jour de l'application existante.

Recompiler avec `tool/android.ps1 -Action Apk` sur le même PC puis installer
le nouvel APK par-dessus l'ancien. Ne pas désinstaller pour changer le nom.
Le nouvel APK doit être signé avec la même clé que l'ancien ; la version est
maintenant `11.1.5+116`. La recompilation n'a pas été exécutée ici.

## 1. Fichier Firebase Android — déjà intégré

Dans https://console.firebase.google.com/ ouvrir le projet **planninghm6** :

1. Paramètres du projet → Général → Vos applications → Ajouter une application → Android.
2. Nom du package : **`com.huim6.huim6_planning`**. Il doit être identique, caractère par caractère.
3. Nom d'application facultatif : GardeFlow. SHA-1 n'est pas requis pour FCM seul.
4. Télécharger **google-services.json** et le placer dans ce dossier, à côté de `pubspec.yaml`.

Le fichier Android est différent de la configuration Firebase Web déjà intégrée.
Il ne s'agit PAS de la clé privée d'un compte de service. Ne jamais mettre une
clé privée de compte de service dans l'application ou dans ce dossier.
Si l'application Android possède déjà un autre package enregistré ou publié,
conserver cet identifiant et adapter le générateur avant de continuer.

## 2. Préparer Android sous Windows

Installer Flutter et Android Studio avec le SDK Android. Utiliser une version
Flutter stable récente compatible avec les dépendances de ce projet.
Ouvrir PowerShell dans le dossier décompressé :

```powershell
flutter doctor -v
flutter doctor --android-licenses
powershell -ExecutionPolicy Bypass -File .\tool\android.ps1 -Action Prepare
```

La commande génère le dossier Android natif avec le Flutter installé, configure
Google Services, le minimum Android 23, le desugaring, les permissions Internet,
notifications et redémarrage, l'icône de notification et les récepteurs de rappels.
Elle conserve les versions Gradle/Android Gradle Plugin choisies par Flutter.
Elle peut être relancée. Ne pas utiliser l'ancien `configure_native.ps1` pour
cette procédure. Les sources Flutter et le Web sont conservés.

## 3. Lancer sur le téléphone

Activer les options développeur et le débogage USB sur le téléphone, brancher le
câble, puis accepter l'autorisation de débogage sur l'écran du téléphone.

```powershell
flutter devices
powershell -ExecutionPolicy Bypass -File .\tool\android.ps1 -Action Run -Device IDENTIFIANT_ANDROID
```

Remplacer `IDENTIFIANT_ANDROID` par celui affiché par `flutter devices`.
Utiliser un téléphone avec Google Play Services ou un émulateur Google Play.
Se connecter avec un compte actif. Accepter les notifications Android.
Dans Paramètres, vérifier « Notifications push activées sur cet appareil ».
Ce statut confirme l'inscription de l'appareil auprès de Supabase, pas encore
un envoi réel du serveur. Le bouton « Activer / réessayer » permet une nouvelle tentative.

## 4. Activer les envois Supabase — indispensable

Le projet Supabase configuré dans cette archive est `bqmtkdzlqfvfocxlffac`.
Les migrations métier V10/V10.2/V10.3 doivent déjà être appliquées comme dans
l'application actuelle. Cette mise à jour Android ne nécessite pas de nouveau
schéma si votre base V11 fonctionne déjà. Ne pas réexécuter `schema.sql` sur une
base existante pour activer Android.

Vérification non destructive dans le SQL Editor :

```sql
select column_name from information_schema.columns
where table_schema = 'public' and table_name = 'push_tokens'
order by ordinal_position;
-- Les colonnes owner_id, owner_phone, token et platform doivent être présentes.

select platform, count(*) as appareils
from public.push_tokens group by platform;
-- Après activation sur le téléphone, une ligne platform = android doit apparaître.
```

Dans Supabase → Edge Functions → Secrets, le secret **FCM_SERVICE_ACCOUNT_JSON**
doit contenir le JSON du compte de service Firebase **planninghm6**. S'il est déjà
configuré et que les push Web fonctionnent, le garder. Sinon, le créer dans la
console Supabase avec le JSON obtenu dans Firebase → Paramètres du projet →
Comptes de service. La clé reste exclusivement sur le serveur. Vérifier également
que l'API Firebase Cloud Messaging HTTP v1 est activée sur ce projet Google Cloud.

Redéployer **la version modifiée** de `supabase/functions/send-push/index.ts`, soit
avec l'éditeur Supabase, soit avec la CLI Supabase installée :

```powershell
supabase login
supabase functions deploy send-push --project-ref bqmtkdzlqfvfocxlffac
```

La fonction contrôle toujours la session, le rôle et les destinataires à partir
de la base. Les secrets FCM et service_role restent sur Supabase. Le code local
n'a effectué aucune modification de votre serveur distant.

## 5. Vérifier les push de bout en bout

Utiliser deux comptes actifs distincts (médecin A et médecin B ; administrateur
pour les congés). L'émetteur n'est volontairement pas son propre destinataire.

| Test | Résultat attendu |
| --- | --- |
| A envoie une demande d'échange à B, application de B ouverte | Notification Android visible ; toucher ouvre les échanges |
| Même scénario avec B en arrière-plan ou téléphone verrouillé | Notification système visible, sans doublon |
| Application de B retirée des applications récentes | Réception puis toucher : splash, restauration de session, écran des échanges |
| Demande de congé envoyée à l'administrateur | Notification et ouverture de l'onglet Congés |
| Refus de la permission Android | Statut explicite ; activer dans les réglages Android puis réessayer |
| Déconnexion de B ou désactivation des notifications | Désinscription du token et invalidation FCM ; vérifier qu'aucun nouveau push n'arrive après succès |
| Rappel local programmé, puis redémarrage du téléphone | Rappel conservé par les récepteurs Android ; horaire approximatif selon Android |

« Forcer l'arrêt » dans les réglages Android bloque les notifications jusqu'à
la réouverture de l'application. Cela diffère de retirer l'application des
applications récentes. Certains constructeurs imposent aussi des restrictions
d'arrière-plan. Les rappels horaires locaux utilisent les alarmes inexactes
existantes : cette mise à jour ne promet pas une livraison à la seconde.

Si rien n'arrive : vérifier la permission et le canal « Échanges et congés », la
connexion réseau, l'inscription `platform=android`, le secret, le projet Firebase
et les journaux `send-push`. La réponse serveur indique `sent`, `failed` et
`devices` quand des appareils sont ciblés. Une acceptation par FCM ne garantit
pas l'affichage effectif sur un téléphone hors ligne ou bloqué par Android.
Les envois métier restent déclenchés par le client après validation des opérations,
comme dans la version d'origine ; il n'y a pas de file transactionnelle de reprise.

## 6. Générer un APK installable pour tester

```powershell
powershell -ExecutionPolicy Bypass -File .\tool\android.ps1 -Action Apk
```

Résultat : **`build/app/outputs/flutter-apk/app-debug.apk`**.
Il est signé avec la clé de debug de ce PC et prévu pour les tests, pas pour le
Play Store. Pour installer directement par USB :

```powershell
adb install -r build\app\outputs\flutter-apk\app-debug.apk
```

Pour publier sur le Play Store, il faudra configurer votre clé de signature de
production, puis générer un AAB avec `flutter build appbundle --release` et
compléter la fiche Play Console. Le squelette Flutter utilise normalement une
signature de debug par défaut pour release : la remplacer avant distribution.
Aucune publication Play Store ni création de clé de signature n'a été effectuée.

## Validation effectuée et limites

- 5 tests Node exécutés avec succès sur le vrai code TypeScript : payload Android,
  absence de double affichage Web, remontée d'erreur FCM, rejet sans authentification
  et rejet d'un payload libre ne contenant pas d'événement métier valide.
- Ressources XML vérifiées ; modifications relues et archive contrôlée.
- Non exécutés : `flutter pub get`, analyse Dart, scripts Dart/PowerShell, Gradle,
  compilation APK, tests sur téléphone et déploiement Supabase, faute d'environnement
  Android et de configuration Firebase native. Les cinq tests ne remplacent pas ces étapes.

Sur votre PC après préparation :

```powershell
flutter analyze
# Facultatif si Node >= 22.13 est installé :
node --test test/push_payload_test.mjs
```

Références officielles :
- https://firebase.google.com/docs/android/setup
- https://firebase.google.com/docs/cloud-messaging/flutter/receive-messages
- https://pub.dev/packages/flutter_local_notifications/versions/17.2.4
- https://docs.flutter.dev/deployment/android


## Logo GardeFlow — Android, Web et démarrage

Le logo approuvé est inclus dans `assets/branding/gardeflow_logo.png`.
Les icônes Android standard et adaptatives sont exportées et le script Android
les recopie après la génération du squelette Flutter. Le nom GardeFlow apparaît
sur le splash, la connexion, l'accueil et dans les barres de titre des écrans.
Les libellés des sections restent visibles sous le nom de l'application.

### Android

Recompiler sur le même PC, puis installer le nouvel APK par-dessus l'ancien :

```powershell
powershell -ExecutionPolicy Bypass -File .\tool\android.ps1 -Action Apk
```

### Web

Le dossier `web/` comprend maintenant `index.html`, `manifest.json`, le favicon,
les icônes 192/512 px et l'icône Apple Touch. Le titre de l'onglet et le nom de
l'application installée sont GardeFlow. Le service worker FCM conserve son fichier.

```powershell
flutter pub get
flutter run -d chrome
# Pour produire la version à héberger :
flutter build web --release
```

Déployer ensuite le contenu généré dans `build/web` sur l'hébergement actuel.
Si une ancienne icône reste affichée, actualiser le navigateur sans cache ;
une application Web déjà installée peut nécessiter de retirer son raccourci
puis de l'ajouter à nouveau. Aucune mise en ligne n'a été effectuée ici.

Vérifications effectuées : formats/dimensions des PNG, ressources XML Android,
manifest Web et références aux fichiers. La compilation Flutter et le rendu
sur appareil restent à vérifier sur votre poste, sans SDK Flutter ici.

## V11.6.0 — étape Supabase supplémentaire

Avant le premier lancement de V11.6.0, exécuter `PATCH_SUPABASE_V11_6_0_OFFICIAL_PDF_AUTO_IMPORT.sql` dans Supabase > SQL Editor. Ensuite, ouvrir **Planning de Garde Officiel** avec un compte administrateur : les PDF déjà présents seront transposés automatiquement une seule fois.
