#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./tool/ios.sh Ipa
