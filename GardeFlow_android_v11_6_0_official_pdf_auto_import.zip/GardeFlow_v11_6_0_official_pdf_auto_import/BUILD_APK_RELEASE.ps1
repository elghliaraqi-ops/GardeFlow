$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

Write-Host '=== GardeFlow - compilation APK RELEASE ===' -ForegroundColor Cyan
powershell -ExecutionPolicy Bypass -File ".\tool\android.ps1" -Action Apk

if (Test-Path ".\build\app\outputs\flutter-apk\app-release.apk") {
  Write-Host ''
  Write-Host 'Compilation reussie.' -ForegroundColor Green
  Write-Host 'APK : build\app\outputs\flutter-apk\app-release.apk' -ForegroundColor Green
} else {
  throw 'La compilation s est terminee sans produire app-release.apk.'
}
