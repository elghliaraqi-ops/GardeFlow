# HUIM6 Planning V10.3

## Dévalidation administrateur
- Un administrateur peut dévalider et rouvrir le calendrier validé d’un autre médecin, qu’il soit Junior ou Senior.
- Junior/Senior reste un grade purement médical : les droits viennent uniquement de `profiles.role = admin`.
- Un administrateur ne peut pas dévalider son propre calendrier ; un autre administrateur doit le faire.
- Motif de dévalidation obligatoire et journalisation dans `audit_log`.
- Le médecin retrouve immédiatement son calendrier en brouillon et doit le valider de nouveau après correction.
- Les transferts/échanges encore actifs sur le mois sont annulés lors de la réouverture.
- Les congés encore en attente sont annulés et seront recréés lors de la prochaine validation.
- Un congé déjà approuvé reste protégé et ne peut être retiré que par un administrateur.

## Design des tuiles
- Les tuiles placées occupent désormais presque toute la case du calendrier.
- Jour / Nuit / 24H sont plus lisibles avec catégorie SERVICE ou URGENCES clairement visible.
- Les couleurs existantes sont conservées et les cartes ont davantage de relief, des coins plus doux et des boutons d’action plus grands.
- Les tuiles à glisser en bas du planning sont agrandies, ainsi que la tuile Congé.
- La vue Admin utilise le même langage visuel pour les gardes.

## Supabase
Exécuter uniquement `supabase/patch_v10_3_admin_reopen_and_tile_ui.sql` après la V10.2.
Aucune mise à jour de la Edge Function `send-push` n’est nécessaire.

### Ajustement visuel final
- Les tuiles posées utilisent désormais presque tout l’espace disponible de la case (marge interne réduite à 2 px).
- Icônes et libellés agrandis, contraste renforcé et bord clair pour une lecture plus nette.
- Les tuiles de la palette du bas et la tuile Congé ont également été agrandies.
