import '../widgets/month_navigation.dart';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/app_user.dart';
import '../models/leave_request.dart';
import '../models/planning_entry.dart';
import '../models/planning_month.dart';
import '../models/shift_type.dart';
import '../state/app_state.dart';
import '../services/push_notification_service.dart';
import '../theme/app_theme.dart';
import '../theme/widgets.dart';
import 'admin_screen.dart';
import 'astreinte_screen.dart';
import 'directory_screen.dart';
import 'exchange_request_sheet.dart';
import 'junior_oncall_screen.dart';
import 'notifications_screen.dart';
import 'official_planning_screen.dart';
import 'settings_screen.dart';

/// ---------------------------------------------------------------------
/// Écran principal.
///
/// Contrainte de layout volontaire : chaque bloc au-dessus et en dessous
/// du calendrier a une hauteur bornée et compacte, et le calendrier prend
/// tout l'espace restant (`Expanded`). Résultat : le mois complet reste
/// toujours entièrement visible, sans le moindre défilement de page, quel
/// que soit le nombre de semaines du mois, la taille de l'écran ou l'échelle
/// de police système. Sur un écran très petit ou une police très agrandie,
/// les cellules se compriment plutôt que de faire défiler la page.
/// ---------------------------------------------------------------------
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final me = appState.currentUser;
    if (me != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted && appState.currentUser != null) {
          PushNotificationService.instance.navigationReady(isAdmin: appState.currentUser!.role == UserRole.admin);
        }
      });
    }
    return Scaffold(
      backgroundColor: AppColors.paper,
      body: SafeArea(
        child: Column(
          children: [
            if (me != null) _TopBar(appState: appState, user: me),
            _MonthBar(appState: appState),
            const _WeekdaysRow(),
            const SizedBox(height: 2),
            const Expanded(child: _CalendarGrid()),
            _ShiftTray(enabled: appState.canEditMyPlanningMonth(appState.visibleMonth)),
          ],
        ),
      ),
    );
  }
}

// =======================================================================
// BARRE SUPÉRIEURE — identité, statut du jour, accès rapides.
// =======================================================================

class _TopBar extends StatefulWidget {
  final AppState appState;
  final AppUser user;
  const _TopBar({required this.appState, required this.user});

  @override
  State<_TopBar> createState() => _TopBarState();
}

class _TopBarState extends State<_TopBar> {
  late DateTime _now;
  Timer? _clockTimer;

  @override
  void initState() {
    super.initState();
    _now = DateTime.now();
    _clockTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (!mounted) return;
      final now = DateTime.now();
      if (now.minute != _now.minute || now.day != _now.day || now.hour != _now.hour) {
        setState(() => _now = now);
      }
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hour = _now.hour;
    final greeting = hour >= 5 && hour < 18 ? 'Bonjour' : 'Bonsoir';
    final entry = widget.appState.myEntryForDate(AppState.dateKey(_now));
    final status = _statusFor(entry, widget.appState);
    final isAdmin = widget.user.role == UserRole.admin;
    final badge = widget.appState.totalBadgeCount;

    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.sm, AppSpace.lg, AppSpace.xs),
      child: Column(
        children: [
          Row(
            children: [
              const GardeFlowLogo(size: 44),
              const SizedBox(width: AppSpace.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('GardeFlow',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w700)),
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            '$greeting Dr ${widget.user.nom}',
                            style: Theme.of(context).textTheme.titleMedium,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (isAdmin) ...[
                          const SizedBox(width: 6),
                          const Pill(text: 'ADMIN', background: AppColors.ink, foreground: Colors.white, fontSize: 9),
                        ],
                      ],
                    ),
                    const SizedBox(height: 1),
                    Text(
                      status.title,
                      style: Theme.of(context).textTheme.bodySmall,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: AppSpace.sm),
              _BellButton(
                badge: badge,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
              ),
            ],
          ),
          const SizedBox(height: AppSpace.sm),
          _NavRail(isAdmin: isAdmin),
        ],
      ),
    );
  }

  _TodayStatus _statusFor(PlanningEntry? entry, AppState appState) {
    if (entry == null) {
      return const _TodayStatus(
        title: 'Rien de prévu aujourd’hui',
        icon: Icons.event_available_rounded,
        background: AppColors.paperAlt,
        foreground: AppColors.ink,
      );
    }
    final shift = ShiftCatalog.byId(entry.shiftId);
    if (shift.id == 'conge') {
      final leave = appState.leaveRequestForEntry(entry);
      final pending = leave?.status == LeaveRequestStatus.pendingAdmin;
      return _TodayStatus(
        title: pending ? 'Congé en attente de validation' : 'Vous êtes en congé aujourd’hui',
        icon: pending ? Icons.hourglass_top_rounded : Icons.beach_access_rounded,
        background: shift.color,
        foreground: shift.textColor,
      );
    }
    final isUrgence = shift.id.startsWith('urg-');
    final location = isUrgence ? 'Urgences' : 'Service';
    final schedule = shift.start == null ? '' : ' · ${shift.start} → ${shift.end}';
    return _TodayStatus(
      title: '$location · ${shift.label}$schedule',
      icon: shift.icon,
      background: shift.color,
      foreground: shift.textColor,
    );
  }
}

class _TodayStatus {
  final String title;
  final IconData icon;
  final Color background;
  final Color foreground;
  const _TodayStatus({required this.title, required this.icon, required this.background, required this.foreground});
}

class _BellButton extends StatelessWidget {
  final int badge;
  final VoidCallback onTap;
  const _BellButton({required this.badge, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        SoftIconButton(icon: Icons.notifications_rounded, onTap: onTap, tooltip: 'Notifications'),
        if (badge > 0)
          Positioned(
            top: -3,
            right: -3,
            child: Container(
              constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                color: AppColors.urgNuit,
                borderRadius: AppRadius.pillR,
                border: Border.all(color: AppColors.paper, width: 2),
              ),
              child: Text(
                badge > 99 ? '99+' : '$badge',
                style: const TextStyle(color: Colors.white, fontSize: 8.5, fontWeight: FontWeight.w900),
              ),
            ),
          ),
      ],
    );
  }
}

/// Rangée d'accès rapides — remplace les grandes cartes d'origine par des
/// puces compactes icône + libellé, pour libérer de la hauteur au profit
/// du calendrier tout en gardant exactement les mêmes destinations.
class _NavRail extends StatelessWidget {
  final bool isAdmin;
  const _NavRail({required this.isAdmin});

  @override
  Widget build(BuildContext context) {
    final items = <_NavItem>[
      _NavItem(Icons.picture_as_pdf_rounded, 'Planning de Garde Officiel', AppColors.urg24h,
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OfficialPlanningScreen()))),
      _NavItem(Icons.badge_rounded, 'Annuaire', AppColors.catService,
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DirectoryScreen()))),
      _NavItem(Icons.medical_services_rounded, 'Séniors d’astreinte', AppColors.conge,
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AstreinteScreen()))),
      _NavItem(Icons.groups_2_rounded, 'Juniors d’astreinte', AppColors.service24h,
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => const JuniorOnCallScreen()))),
      _NavItem(Icons.tune_rounded, 'Réglages', AppColors.inkSoft,
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
      if (isAdmin)
        _NavItem(Icons.admin_panel_settings_rounded, 'Vue Admin', AppColors.ink,
            () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen()))),
    ];

    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) => _NavChip(item: items[i]),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  _NavItem(this.icon, this.label, this.accent, this.onTap);
}

class _NavChip extends StatelessWidget {
  final _NavItem item;
  const _NavChip({required this.item});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: AppRadius.pillR,
        onTap: item.onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: AppRadius.pillR,
            border: Border.all(color: AppColors.line),
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(item.icon, size: 16, color: item.accent),
              const SizedBox(width: 6),
              Text(item.label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.ink)),
            ],
          ),
        ),
      ),
    );
  }
}

// =======================================================================
// BARRE DE MOIS — navigation + statut de validation, en une seule ligne.
// =======================================================================

class _MonthBar extends StatelessWidget {
  final AppState appState;
  const _MonthBar({required this.appState});

  @override
  Widget build(BuildContext context) {
    final month = appState.visibleMonth;
    final record = appState.myPlanningMonth(month);
    final status = record?.status ?? PlanningMonthStatus.draft;
    final monthLabel = _capitalize(DateFormat.yMMMM('fr_FR').format(month));

    late String chipLabel;
    late IconData chipIcon;
    late Color chipColor;
    String? reopenReason;
    switch (status) {
      case PlanningMonthStatus.approved:
        chipLabel = 'Validé';
        chipIcon = Icons.verified_rounded;
        chipColor = AppColors.conge;
        break;
      case PlanningMonthStatus.draft:
      case PlanningMonthStatus.submitted:
      case PlanningMonthStatus.rejected:
        reopenReason = record?.rejectionReason?.trim();
        final reopened = reopenReason != null && reopenReason.isNotEmpty;
        chipLabel = reopened ? 'Rouvert' : 'En préparation';
        chipIcon = reopened ? Icons.lock_open_rounded : Icons.edit_calendar_rounded;
        chipColor = reopened ? AppColors.serviceJour : AppColors.paperAlt;
        break;
    }
    final canSubmit = status != PlanningMonthStatus.approved;

    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.xs, AppSpace.lg, AppSpace.xs),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          MonthNavigation(
            label: monthLabel,
            onPrevious: appState.previousMonth,
            onNext: appState.nextMonth,
            onLabelTap: () => _showMonthInfo(context, status, reopenReason),
          ),
          Wrap(
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: AppSpace.sm,
            runSpacing: AppSpace.xs,
            children: [
              GestureDetector(
                onTap: () => _showMonthInfo(context, status, reopenReason),
                child: Pill(text: chipLabel, icon: chipIcon,
                  background: chipColor.withOpacity(status == PlanningMonthStatus.approved ? 0.22 : 1),
                  foreground: status == PlanningMonthStatus.approved ? AppColors.congeText : AppColors.ink),
              ),
              if (canSubmit) _ValidateButton(appState: appState, month: month),
            ],
          ),
        ],
      ),
    );
  }

  void _showMonthInfo(BuildContext context, PlanningMonthStatus status, String? reopenReason) {
    late String title;
    late String detail;
    switch (status) {
      case PlanningMonthStatus.approved:
        title = 'Calendrier validé définitivement';
        detail = 'Le mois est verrouillé. Un administrateur peut supprimer une garde validée ou rouvrir le calendrier pour correction.';
        break;
      case PlanningMonthStatus.draft:
      case PlanningMonthStatus.submitted:
      case PlanningMonthStatus.rejected:
        if (reopenReason != null && reopenReason.isNotEmpty) {
          title = 'Calendrier rouvert par un administrateur';
          detail = 'Motif : $reopenReason. Modifiez vos tuiles puis validez à nouveau le mois.';
        } else {
          title = 'Calendrier en préparation';
          detail = 'Placez vos tuiles Service, Urgences et Congé puis validez définitivement le mois.';
        }
        break;
    }
    showModalBottomSheet<void>(
      context: context,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(AppSpace.xl, AppSpace.md, AppSpace.xl, AppSpace.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: AppSpace.sm),
            Text(detail, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }
}

class _ValidateButton extends StatelessWidget {
  final AppState appState;
  final DateTime month;
  const _ValidateButton({required this.appState, required this.month});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 34,
      child: FilledButton(
        style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 14), textStyle: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800)),
        onPressed: () async {
          final confirm = await showDialog<bool>(
            context: context,
            builder: (dialogContext) => AlertDialog(
              title: const Text('Valider définitivement ce calendrier ?'),
              content: const Text(
                'Après validation, vous ne pourrez plus déplacer, remplacer ni retirer vos tuiles. '
                'Seul un administrateur pourra supprimer une garde validée ou rouvrir le mois pour correction. '
                'Les tuiles Congé seront envoyées à l’administration pour approbation.',
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Annuler')),
                FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Valider définitivement')),
              ],
            ),
          );
          if (confirm != true || !context.mounted) return;
          final err = await appState.submitMyPlanningMonth(month);
          if (!context.mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err ?? 'Calendrier validé définitivement.')));
        },
        child: const Text('Valider'),
      ),
    );
  }
}

// =======================================================================
// JOURS DE LA SEMAINE
// =======================================================================

class _WeekdaysRow extends StatelessWidget {
  const _WeekdaysRow();
  @override
  Widget build(BuildContext context) {
    const days = ['L', 'Ma', 'Me', 'J', 'V', 'S', 'D'];
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.xs, AppSpace.lg, 0),
      child: Row(
        children: days
            .map((d) => Expanded(
                  child: Text(d, textAlign: TextAlign.center, style: Theme.of(context).textTheme.labelMedium),
                ))
            .toList(),
      ),
    );
  }
}

// =======================================================================
// GRILLE DU CALENDRIER — cœur de l'écran, toujours entièrement visible.
// =======================================================================

class _CalendarGrid extends StatelessWidget {
  const _CalendarGrid();
  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final month = appState.visibleMonth;
    final firstWeekday = DateTime(month.year, month.month, 1).weekday - 1;
    final daysInMonth = DateTime(month.year, month.month + 1, 0).day;
    final todayKey = AppState.dateKey(DateTime.now());
    final monthStatus = appState.myPlanningMonth(month)?.status ?? PlanningMonthStatus.draft;
    final monthEditable = appState.canEditMyPlanningMonth(month);
    final monthApproved = monthStatus == PlanningMonthStatus.approved;
    final totalCells = firstWeekday + daysInMonth;
    final rows = ((totalCells + 6) ~/ 7).clamp(5, 6);
    final cells = <Widget>[];
    for (var i = 0; i < firstWeekday; i++) {
      cells.add(KeyedSubtree(key: ValueKey('empty-$i'), child: const SizedBox.shrink()));
    }
    for (var d = 1; d <= daysInMonth; d++) {
      final date = DateTime(month.year, month.month, d);
      final dateStr = AppState.dateKey(date);
      final entry = appState.myEntryForDate(dateStr);
      final editable = monthEditable &&
          !appState.dateIsPast(dateStr) &&
          (entry == null || !appState.isApprovedLeaveEntry(entry));
      final canExchange = monthApproved && entry != null && ShiftCatalog.byId(entry.shiftId).hasSchedule && !appState.guardHasStarted(entry);
      cells.add(KeyedSubtree(
        key: ValueKey(dateStr),
        child: _DayCell(
          day: d,
          dateStr: dateStr,
          isToday: dateStr == todayKey,
          entry: entry,
          editable: editable,
          locked: !monthEditable,
          canExchange: canExchange,
          onDrop: (shiftId) async {
            final err = await appState.placeShift(dateStr, shiftId);
            if (err != null && context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
          },
          onRemove: entry == null
              ? null
              : () async {
                  final err = await appState.removeShift(entry.id);
                  if (err != null && context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
                },
          onExchange: entry == null
              ? null
              : () => showModalBottomSheet<void>(
                    context: context,
                    isScrollControlled: true,
                    builder: (_) => ExchangeRequestSheet(dateStr: dateStr, entry: entry),
                  ),
        ),
      ));
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpace.lg),
      child: LayoutBuilder(
        builder: (context, constraints) {
          const gap = 6.0;
          final itemWidth = ((constraints.maxWidth - gap * 6) / 7).clamp(1.0, double.infinity);
          final rawHeight = (constraints.maxHeight - gap * (rows - 1)) / rows;
          final itemHeight = rawHeight.isFinite && rawHeight > 1 ? rawHeight : 1.0;
          final aspectRatio = itemWidth / itemHeight;
          return GridView.count(
            key: ValueKey('grid-${month.year}-${month.month}'),
            crossAxisCount: 7,
            mainAxisSpacing: gap,
            crossAxisSpacing: gap,
            childAspectRatio: aspectRatio,
            physics: const NeverScrollableScrollPhysics(),
            children: cells,
          );
        },
      ),
    );
  }
}

class _DayCell extends StatelessWidget {
  final int day;
  final String dateStr;
  final bool isToday;
  final PlanningEntry? entry;
  final bool editable;
  final bool locked;
  final bool canExchange;
  final ValueChanged<String> onDrop;
  final VoidCallback? onRemove;
  final VoidCallback? onExchange;

  const _DayCell({
    required this.day,
    required this.dateStr,
    required this.isToday,
    required this.entry,
    required this.editable,
    required this.locked,
    required this.canExchange,
    required this.onDrop,
    required this.onRemove,
    required this.onExchange,
  });

  @override
  Widget build(BuildContext context) {
    final currentEntry = entry;
    return DragTarget<String>(
      onWillAcceptWithDetails: (_) => editable,
      onAcceptWithDetails: (details) => onDrop(details.data),
      builder: (context, candidateData, rejectedData) {
        final hovering = candidateData.isNotEmpty && editable;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          curve: Curves.easeOut,
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: hovering ? AppColors.brandSoft : AppColors.card,
            borderRadius: AppRadius.mdR,
            border: Border.all(
              color: hovering ? AppColors.ink : (isToday ? AppColors.ink : AppColors.line),
              width: hovering || isToday ? 1.6 : 1,
            ),
            boxShadow: currentEntry == null ? null : AppShadow.low,
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final tiny = constraints.maxWidth < 50 || constraints.maxHeight < 54;
              final headerHeight = tiny ? 19.0 : 23.0;
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(
                    height: headerHeight,
                    child: Row(
                      children: [
                        Container(
                          constraints: BoxConstraints(
                            minWidth: tiny ? 18 : 22,
                            minHeight: tiny ? 18 : 22,
                          ),
                          alignment: Alignment.center,
                          padding: EdgeInsets.symmetric(horizontal: tiny ? 2 : 4),
                          decoration: BoxDecoration(
                            color: isToday ? AppColors.ink : Colors.transparent,
                            borderRadius: AppRadius.smR,
                          ),
                          child: Text(
                            '$day',
                            style: TextStyle(
                              fontFamily: 'SpaceGrotesk',
                              fontSize: tiny ? 9.5 : 11.5,
                              color: isToday ? Colors.white : AppColors.ink,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const Spacer(),
                        if (editable && currentEntry != null && onRemove != null)
                          _CalendarCellAction(
                            tooltip: 'Retirer cette garde',
                            icon: Icons.close_rounded,
                            onTap: onRemove!,
                            compact: tiny,
                            foreground: AppColors.danger,
                            background: const Color(0xFFFFECE9),
                          )
                        else if (canExchange && onExchange != null)
                          _CalendarCellAction(
                            tooltip: 'Échanger cette garde',
                            icon: Icons.swap_horiz_rounded,
                            onTap: onExchange!,
                            compact: tiny,
                            foreground: Colors.white,
                            background: AppColors.ink,
                          )
                        else if (locked && currentEntry == null)
                          Icon(Icons.lock_outline_rounded, size: tiny ? 12 : 14, color: AppColors.inkFaint),
                      ],
                    ),
                  ),
                  SizedBox(height: tiny ? 1 : 2),
                  Expanded(
                    child: currentEntry != null
                        ? _ShiftChip(entry: currentEntry)
                        : Container(
                            decoration: BoxDecoration(
                              color: hovering ? Colors.white.withOpacity(0.58) : Colors.transparent,
                              borderRadius: AppRadius.smR,
                            ),
                            alignment: Alignment.center,
                            child: hovering
                                ? Icon(Icons.add_rounded, size: tiny ? 18 : 24, color: AppColors.ink)
                                : null,
                          ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class _CalendarCellAction extends StatelessWidget {
  final String tooltip;
  final IconData icon;
  final VoidCallback onTap;
  final bool compact;
  final Color foreground;
  final Color background;

  const _CalendarCellAction({
    required this.tooltip,
    required this.icon,
    required this.onTap,
    required this.compact,
    required this.foreground,
    required this.background,
  });

  @override
  Widget build(BuildContext context) {
    final size = compact ? 18.0 : 22.0;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: background,
        borderRadius: BorderRadius.circular(999),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(999),
          child: SizedBox(
            width: size,
            height: size,
            child: Icon(icon, size: compact ? 12 : 14, color: foreground),
          ),
        ),
      ),
    );
  }
}

class _ShiftChip extends StatelessWidget {
  final PlanningEntry entry;
  const _ShiftChip({required this.entry});

  @override
  Widget build(BuildContext context) {
    final shift = ShiftCatalog.byId(entry.shiftId);
    final isUrgence = shift.id.startsWith('urg-');
    final isLeave = shift.id == 'conge';
    final leave = isLeave ? context.watch<AppState>().leaveRequestForEntry(entry) : null;
    final pendingLeave = leave?.status == LeaveRequestStatus.pendingAdmin;

    return LayoutBuilder(
      builder: (context, constraints) {
        final tiny = constraints.maxWidth < 48 || constraints.maxHeight < 32;
        final compact = constraints.maxWidth < 66 || constraints.maxHeight < 48;
        final groupLabel = isLeave
            ? 'Congé'
            : isUrgence
                ? (tiny ? 'URG' : 'Urgences')
                : (tiny ? 'SERV' : 'Service');
        final shiftLabel = isLeave
            ? (pendingLeave ? 'Attente' : null)
            : shift.label == '24H'
                ? '24H'
                : shift.label;
        final showIcon = !tiny && constraints.maxHeight >= 42;

        return Container(
          width: double.infinity,
          height: double.infinity,
          padding: EdgeInsets.symmetric(horizontal: tiny ? 2 : 4, vertical: tiny ? 1 : 3),
          decoration: BoxDecoration(
            color: shift.color,
            borderRadius: AppRadius.smR,
            border: Border.all(color: Colors.white.withOpacity(0.38), width: 1.1),
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (showIcon) ...[
                  Icon(shift.icon, size: compact ? 16 : 21, color: shift.textColor),
                  SizedBox(height: compact ? 1 : 2),
                ],
                Text(
                  groupLabel,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: tiny ? 9.5 : compact ? 10.5 : 12.5,
                    height: 1.0,
                    fontWeight: FontWeight.w900,
                    color: shift.textColor,
                  ),
                ),
                if (shiftLabel != null) ...[
                  const SizedBox(height: 1),
                  Text(
                    shiftLabel,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: tiny ? 9 : compact ? 10 : 11.5,
                      height: 1.0,
                      fontWeight: FontWeight.w800,
                      color: shift.textColor.withOpacity(0.94),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

// =======================================================================
// PLATEAU DE TUILES — drag-and-drop identique, habillage modernisé.
// =======================================================================

class _ShiftTray extends StatelessWidget {
  final bool enabled;
  const _ShiftTray({required this.enabled});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.md, AppSpace.lg, AppSpace.lg),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadius.xl)),
        boxShadow: AppShadow.mid,
        border: const Border(top: BorderSide(color: AppColors.line)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 36, height: 4, margin: const EdgeInsets.only(bottom: AppSpace.md), decoration: BoxDecoration(color: AppColors.line, borderRadius: AppRadius.pillR)),
          if (!enabled)
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.lock_outline_rounded, size: 13, color: AppColors.inkSoft),
                SizedBox(width: 5),
                Flexible(child: Text('Tuiles verrouillées : calendrier validé. Un administrateur peut le rouvrir si nécessaire.', style: TextStyle(fontSize: 10, color: AppColors.inkSoft), textAlign: TextAlign.center)),
              ]),
            ),
          Opacity(
            opacity: enabled ? 1 : 0.45,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(children: [
                    _TrayRow(label: 'Service', accent: AppColors.catService, enabled: enabled, shifts: const [ShiftCatalog.serviceJour, ShiftCatalog.service24h, ShiftCatalog.serviceNuit]),
                    const SizedBox(height: AppSpace.sm),
                    _TrayRow(label: 'Urgences', accent: AppColors.catUrgence, enabled: enabled, shifts: const [ShiftCatalog.urgJour, ShiftCatalog.urg24h, ShiftCatalog.urgNuit]),
                  ]),
                ),
                const SizedBox(width: AppSpace.md),
                _CongeDock(shift: ShiftCatalog.conge, enabled: enabled),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TrayRow extends StatelessWidget {
  final String label;
  final Color accent;
  final List<ShiftType> shifts;
  final bool enabled;
  const _TrayRow({required this.label, required this.accent, required this.shifts, required this.enabled});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Container(width: 6, height: 6, decoration: BoxDecoration(color: accent, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(label, style: Theme.of(context).textTheme.labelMedium),
        ]),
        const SizedBox(height: 6),
        Row(children: shifts.map((s) => Expanded(child: _ShiftTile(shift: s, enabled: enabled))).toList()),
      ],
    );
  }
}

class _ShiftTile extends StatelessWidget {
  final ShiftType shift;
  final bool enabled;
  const _ShiftTile({required this.shift, required this.enabled});

  @override
  Widget build(BuildContext context) {
    final tile = Container(
      height: 56,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        color: shift.color,
        borderRadius: AppRadius.mdR,
        border: Border.all(color: shift.textColor.withOpacity(0.10)),
        boxShadow: AppShadow.low,
      ),
      alignment: Alignment.center,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(shift.icon, size: 19, color: shift.textColor),
        const SizedBox(height: 3),
        Text(shift.label, style: TextStyle(fontFamily: 'SpaceGrotesk', fontSize: 12.5, fontWeight: FontWeight.w600, color: shift.textColor)),
      ]),
    );
    return Draggable<String>(
      data: shift.id,
      maxSimultaneousDrags: enabled ? 1 : 0,
      feedback: Material(
        color: Colors.transparent,
        child: SizedBox(
          width: 98,
          height: 66,
          child: Transform.scale(scale: 1.06, child: DecoratedBox(decoration: BoxDecoration(boxShadow: AppShadow.high), child: tile)),
        ),
      ),
      childWhenDragging: Opacity(opacity: 0.28, child: tile),
      child: tile,
    );
  }
}

class _CongeDock extends StatelessWidget {
  final ShiftType shift;
  final bool enabled;
  const _CongeDock({required this.shift, required this.enabled});

  @override
  Widget build(BuildContext context) {
    final dock = Container(
      width: 90,
      height: 134,
      decoration: BoxDecoration(
        color: shift.color,
        borderRadius: AppRadius.mdR,
        border: Border.all(color: shift.textColor.withOpacity(0.10)),
        boxShadow: AppShadow.low,
      ),
      alignment: Alignment.center,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(shift.icon, size: 26, color: shift.textColor),
        const SizedBox(height: 6),
        Text(shift.label, style: TextStyle(fontFamily: 'SpaceGrotesk', fontSize: 13.5, fontWeight: FontWeight.w600, color: shift.textColor)),
      ]),
    );
    return Draggable<String>(
      data: shift.id,
      maxSimultaneousDrags: enabled ? 1 : 0,
      feedback: Material(
        color: Colors.transparent,
        child: SizedBox(width: 90, height: 134, child: Transform.scale(scale: 1.05, child: DecoratedBox(decoration: BoxDecoration(boxShadow: AppShadow.high), child: dock))),
      ),
      childWhenDragging: Opacity(opacity: 0.28, child: dock),
      child: dock,
    );
  }
}

String _capitalize(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
