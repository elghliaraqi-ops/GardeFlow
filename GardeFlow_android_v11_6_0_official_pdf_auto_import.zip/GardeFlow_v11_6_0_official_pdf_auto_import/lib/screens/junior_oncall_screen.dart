import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../data/hospitals.dart';
import '../models/app_user.dart';
import '../models/planning_entry.dart';
import '../models/shift_type.dart';
import '../services/supabase_backend_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../theme/widgets.dart';

/// Vue hebdomadaire en lecture seule des Juniors qui assurent une garde de Service.
///
/// L'objectif est de répondre rapidement à la question : « qui est d'astreinte
/// parmi les Juniors dans tel service, cette semaine ? ».
/// Les données sont donc regroupées d'abord par service, puis établissement,
/// puis date. Seuls les calendriers validés sont visibles.
class JuniorOnCallScreen extends StatefulWidget {
  const JuniorOnCallScreen({super.key});

  @override
  State<JuniorOnCallScreen> createState() => _JuniorOnCallScreenState();
}

class _JuniorOnCallScreenState extends State<JuniorOnCallScreen> {
  late DateTime _weekStart;
  bool _loading = true;
  String? _error;
  String? _selectedHospital;
  List<_JuniorOnCallRow> _rows = const [];

  @override
  void initState() {
    super.initState();
    _weekStart = _startOfWeek(DateTime.now());
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  DateTime get _weekEnd => _weekStart.add(const Duration(days: 6));

  static DateTime _startOfWeek(DateTime date) {
    final normalized = DateTime(date.year, date.month, date.day);
    return normalized.subtract(Duration(days: normalized.weekday - DateTime.monday));
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final appState = context.read<AppState>();
      if (appState.backendEnabled) {
        final data = await SupabaseBackendService.instance.fetchJuniorOnCallRoster(
          from: _weekStart,
          to: _weekEnd,
        );
        final rows = data.map(_JuniorOnCallRow.fromRpc).toList()..sort(_compareRows);
        if (!mounted) return;
        setState(() => _rows = rows);
      } else {
        final rows = _buildLocalRows(appState)..sort(_compareRows);
        if (!mounted) return;
        setState(() => _rows = rows);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _rows = const [];
        _error = 'Impossible de charger les Juniors d’astreinte.\n$e';
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<_JuniorOnCallRow> _buildLocalRows(AppState appState) {
    final usersById = <String, AppUser>{for (final user in appState.users) user.id: user};
    final usersByPhone = <String, AppUser>{for (final user in appState.users) user.phone: user};
    final result = <_JuniorOnCallRow>[];
    final start = DateTime(_weekStart.year, _weekStart.month, _weekStart.day);
    final endExclusive = _weekEnd.add(const Duration(days: 1));

    for (final PlanningEntry entry in appState.planning) {
      if (!entry.shiftId.startsWith('service-')) continue;
      final date = DateTime.tryParse(entry.dateStr);
      if (date == null || date.isBefore(start) || !date.isBefore(endExclusive)) continue;
      if (!appState.isPlanningEntryApproved(entry)) continue;

      final user = usersById[entry.ownerId] ?? usersByPhone[entry.ownerPhone];
      if (user == null || user.grade != MedicalGrade.junior || user.accountStatus != AccountStatus.active) continue;

      result.add(_JuniorOnCallRow(
        dateStr: entry.dateStr,
        shiftId: entry.shiftId,
        ownerName: entry.ownerName,
        service: user.service,
        hospital: user.hospital,
      ));
    }
    return result;
  }

  static int _compareRows(_JuniorOnCallRow a, _JuniorOnCallRow b) {
    var c = a.service.toLowerCase().compareTo(b.service.toLowerCase());
    if (c != 0) return c;
    c = _hospitalRank(a.hospital).compareTo(_hospitalRank(b.hospital));
    if (c != 0) return c;
    c = a.dateStr.compareTo(b.dateStr);
    if (c != 0) return c;
    return a.ownerName.toLowerCase().compareTo(b.ownerName.toLowerCase());
  }

  static int _hospitalRank(String hospital) {
    final index = kHospitals.indexOf(hospital);
    return index < 0 ? 999 : index;
  }

  void _changeWeek(int delta) {
    setState(() => _weekStart = _weekStart.add(Duration(days: 7 * delta)));
    _load();
  }

  void _goToCurrentWeek() {
    final current = _startOfWeek(DateTime.now());
    if (_sameDay(current, _weekStart)) return;
    setState(() => _weekStart = current);
    _load();
  }

  static bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  List<_JuniorOnCallRow> get _visibleRows {
    final selected = _selectedHospital;
    if (selected == null) return _rows;
    return _rows.where((row) => row.hospital == selected).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.paper,
      appBar: AppBar(
        title: const GardeFlowTitle('Juniors d’astreinte'),
        actions: [
          IconButton(
            tooltip: 'Semaine actuelle',
            onPressed: _loading ? null : _goToCurrentWeek,
            icon: const Icon(Icons.today_rounded),
          ),
          IconButton(
            tooltip: 'Actualiser',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: Column(
        children: [
          _WeekSelector(
            start: _weekStart,
            end: _weekEnd,
            onPrevious: _loading ? null : () => _changeWeek(-1),
            onNext: _loading ? null : () => _changeWeek(1),
          ),
          _HospitalFilter(
            selectedHospital: _selectedHospital,
            onChanged: (hospital) => setState(() => _selectedHospital = hospital),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return _JuniorErrorState(message: _error!, onRetry: _load);

    final rows = _visibleRows;
    if (rows.isEmpty) {
      return RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            const SizedBox(height: 110),
            const Icon(Icons.groups_2_outlined, size: 52, color: AppColors.inkFaint),
            const SizedBox(height: AppSpace.md),
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSpace.xl),
                child: Text(
                  _selectedHospital == null
                      ? 'Aucune garde de service Junior validée pour cette semaine.'
                      : 'Aucune garde de service Junior validée pour cette semaine à ${hospitalDisplayName(_selectedHospital!)}.',
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      );
    }

    final grouped = _groupRowsByService(rows);
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.md, AppSpace.lg, 36),
        itemCount: grouped.length,
        itemBuilder: (context, index) => _ServiceWeekCard(group: grouped[index]),
      ),
    );
  }
}

class _WeekSelector extends StatelessWidget {
  final DateTime start;
  final DateTime end;
  final VoidCallback? onPrevious;
  final VoidCallback? onNext;

  const _WeekSelector({required this.start, required this.end, this.onPrevious, this.onNext});

  String _label() {
    final startDay = DateFormat('d', 'fr_FR').format(start);
    final startMonth = DateFormat('MMMM', 'fr_FR').format(start);
    final endDay = DateFormat('d', 'fr_FR').format(end);
    final endMonth = DateFormat('MMMM', 'fr_FR').format(end);
    final year = DateFormat('yyyy', 'fr_FR').format(end);

    if (start.year == end.year && start.month == end.month) {
      return 'Semaine du $startDay au $endDay $endMonth $year';
    }
    if (start.year == end.year) {
      return 'Semaine du $startDay $startMonth au $endDay $endMonth $year';
    }
    return 'Semaine du $startDay $startMonth ${start.year} au $endDay $endMonth ${end.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.md, AppSpace.lg, AppSpace.sm),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppRadius.mdR,
        border: Border.all(color: AppColors.line),
        boxShadow: AppShadow.low,
      ),
      child: Row(
        children: [
          IconButton(onPressed: onPrevious, tooltip: 'Semaine précédente', icon: const Icon(Icons.chevron_left_rounded)),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_label(), textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
                const SizedBox(height: 2),
                Text('Qui est d’astreinte parmi les Juniors ?', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          IconButton(onPressed: onNext, tooltip: 'Semaine suivante', icon: const Icon(Icons.chevron_right_rounded)),
        ],
      ),
    );
  }
}

class _HospitalFilter extends StatelessWidget {
  final String? selectedHospital;
  final ValueChanged<String?> onChanged;

  const _HospitalFilter({required this.selectedHospital, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppSpace.lg, vertical: 4),
        children: [
          ChoiceChip(
            label: const Text('Tous les établissements'),
            selected: selectedHospital == null,
            onSelected: (_) => onChanged(null),
          ),
          const SizedBox(width: 8),
          for (final hospital in kHospitals) ...[
            ChoiceChip(
              label: Text(hospitalDisplayName(hospital)),
              selected: selectedHospital == hospital,
              onSelected: (_) => onChanged(hospital),
            ),
            const SizedBox(width: 8),
          ],
        ],
      ),
    );
  }
}

class _ServiceWeekCard extends StatelessWidget {
  final _ServiceWeekGroup group;
  const _ServiceWeekCard({required this.group});

  @override
  Widget build(BuildContext context) {
    final total = group.hospitals.fold<int>(0, (sum, hospital) => sum + hospital.dates.fold<int>(0, (s, date) => s + date.rows.length));

    return Container(
      margin: const EdgeInsets.only(bottom: AppSpace.lg),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: AppRadius.mdR,
        border: Border.all(color: AppColors.line),
        boxShadow: AppShadow.low,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: AppSpace.md, vertical: 12),
            decoration: const BoxDecoration(
              color: AppColors.brandSoft,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(AppRadius.md), topRight: Radius.circular(AppRadius.md)),
            ),
            child: Row(
              children: [
                const Icon(Icons.medical_services_rounded, size: 20, color: AppColors.brand),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(group.service, style: const TextStyle(color: AppColors.brand, fontWeight: FontWeight.w900, fontSize: 16)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                  decoration: BoxDecoration(color: AppColors.card, borderRadius: AppRadius.pillR),
                  child: Text('$total garde${total > 1 ? 's' : ''}', style: Theme.of(context).textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w800)),
                ),
              ],
            ),
          ),
          for (var i = 0; i < group.hospitals.length; i++) ...[
            _HospitalWeekBlock(group: group.hospitals[i]),
            if (i != group.hospitals.length - 1) const Divider(height: 1),
          ],
        ],
      ),
    );
  }
}

class _HospitalWeekBlock extends StatelessWidget {
  final _HospitalWeekGroup group;
  const _HospitalWeekBlock({required this.group});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(AppSpace.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Icon(Icons.local_hospital_outlined, size: 17, color: AppColors.inkSoft),
              const SizedBox(width: 7),
              Expanded(
                child: Text(hospitalDisplayName(group.hospital), style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          for (var i = 0; i < group.dates.length; i++) ...[
            _DateDutyRow(group: group.dates[i]),
            if (i != group.dates.length - 1) const Divider(height: 14, indent: 44),
          ],
        ],
      ),
    );
  }
}

class _DateDutyRow extends StatelessWidget {
  final _DateDutyGroup group;
  const _DateDutyRow({required this.group});

  @override
  Widget build(BuildContext context) {
    final date = DateTime.parse(group.dateStr);
    final dayName = DateFormat('EEE', 'fr_FR').format(date).replaceAll('.', '');
    final dayMonth = DateFormat('d MMM', 'fr_FR').format(date);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 42,
          child: Column(
            children: [
              Text(dayName.toUpperCase(), style: Theme.of(context).textTheme.labelSmall?.copyWith(color: AppColors.inkSoft, fontWeight: FontWeight.w900)),
              const SizedBox(height: 2),
              Text(dayMonth, textAlign: TextAlign.center, style: Theme.of(context).textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w700)),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            children: [
              for (final row in group.rows) _JuniorDutyLine(row: row),
            ],
          ),
        ),
      ],
    );
  }
}

class _JuniorDutyLine extends StatelessWidget {
  final _JuniorOnCallRow row;
  const _JuniorDutyLine({required this.row});

  @override
  Widget build(BuildContext context) {
    final shift = ShiftCatalog.byId(row.shiftId);
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: shift.color,
            foregroundColor: shift.textColor,
            child: Icon(shift.icon, size: 14),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(row.ownerName, style: const TextStyle(fontWeight: FontWeight.w800), overflow: TextOverflow.ellipsis),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(color: shift.color, borderRadius: AppRadius.pillR),
            child: Text(shift.label, style: TextStyle(color: shift.textColor, fontSize: 10.5, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class _JuniorErrorState extends StatelessWidget {
  final String message;
  final Future<void> Function() onRetry;
  const _JuniorErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpace.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded, size: 44, color: AppColors.danger),
            const SizedBox(height: AppSpace.md),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: AppSpace.md),
            FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh_rounded), label: const Text('Réessayer')),
          ],
        ),
      ),
    );
  }
}

class _JuniorOnCallRow {
  final String dateStr;
  final String shiftId;
  final String ownerName;
  final String service;
  final String hospital;

  const _JuniorOnCallRow({
    required this.dateStr,
    required this.shiftId,
    required this.ownerName,
    required this.service,
    required this.hospital,
  });

  factory _JuniorOnCallRow.fromRpc(Map<String, dynamic> json) => _JuniorOnCallRow(
        dateStr: json['date_str'].toString(),
        shiftId: json['shift_id'] as String,
        ownerName: json['owner_name'] as String,
        service: json['service'] as String,
        hospital: json['hospital'] as String,
      );
}

class _ServiceWeekGroup {
  final String service;
  final List<_HospitalWeekGroup> hospitals;
  const _ServiceWeekGroup(this.service, this.hospitals);
}

class _HospitalWeekGroup {
  final String hospital;
  final List<_DateDutyGroup> dates;
  const _HospitalWeekGroup(this.hospital, this.dates);
}

class _DateDutyGroup {
  final String dateStr;
  final List<_JuniorOnCallRow> rows;
  const _DateDutyGroup(this.dateStr, this.rows);
}

List<_ServiceWeekGroup> _groupRowsByService(List<_JuniorOnCallRow> rows) {
  final byService = <String, Map<String, Map<String, List<_JuniorOnCallRow>>>>{};
  for (final row in rows) {
    byService
        .putIfAbsent(row.service, () => {})
        .putIfAbsent(row.hospital, () => {})
        .putIfAbsent(row.dateStr, () => [])
        .add(row);
  }

  final services = byService.keys.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
  return services.map((service) {
    final hospitalMap = byService[service]!;
    final hospitals = hospitalMap.keys.toList()
      ..sort((a, b) {
        final ai = kHospitals.indexOf(a);
        final bi = kHospitals.indexOf(b);
        final ar = ai < 0 ? 999 : ai;
        final br = bi < 0 ? 999 : bi;
        final c = ar.compareTo(br);
        return c != 0 ? c : a.compareTo(b);
      });

    return _ServiceWeekGroup(
      service,
      hospitals.map((hospital) {
        final dateMap = hospitalMap[hospital]!;
        final dates = dateMap.keys.toList()..sort();
        return _HospitalWeekGroup(
          hospital,
          dates.map((date) {
            final members = dateMap[date]!
              ..sort((a, b) {
                final c = a.ownerName.toLowerCase().compareTo(b.ownerName.toLowerCase());
                return c != 0 ? c : a.shiftId.compareTo(b.shiftId);
              });
            return _DateDutyGroup(date, members);
          }).toList(),
        );
      }).toList(),
    );
  }).toList();
}
