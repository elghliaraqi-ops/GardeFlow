import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/hospitals.dart';
import '../data/services.dart';
import '../models/app_user.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/brand_identity.dart';
import 'home_screen.dart';

const _loginGreen = Color(0xFF0F7C49);
const _loginGreenDark = Color(0xFF075B38);

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> with SingleTickerProviderStateMixin {
  bool _showRegister = false;
  bool _obscureLoginPassword = true;
  bool _obscureRegisterPassword = true;
  String? _error;
  String? _info;
  String _hospital = kHospitals.first;

  late final AnimationController _entranceController;
  late final Animation<double> _contentOpacity;
  late final Animation<Offset> _contentSlide;

  // Connexion
  final _loginPhoneCtrl = TextEditingController();
  final _loginPasswordCtrl = TextEditingController();

  // Inscription
  final _regNomCtrl = TextEditingController();
  final _regPrenomCtrl = TextEditingController();
  final _regPhoneCtrl = TextEditingController();
  final _regPasswordCtrl = TextEditingController();
  String _regService = kServices.first;
  MedicalGrade _regGrade = MedicalGrade.junior;

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1250),
    );
    _contentOpacity = CurvedAnimation(
      parent: _entranceController,
      curve: const Interval(0.18, 1, curve: Curves.easeOutCubic),
    );
    _contentSlide = Tween<Offset>(
      begin: const Offset(0, 0.035),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _entranceController,
      curve: const Interval(0.12, 1, curve: Curves.easeOutCubic),
    ));
    _entranceController.forward();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _loginPhoneCtrl.dispose();
    _loginPasswordCtrl.dispose();
    _regNomCtrl.dispose();
    _regPrenomCtrl.dispose();
    _regPhoneCtrl.dispose();
    _regPasswordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submitLogin() async {
    final appState = context.read<AppState>();
    final err = await appState.login(_loginPhoneCtrl.text, _loginPasswordCtrl.text);
    if (!mounted) return;
    setState(() {
      _error = err;
      _info = null;
    });
    if (err == null) _goToApp();
  }

  Future<void> _submitRegister() async {
    final appState = context.read<AppState>();
    final err = await appState.register(
      nom: _regNomCtrl.text,
      prenom: _regPrenomCtrl.text,
      rawPhone: _regPhoneCtrl.text,
      password: _regPasswordCtrl.text,
      service: _regService,
      grade: _regGrade,
      hospital: _hospital,
    );
    if (!mounted) return;
    if (err == null) {
      setState(() {
        _error = null;
        _info = 'Compte créé. Un administrateur doit maintenant valider votre inscription avant la première connexion.';
        _showRegister = false;
        _loginPhoneCtrl.text = _regPhoneCtrl.text;
      });
    } else {
      setState(() {
        _error = err;
        _info = null;
      });
    }
  }

  void _goToApp() {
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
  }

  void _showPasswordHelp() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Pour réinitialiser votre mot de passe, contactez un administrateur GardeFlow.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7F5),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/branding/login_urgences.jpg',
            fit: BoxFit.cover,
            alignment: Alignment.center,
            filterQuality: FilterQuality.high,
          ),
          AnimatedBuilder(
            animation: _entranceController,
            builder: (context, child) {
              final t = Curves.easeInOutCubic.transform(_entranceController.value);
              final sigma = 8.5 * t;
              return BackdropFilter(
                filter: ui.ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
                child: Container(color: Colors.white.withOpacity(0.05 + (0.10 * t))),
              );
            },
          ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white.withOpacity(0.62),
                  Colors.white.withOpacity(0.28),
                  Colors.white.withOpacity(0.48),
                  const Color(0xFFE9F2ED).withOpacity(0.72),
                ],
                stops: const [0, 0.28, 0.70, 1],
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _contentOpacity,
              child: SlideTransition(
                position: _contentSlide,
                child: Center(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(18, 20, 18, 24),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 460),
                      child: Column(
                        children: [
                          const GardeFlowBrandBlock(compact: true),
                          const SizedBox(height: 20),
                          if (_info != null)
                            _Banner(
                              text: _info!,
                              background: const Color(0xFFD9EDDF),
                              foreground: const Color(0xFF205B38),
                              icon: Icons.check_circle_rounded,
                            ),
                          if (_error != null)
                            _Banner(
                              text: _error!,
                              background: const Color(0xFFF4D4CF),
                              foreground: const Color(0xFF7E2A1C),
                              icon: Icons.error_rounded,
                            ),
                          _GlassCard(
                            child: AnimatedSwitcher(
                              duration: const Duration(milliseconds: 260),
                              switchInCurve: Curves.easeOutCubic,
                              switchOutCurve: Curves.easeInCubic,
                              child: !_showRegister ? _buildLoginForm() : _buildRegisterForm(),
                            ),
                          ),
                          const SizedBox(height: 22),
                          const InstitutionalLogosPanel(compact: true),
                          const SizedBox(height: 16),
                          const Text(
                            'AU SERVICE DES SOIGNANTS\nAU SERVICE DES PATIENTS',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 9.5,
                              height: 1.55,
                              letterSpacing: 2.5,
                              color: _loginGreenDark,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Container(
                            width: 46,
                            height: 2,
                            decoration: BoxDecoration(
                              color: _loginGreen.withOpacity(0.65),
                              borderRadius: BorderRadius.circular(99),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoginForm() {
    return Column(
      key: const ValueKey('login'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Bienvenue',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'SpaceGrotesk',
            fontSize: 29,
            fontWeight: FontWeight.w700,
            color: _loginGreenDark,
          ),
        ),
        const SizedBox(height: 7),
        const Text(
          'Connectez-vous pour accéder\nà votre planning de gardes',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 14, height: 1.35, color: Color(0xFF68757A), fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 22),
        TextField(
          controller: _loginPhoneCtrl,
          keyboardType: TextInputType.phone,
          textInputAction: TextInputAction.next,
          decoration: _glassInputDecoration(
            hint: 'Numéro de téléphone',
            icon: Icons.phone_android_rounded,
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _loginPasswordCtrl,
          obscureText: _obscureLoginPassword,
          textInputAction: TextInputAction.done,
          onSubmitted: (_) => _submitLogin(),
          decoration: _glassInputDecoration(
            hint: 'Mot de passe',
            icon: Icons.lock_outline_rounded,
            suffix: IconButton(
              onPressed: () => setState(() => _obscureLoginPassword = !_obscureLoginPassword),
              icon: Icon(
                _obscureLoginPassword ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                color: const Color(0xFF829096),
              ),
              tooltip: _obscureLoginPassword ? 'Afficher le mot de passe' : 'Masquer le mot de passe',
            ),
          ),
        ),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: _showPasswordHelp,
            style: TextButton.styleFrom(foregroundColor: _loginGreenDark, padding: const EdgeInsets.fromLTRB(8, 10, 2, 8)),
            child: const Text('Mot de passe oublié ?'),
          ),
        ),
        const SizedBox(height: 2),
        _GradientPrimaryButton(
          label: 'Se connecter',
          icon: Icons.arrow_forward_rounded,
          onPressed: _submitLogin,
        ),
        const SizedBox(height: 18),
        const _OrDivider(),
        const SizedBox(height: 16),
        SizedBox(
          height: 52,
          child: OutlinedButton(
            onPressed: () => setState(() {
              _showRegister = true;
              _error = null;
              _info = null;
            }),
            style: OutlinedButton.styleFrom(
              foregroundColor: _loginGreenDark,
              backgroundColor: Colors.white.withOpacity(0.28),
              side: const BorderSide(color: _loginGreen, width: 1.4),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            ),
            child: const Text('Créer un compte', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
        ),
      ],
    );
  }

  Widget _buildRegisterForm() {
    return Column(
      key: const ValueKey('register'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Créer un compte',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'SpaceGrotesk',
            fontSize: 27,
            fontWeight: FontWeight.w700,
            color: _loginGreenDark,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'Votre inscription sera validée par un administrateur.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12.5, height: 1.35, color: Color(0xFF68757A), fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _regNomCtrl,
                decoration: _glassInputDecoration(hint: 'Nom', icon: Icons.person_outline_rounded),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _regPrenomCtrl,
                decoration: _glassInputDecoration(hint: 'Prénom', icon: Icons.badge_outlined),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _regPhoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: _glassInputDecoration(hint: 'Numéro de téléphone', icon: Icons.phone_android_rounded),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _regPasswordCtrl,
          obscureText: _obscureRegisterPassword,
          decoration: _glassInputDecoration(
            hint: 'Mot de passe',
            icon: Icons.lock_outline_rounded,
            suffix: IconButton(
              onPressed: () => setState(() => _obscureRegisterPassword = !_obscureRegisterPassword),
              icon: Icon(
                _obscureRegisterPassword ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                color: const Color(0xFF829096),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _hospital,
          isExpanded: true,
          decoration: _glassInputDecoration(hint: 'Établissement', icon: Icons.local_hospital_outlined),
          items: kHospitals
              .map((h) => DropdownMenuItem(
                    value: h,
                    child: Text(hospitalDisplayName(h), style: const TextStyle(fontSize: 12.5), overflow: TextOverflow.ellipsis),
                  ))
              .toList(),
          onChanged: (v) => setState(() => _hospital = v ?? _hospital),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _regService,
          isExpanded: true,
          decoration: _glassInputDecoration(hint: 'Service actuel', icon: Icons.medical_services_outlined),
          items: kServices
              .map((s) => DropdownMenuItem(
                    value: s,
                    child: Text(s, style: const TextStyle(fontSize: 12.5), overflow: TextOverflow.ellipsis),
                  ))
              .toList(),
          onChanged: (v) => setState(() => _regService = v ?? _regService),
        ),
        const SizedBox(height: 16),
        const Text('Grade médical', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: Color(0xFF68757A))),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _gradeOption(MedicalGrade.junior, 'Junior')),
          const SizedBox(width: 10),
          Expanded(child: _gradeOption(MedicalGrade.senior, 'Senior')),
        ]),
        const SizedBox(height: 20),
        _GradientPrimaryButton(label: 'Créer mon compte', icon: Icons.person_add_alt_1_rounded, onPressed: _submitRegister),
        const SizedBox(height: 10),
        TextButton(
          onPressed: () => setState(() {
            _showRegister = false;
            _error = null;
            _info = null;
          }),
          style: TextButton.styleFrom(foregroundColor: _loginGreenDark),
          child: const Text('Déjà inscrit ? Se connecter'),
        ),
      ],
    );
  }

  InputDecoration _glassInputDecoration({
    required String hint,
    required IconData icon,
    Widget? suffix,
  }) {
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(17),
      borderSide: BorderSide(color: Colors.white.withOpacity(0.82), width: 1.2),
    );
    return InputDecoration(
      hintText: hint,
      labelText: null,
      prefixIcon: Icon(icon, color: const Color(0xFF829096), size: 21),
      suffixIcon: suffix,
      filled: true,
      fillColor: Colors.white.withOpacity(0.70),
      hintStyle: const TextStyle(color: Color(0xFF829096), fontWeight: FontWeight.w500),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      border: border,
      enabledBorder: border,
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(17),
        borderSide: const BorderSide(color: _loginGreen, width: 1.5),
      ),
    );
  }

  Widget _gradeOption(MedicalGrade value, String label) {
    final selected = _regGrade == value;
    return GestureDetector(
      onTap: () => setState(() => _regGrade = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 170),
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? _loginGreen : Colors.white.withOpacity(0.62),
          border: Border.all(color: selected ? _loginGreen : Colors.white.withOpacity(0.92), width: 1.4),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12.5,
            fontWeight: FontWeight.w800,
            color: selected ? Colors.white : const Color(0xFF536168),
          ),
        ),
      ),
    );
  }
}

class _GlassCard extends StatelessWidget {
  final Widget child;
  const _GlassCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(30),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 13, sigmaY: 13),
        child: Container(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 22),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.72),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: Colors.white.withOpacity(0.90), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.11),
                blurRadius: 30,
                offset: const Offset(0, 14),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class _GradientPrimaryButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onPressed;

  const _GradientPrimaryButton({required this.label, required this.icon, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(18),
        child: Ink(
          height: 54,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF2EB873), _loginGreenDark],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(color: _loginGreen.withOpacity(0.25), blurRadius: 14, offset: const Offset(0, 7)),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(label, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
              const SizedBox(width: 10),
              Icon(icon, color: Colors.white, size: 21),
            ],
          ),
        ),
      ),
    );
  }
}

class _OrDivider extends StatelessWidget {
  const _OrDivider();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Divider(color: const Color(0xFF94A09F).withOpacity(0.45))),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 12),
          child: Text('ou', style: TextStyle(color: Color(0xFF6E7A7C), fontWeight: FontWeight.w600)),
        ),
        Expanded(child: Divider(color: const Color(0xFF94A09F).withOpacity(0.45))),
      ],
    );
  }
}

class _Banner extends StatelessWidget {
  final String text;
  final Color background;
  final Color foreground;
  final IconData icon;
  const _Banner({required this.text, required this.background, required this.foreground, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: background.withOpacity(0.92),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.72)),
      ),
      child: Row(children: [
        Icon(icon, size: 18, color: foreground),
        const SizedBox(width: 8),
        Expanded(child: Text(text, style: TextStyle(color: foreground, fontWeight: FontWeight.w600, fontSize: 12.5))),
      ]),
    );
  }
}
