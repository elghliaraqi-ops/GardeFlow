import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/planning_entry.dart';
import '../models/shift_type.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';

enum _Mode { transfer, exchange }

class ExchangeRequestSheet extends StatefulWidget {
  final String dateStr;
  final PlanningEntry entry;
  const ExchangeRequestSheet({super.key, required this.dateStr, required this.entry});
  @override
  State<ExchangeRequestSheet> createState() => _ExchangeRequestSheetState();
}

class _ExchangeRequestSheetState extends State<ExchangeRequestSheet> {
  _Mode _mode = _Mode.transfer;
  String? _doctorId;
  String? _targetEntryId;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final shift = ShiftCatalog.byId(widget.entry.shiftId);
    final sourceIsService = widget.entry.shiftId.startsWith('service-');
    final exchangeMode = _mode == _Mode.exchange;
    final targets = state.exchangeTargets(sameServiceOnly: exchangeMode && sourceIsService);
    final dateLabel = DateFormat('EEEE d MMMM', 'fr_FR').format(DateTime.parse(widget.dateStr));
    final selectedDoctor = _doctorId == null ? null : targets.where((c) => c.id == _doctorId).firstOrNull;
    final allTargetEntries = selectedDoctor == null
        ? <PlanningEntry>[]
        : state.exchangeableEntriesFor(selectedDoctor.id, excludingDate: widget.dateStr);
    final targetEntries = selectedDoctor == null
        ? <PlanningEntry>[]
        : allTargetEntries.where((e) {
            if (!exchangeMode) return true;
            final targetIsService = e.shiftId.startsWith('service-');
            if (targetIsService && selectedDoctor.service != state.currentUser?.service) return false;
            return true;
          }).toList();
    final selectedTargetEntryId =
        _targetEntryId != null && targetEntries.any((e) => e.id == _targetEntryId) ? _targetEntryId : null;

    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.only(left: AppSpace.xl, right: AppSpace.xl, top: AppSpace.sm, bottom: MediaQuery.of(context).viewInsets.bottom + AppSpace.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Transfert / échange de garde', style: Theme.of(context).textTheme.displaySmall),
            const SizedBox(height: AppSpace.sm),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: AppSpace.md, vertical: AppSpace.sm),
              decoration: BoxDecoration(color: shift.color, borderRadius: AppRadius.smR),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(shift.icon, size: 15, color: shift.textColor),
                const SizedBox(width: AppSpace.xs),
                Text('$dateLabel · ${shift.label}', style: TextStyle(fontSize: 12.5, color: shift.textColor, fontWeight: FontWeight.w700)),
              ]),
            ),
            const SizedBox(height: AppSpace.lg),
            SegmentedButton<_Mode>(
              segments: const [
                ButtonSegment(value: _Mode.transfer, icon: Icon(Icons.arrow_forward_rounded, size: 16), label: Text('Transfert')),
                ButtonSegment(value: _Mode.exchange, icon: Icon(Icons.swap_horiz_rounded, size: 16), label: Text('Échange')),
              ],
              selected: {_mode},
              onSelectionChanged: (v) => setState(() {
                _mode = v.first;
                _targetEntryId = null;
                _error = null;
              }),
            ),
            const SizedBox(height: AppSpace.sm),
            _RuleNotice(
              text: _mode == _Mode.transfer
                  ? 'Transfert : vous donnez cette garde à un collègue du même hôpital. Il doit accepter, puis l’admin valide.'
                  : sourceIsService
                      ? 'Échange Service : uniquement avec un médecin de votre service. Si les deux gardes sont des gardes de Service, l’échange est appliqué dès l’acceptation du collègue, sans validation admin. Si une garde Urgences intervient, l’admin doit valider.'
                      : 'Échange Urgences : possible avec tout médecin du même hôpital et validation admin obligatoire. Une garde de Service ne peut être choisie que si le médecin appartient au même service que vous.',
              icon: _mode == _Mode.transfer
                  ? Icons.arrow_forward_rounded
                  : sourceIsService
                      ? Icons.groups_2_rounded
                      : Icons.local_hospital_rounded,
            ),
            const SizedBox(height: AppSpace.lg),
            if (targets.isEmpty)
              Text('Aucun autre médecin inscrit dans votre établissement.', style: Theme.of(context).textTheme.bodyMedium)
            else ...[
              DropdownButtonFormField<String>(
                value: selectedDoctor?.id,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Médecin destinataire'),
                items: targets.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name, overflow: TextOverflow.ellipsis))).toList(),
                onChanged: (v) => setState(() {
                  _doctorId = v;
                  _targetEntryId = null;
                  _error = null;
                }),
              ),
              if (_mode == _Mode.exchange && selectedDoctor != null) ...[
                const SizedBox(height: AppSpace.md),
                if (targetEntries.isEmpty)
                  Text('${selectedDoctor.name} n’a aucune garde disponible à échanger.', style: Theme.of(context).textTheme.bodySmall)
                else
                  DropdownButtonFormField<String>(
                    value: selectedTargetEntryId,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Garde reçue en échange'),
                    items: targetEntries.map((e) {
                      final sh = ShiftCatalog.byId(e.shiftId);
                      final d = DateFormat('EEE d MMM yyyy', 'fr_FR').format(DateTime.parse(e.dateStr));
                      return DropdownMenuItem(value: e.id, child: Text('$d · ${sh.label}', overflow: TextOverflow.ellipsis));
                    }).toList(),
                    onChanged: (v) => setState(() {
                      _targetEntryId = v;
                      _error = null;
                    }),
                  ),
              ],
            ],
            if (_error != null) ...[
              const SizedBox(height: AppSpace.sm),
              Row(children: [
                const Icon(Icons.error_rounded, size: 15, color: AppColors.danger),
                const SizedBox(width: 6),
                Expanded(child: Text(_error!, style: const TextStyle(color: AppColors.danger, fontSize: 12, fontWeight: FontWeight.w600))),
              ]),
            ],
            const SizedBox(height: AppSpace.lg),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: targets.isEmpty
                    ? null
                    : () async {
                        final doctor = _doctorId == null ? null : targets.where((c) => c.id == _doctorId).firstOrNull;
                        if (doctor == null) {
                          setState(() => _error = 'Sélectionnez un médecin destinataire.');
                          return;
                        }
                        String? err;
                        if (_mode == _Mode.transfer) {
                          err = await state.createTransferRequest(widget.dateStr, widget.entry, doctor);
                        } else {
                          final available = state.exchangeableEntriesFor(doctor.id, excludingDate: widget.dateStr).where((e) {
                            final targetIsService = e.shiftId.startsWith('service-');
                            if (targetIsService && doctor.service != state.currentUser?.service) return false;
                            return true;
                          }).toList();
                          if (available.isEmpty) {
                            setState(() => _error = '${doctor.name} n’a aucune garde compatible avec les règles d’échange.');
                            return;
                          }
                          final targetEntry = _targetEntryId == null ? null : available.where((e) => e.id == _targetEntryId).firstOrNull;
                          if (targetEntry == null) {
                            setState(() => _error = 'Sélectionnez la garde à recevoir en échange.');
                            return;
                          }
                          err = await state.createSwapRequest(widget.dateStr, widget.entry, doctor, targetEntry);
                        }
                        if (!mounted) return;
                        if (err != null) {
                          setState(() => _error = err);
                          return;
                        }
                        Navigator.of(context).pop();
                      },
                child: Text(_mode == _Mode.transfer ? 'Envoyer la demande de transfert' : 'Envoyer la demande d’échange'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _RuleNotice extends StatelessWidget {
  final String text;
  final IconData icon;
  const _RuleNotice({required this.text, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpace.md),
      decoration: BoxDecoration(
        color: AppColors.paperAlt,
        borderRadius: AppRadius.mdR,
        border: Border.all(color: AppColors.line),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: AppColors.brand),
          const SizedBox(width: AppSpace.sm),
          Expanded(child: Text(text, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.45))),
        ],
      ),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> { T? get firstOrNull => isEmpty ? null : first; }
