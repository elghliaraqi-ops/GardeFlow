import 'package:flutter/material.dart';
import '../services/push_notification_service.dart';
import 'package:provider/provider.dart';

import '../data/hospitals.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../theme/widgets.dart';
import 'auth_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const _presets = <int>[30, 60, 120, 720, 1440];

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final user = appState.currentUser;

    return Scaffold(
      backgroundColor: AppColors.paper,
      appBar: AppBar(title: const GardeFlowTitle('Réglages')),
      body: ListView(
        padding: const EdgeInsets.all(AppSpace.lg),
        children: [
          if (user != null)
            AppCard(
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: AppColors.paperAlt,
                    child: Text(
                      user.fullName.isEmpty ? '?' : user.fullName.trim()[0].toUpperCase(),
                      style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.ink),
                    ),
                  ),
                  const SizedBox(width: AppSpace.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user.fullName, style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 2),
                        Text('${user.gradeLabel} · ${user.roleLabel} · ${user.service} · ${hospitalDisplayName(user.hospital)}',
                            style: Theme.of(context).textTheme.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: AppSpace.sm),
          if (user != null)
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await appState.logout();
                  if (!context.mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const AuthScreen()),
                    (route) => false,
                  );
                },
                icon: const Icon(Icons.logout_rounded, size: 17, color: AppColors.danger),
                label: const Text('Déconnexion', style: TextStyle(color: AppColors.danger)),
                style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.line)),
              ),
            ),
          const SizedBox(height: AppSpace.xl),

          const SectionLabel('Notifications'),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: AppSpace.lg, vertical: AppSpace.xs),
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('Notifications et rappels', style: Theme.of(context).textTheme.titleMedium),
              subtitle: const Text('Échanges, congés et rappels avant les gardes', style: TextStyle(fontSize: 12)),
              value: appState.notificationsOn,
              onChanged: (v) {
                appState.notificationsOn = v;
                appState.rescheduleAllReminders();
              },
            ),
          ),
          const SizedBox(height: AppSpace.md),
          AppCard(
            padding: const EdgeInsets.all(AppSpace.md),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Container(
                    width: 32,
                    height: 32,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: AppColors.paperAlt, borderRadius: AppRadius.smR),
                    child: const Icon(Icons.notifications_active_rounded, size: 16, color: AppColors.ink),
                  ),
                  const SizedBox(width: AppSpace.sm),
                  Expanded(
                    child: ValueListenableBuilder<String>(
                      valueListenable: PushNotificationService.instance.status,
                      builder: (context, status, _) => Text(status, style: Theme.of(context).textTheme.bodySmall),
                    ),
                  ),
                ]),
                if (appState.notificationsOn && appState.backendEnabled) ...[
                  const SizedBox(height: AppSpace.sm),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: () async {
                        await PushNotificationService.instance.activateForSignedInUser();
                      },
                      child: const Text('Activer / réessayer les notifications push'),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: AppSpace.lg),
          Text('Délai de rappel avant la garde', style: Theme.of(context).textTheme.labelMedium),
          const SizedBox(height: AppSpace.sm),
          DropdownButtonFormField<int>(
            value: _presets.contains(appState.delayMinutes) ? appState.delayMinutes : _presets[1],
            isExpanded: true,
            items: const [
              DropdownMenuItem(value: 30, child: Text('30 minutes avant')),
              DropdownMenuItem(value: 60, child: Text('1 heure avant')),
              DropdownMenuItem(value: 120, child: Text('2 heures avant')),
              DropdownMenuItem(value: 720, child: Text('12 heures avant')),
              DropdownMenuItem(value: 1440, child: Text('La veille (24h avant)')),
            ],
            onChanged: (v) {
              if (v == null) return;
              appState.delayMinutes = v;
              appState.rescheduleAllReminders();
              setState(() {});
            },
          ),

          const SizedBox(height: AppSpace.xl),
          const SectionLabel('Synchronisation'),
          AppCard(
            child: Row(children: [
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: AppColors.paperAlt, borderRadius: AppRadius.smR),
                child: Icon(appState.backendEnabled ? Icons.cloud_done_rounded : Icons.cloud_off_rounded, size: 20, color: AppColors.ink),
              ),
              const SizedBox(width: AppSpace.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(appState.backendModeLabel, style: Theme.of(context).textTheme.titleSmall),
                    const SizedBox(height: 2),
                    Text(
                      appState.backendEnabled
                          ? 'Comptes, planning et transferts/échanges synchronisés avec Supabase.'
                          : 'Aucune clé Supabase fournie : fonctionnement local de démonstration.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              if (appState.backendEnabled) SoftIconButton(icon: Icons.sync_rounded, onTap: () => appState.refreshBackend(), size: 36, tooltip: 'Synchroniser'),
            ]),
          ),
          const SizedBox(height: AppSpace.md),
          Text(
            'Les rappels de notifications et les préférences restent locaux à chaque appareil. '
            'En mode Supabase, les données métier principales sont centralisées et sécurisées par RLS.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.6),
          ),
        ],
      ),
    );
  }
}
