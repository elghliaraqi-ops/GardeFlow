import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/app_user.dart';
import '../models/exchange_request.dart';
import '../models/leave_request.dart';
import '../models/reminder_notification.dart';
import '../models/shift_type.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../theme/widgets.dart';

class NotificationsScreen extends StatelessWidget {
  final int initialIndex;
  const NotificationsScreen({super.key, this.initialIndex = 0});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      initialIndex: initialIndex < 0 ? 0 : (initialIndex > 2 ? 2 : initialIndex),
      child: Scaffold(
        backgroundColor: AppColors.paper,
        appBar: AppBar(
          title: const GardeFlowTitle('Notifications'),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: AppSpace.sm),
              child: TextButton.icon(
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (dialogContext) => AlertDialog(
                      title: const Text('Nettoyer les notifications ?'),
                      content: const Text('Les rappels passés et les demandes déjà terminées seront masqués. Les transferts, échanges et congés encore à traiter restent visibles.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Nettoyer')),
                      ],
                    ),
                  );
                  if (ok == true && context.mounted) {
                    context.read<AppState>().clearReadAndPastNotifications();
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notifications lues et passées nettoyées.')));
                  }
                },
                icon: const Icon(Icons.cleaning_services_rounded, size: 17),
                label: const Text('Nettoyer'),
              ),
            ),
          ],
          bottom: const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [
              Tab(text: 'Rappels'),
              Tab(text: 'Transferts / Échanges'),
              Tab(text: 'Congés'),
            ],
          ),
        ),
        body: const TabBarView(children: [_RemindersTab(), _ExchangesTab(), _LeavesTab()]),
      ),
    );
  }
}

class _RemindersTab extends StatelessWidget {
  const _RemindersTab();

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final reminders = appState.reminders.toList()
      ..sort((a, b) => a.fireAt.compareTo(b.fireAt));

    if (reminders.isEmpty) {
      return const _EmptyState(
        icon: Icons.notifications_none_rounded,
        message: 'Aucun rappel de garde pour l’instant. Les rappels sont créés à partir des gardes des calendriers validés.',
      );
    }

    return Column(
      children: [
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.all(AppSpace.lg),
            itemCount: reminders.length,
            separatorBuilder: (_, __) => const SizedBox(height: AppSpace.sm),
            itemBuilder: (context, i) {
              final r = reminders[i];
              final sent = r.status == ReminderStatus.sent;
              return AppCard(
                padding: const EdgeInsets.all(AppSpace.md),
                child: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      margin: const EdgeInsets.only(right: AppSpace.md),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: sent ? AppColors.inkFaint : AppColors.catService,
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Rappel — ${r.label}', style: Theme.of(context).textTheme.titleSmall),
                          const SizedBox(height: 2),
                          Text(DateFormat('EEE d MMM · HH:mm', 'fr_FR').format(r.fireAt),
                              style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                    ),
                    Pill(
                      text: sent ? 'Envoyée' : 'À venir',
                      background: sent ? AppColors.paperAlt : AppColors.serviceJour,
                      foreground: sent ? AppColors.inkSoft : AppColors.serviceJourText,
                      fontSize: 10.5,
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(AppSpace.lg),
          child: SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: appState.clearSentReminders,
              child: const Text('Effacer les notifications envoyées'),
            ),
          ),
        ),
      ],
    );
  }
}

/// État vide partagé par les trois onglets.
class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String message;
  const _EmptyState({required this.icon, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 36, color: AppColors.inkFaint),
            const SizedBox(height: AppSpace.md),
            Text(message, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.inkSoft)),
          ],
        ),
      ),
    );
  }
}

class _ExchangesTab extends StatelessWidget {
  const _ExchangesTab();

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final me = appState.currentUser;
    if (me == null) return const SizedBox.shrink();

    final relevant = appState.exchanges.where((e) {
      if (appState.isNotificationDismissed('exchange:${e.id}')) return false;
      return me.role == UserRole.admin || e.fromId == me.id || e.toId == me.id || e.fromPhone == me.phone || e.toPhone == me.phone;
    }).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    if (relevant.isEmpty) {
      return const _EmptyState(
        icon: Icons.swap_horiz_rounded,
        message: 'Aucune demande de transfert ou d’échange pour l’instant.',
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(AppSpace.lg),
      itemCount: relevant.length,
      separatorBuilder: (_, __) => const SizedBox(height: AppSpace.sm),
      itemBuilder: (context, i) {
        final ex = relevant[i];
        final shift = ShiftCatalog.byId(ex.shiftId);
        final date = DateTime.parse(ex.dateStr);
        final dateLabel = DateFormat('EEE d MMM', 'fr_FR').format(date);
        final targetShift = ex.targetShiftId == null ? null : ShiftCatalog.byId(ex.targetShiftId!);
        final targetDateLabel = ex.targetDateStr == null ? null : DateFormat('EEE d MMM', 'fr_FR').format(DateTime.parse(ex.targetDateStr!));
        final requestLabel = ex.isTransfer ? 'Transfert' : 'Échange';

        final canRespondAsB = ex.status == ExchangeStatus.pendingB && (ex.toId == me.id || ex.toPhone == me.phone);
        final canRespondAsAdmin = ex.status == ExchangeStatus.pendingAdmin && me.role == UserRole.admin && ex.fromId != me.id && ex.toId != me.id && ex.fromPhone != me.phone && ex.toPhone != me.phone;
        final needsOtherAdmin = ex.status == ExchangeStatus.pendingAdmin && me.role == UserRole.admin && (ex.fromId == me.id || ex.toId == me.id || ex.fromPhone == me.phone || ex.toPhone == me.phone);

        return AppCard(
          padding: const EdgeInsets.all(AppSpace.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Pill(
                  text: requestLabel,
                  icon: ex.isTransfer ? Icons.arrow_forward_rounded : Icons.swap_horiz_rounded,
                  fontSize: 10,
                ),
                const SizedBox(width: AppSpace.sm),
                Expanded(child: Text('${ex.fromName} → ${ex.toName}', style: Theme.of(context).textTheme.titleSmall, overflow: TextOverflow.ellipsis)),
              ]),
              const SizedBox(height: AppSpace.sm),
              if (ex.isTransfer)
                Text('Garde transférée : $dateLabel · ${shift.label}', style: Theme.of(context).textTheme.bodySmall)
              else ...[
                Text('${ex.fromName} donne : $dateLabel · ${shift.label}', style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 2),
                Text('${ex.toName} donne : $targetDateLabel · ${targetShift?.label ?? ""}', style: Theme.of(context).textTheme.bodySmall),
              ],
              if (ex.isServiceExchange && ex.status == ExchangeStatus.pendingB) ...[
                const SizedBox(height: AppSpace.sm),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: AppSpace.sm, vertical: AppSpace.sm),
                  decoration: BoxDecoration(
                    color: AppColors.serviceJour.withOpacity(0.22),
                    borderRadius: AppRadius.smR,
                    border: Border.all(color: AppColors.catService.withOpacity(0.20)),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.flash_on_rounded, size: 16, color: AppColors.catService),
                      SizedBox(width: AppSpace.xs),
                      Expanded(
                        child: Text(
                          'Échange de gardes Service : l’acceptation applique immédiatement l’échange, sans validation administrateur.',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.inkSoft),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: AppSpace.md),
              if (canRespondAsB)
                Row(children: [
                  Expanded(child: _ActionButton(label: 'Accepter', color: AppColors.conge, textColor: AppColors.congeText, onTap: () async { final err = await appState.acceptExchange(ex.id); if (err != null && context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err))); })),
                  const SizedBox(width: AppSpace.sm),
                  Expanded(child: _ActionButton(label: 'Refuser', color: AppColors.urg24h, textColor: AppColors.urg24hText, onTap: () async { final err = await appState.declineExchange(ex.id); if (err != null && context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err))); })),
                ])
              else if (canRespondAsAdmin)
                Row(children: [
                  Expanded(child: _ActionButton(label: 'Approuver', color: AppColors.conge, textColor: AppColors.congeText, onTap: () async { final err = await appState.approveExchange(ex.id); if (err != null && context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err))); })),
                  const SizedBox(width: AppSpace.sm),
                  Expanded(child: _ActionButton(label: 'Rejeter', color: AppColors.urg24h, textColor: AppColors.urg24hText, onTap: () async { final err = await appState.rejectExchange(ex.id); if (err != null && context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err))); })),
                ])
              else if (ex.status == ExchangeStatus.pendingB && (ex.fromId == me.id || ex.fromPhone == me.phone))
                Row(
                  children: [
                    Expanded(child: Align(alignment: Alignment.centerLeft, child: _StatusPill(ex: ex))),
                    const SizedBox(width: AppSpace.sm),
                    TextButton(onPressed: () async { final err = await appState.cancelExchange(ex.id); if (err != null && context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err))); }, child: const Text('Annuler')),
                  ],
                )
              else ...[
                _StatusPill(ex: ex),
                if (needsOtherAdmin) ...[
                  const SizedBox(height: AppSpace.sm),
                  Text('Vous participez à cette demande : sa validation doit être effectuée par un autre administrateur.',
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ],
            ],
          ),
        );
      },
    );
  }
}


class _LeavesTab extends StatelessWidget {
  const _LeavesTab();

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final me = appState.currentUser;
    if (me == null) return const SizedBox.shrink();

    final relevant = appState.leaveRequests.where((r) =>
      !appState.isNotificationDismissed('leave:${r.id}') &&
      (me.role == UserRole.admin || r.ownerId == me.id || r.ownerPhone == me.phone)
    ).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    if (relevant.isEmpty) {
      return const _EmptyState(
        icon: Icons.beach_access_rounded,
        message: 'Aucune demande de congé pour l’instant.',
      );
    }

    if (me.role == UserRole.admin) {
      return _AdminLeavesGroupedList(requests: relevant);
    }

    return ListView.separated(
      padding: const EdgeInsets.all(AppSpace.lg),
      itemCount: relevant.length,
      separatorBuilder: (_, __) => const SizedBox(height: AppSpace.sm),
      itemBuilder: (context, i) => AppCard(
        padding: const EdgeInsets.all(AppSpace.md),
        child: _LeaveRequestRow(request: relevant[i]),
      ),
    );
  }
}

class _AdminLeavesGroupedList extends StatelessWidget {
  final List<LeaveRequest> requests;
  const _AdminLeavesGroupedList({required this.requests});

  @override
  Widget build(BuildContext context) {
    final grouped = <String, List<LeaveRequest>>{};
    for (final request in requests) {
      grouped.putIfAbsent(request.ownerPhone, () => <LeaveRequest>[]).add(request);
    }

    final groups = grouped.values.toList()
      ..sort((a, b) {
        final aPending = a.where((r) => r.status == LeaveRequestStatus.pendingAdmin).length;
        final bPending = b.where((r) => r.status == LeaveRequestStatus.pendingAdmin).length;
        if (aPending != bPending) return bPending.compareTo(aPending);
        return a.first.ownerName.toLowerCase().compareTo(b.first.ownerName.toLowerCase());
      });

    return ListView.separated(
      padding: const EdgeInsets.all(AppSpace.lg),
      itemCount: groups.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final doctorRequests = groups[index]
          ..sort((a, b) {
            final aPending = a.status == LeaveRequestStatus.pendingAdmin ? 0 : 1;
            final bPending = b.status == LeaveRequestStatus.pendingAdmin ? 0 : 1;
            if (aPending != bPending) return aPending.compareTo(bPending);
            return b.createdAt.compareTo(a.createdAt);
          });
        final doctorName = doctorRequests.first.ownerName;
        final pendingCount = doctorRequests.where((r) => r.status == LeaveRequestStatus.pendingAdmin).length;

        return Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            border: Border.all(color: AppColors.line),
            borderRadius: AppRadius.mdR,
            boxShadow: AppShadow.low,
          ),
          clipBehavior: Clip.antiAlias,
          child: ExpansionTile(
            initiallyExpanded: pendingCount > 0,
            shape: const Border(),
            collapsedShape: const Border(),
            tilePadding: const EdgeInsets.symmetric(horizontal: AppSpace.lg, vertical: AppSpace.xs),
            childrenPadding: const EdgeInsets.fromLTRB(AppSpace.lg, 0, AppSpace.lg, AppSpace.md),
            title: Text(doctorName, style: Theme.of(context).textTheme.titleMedium),
            subtitle: Text(
              '${doctorRequests.length} demande${doctorRequests.length > 1 ? 's' : ''} de congé',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            trailing: pendingCount > 0
                ? Pill(
                    text: '$pendingCount en attente',
                    background: AppColors.serviceJour,
                    foreground: AppColors.serviceJourText,
                    fontSize: 10.5,
                  )
                : const Icon(Icons.expand_more_rounded, color: AppColors.inkFaint),
            children: [
              for (var i = 0; i < doctorRequests.length; i++) ...[
                if (i > 0) const Divider(height: AppSpace.lg, color: AppColors.line),
                _LeaveRequestRow(request: doctorRequests[i], showOwnerName: false),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _LeaveRequestRow extends StatelessWidget {
  final LeaveRequest request;
  final bool showOwnerName;
  const _LeaveRequestRow({required this.request, this.showOwnerName = true});

  @override
  Widget build(BuildContext context) {
    final appState = context.read<AppState>();
    final me = appState.currentUser;
    if (me == null) return const SizedBox.shrink();

    final r = request;
    final startLabel = DateFormat('EEE d MMM yyyy', 'fr_FR').format(DateTime.parse(r.startDateStr));
    final endLabel = DateFormat('EEE d MMM yyyy', 'fr_FR').format(DateTime.parse(r.endDateStr));
    final dateLabel = r.isSingleDay ? startLabel : 'Du $startLabel au $endLabel';
    final conflicts = appState.leaveConflictingEntries(r);
    final canReview = me.role == UserRole.admin && r.status == LeaveRequestStatus.pendingAdmin && r.ownerId != me.id && r.ownerPhone != me.phone;
    final needsOtherAdmin = me.role == UserRole.admin && r.status == LeaveRequestStatus.pendingAdmin && (r.ownerId == me.id || r.ownerPhone == me.phone);
    final canCancel = (r.ownerId == me.id || r.ownerPhone == me.phone) && r.status == LeaveRequestStatus.pendingAdmin;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Pill(
            text: 'Congé',
            icon: Icons.beach_access_rounded,
            background: AppColors.conge,
            foreground: AppColors.congeText,
            fontSize: 10,
          ),
          if (showOwnerName) ...[
            const SizedBox(width: AppSpace.sm),
            Expanded(child: Text(r.ownerName, style: Theme.of(context).textTheme.titleSmall, overflow: TextOverflow.ellipsis)),
          ],
        ]),
        const SizedBox(height: AppSpace.sm),
        Text(dateLabel, style: Theme.of(context).textTheme.bodySmall),
        if (conflicts.isNotEmpty) ...[
          const SizedBox(height: AppSpace.sm),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(AppSpace.sm),
            decoration: BoxDecoration(color: AppColors.urgJour, borderRadius: AppRadius.smR),
            child: Row(children: [
              const Icon(Icons.warning_amber_rounded, size: 15, color: AppColors.urgJourText),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  '${conflicts.length} garde${conflicts.length > 1 ? 's' : ''} à couvrir avant approbation : ${conflicts.map((e) => DateFormat('dd/MM', 'fr_FR').format(DateTime.parse(e.dateStr))).join(', ')}',
                  style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: AppColors.urgJourText),
                ),
              ),
            ]),
          ),
        ],
        if (needsOtherAdmin) ...[
          const SizedBox(height: AppSpace.sm),
          Text('Votre propre congé doit être validé par un autre administrateur.', style: Theme.of(context).textTheme.bodySmall),
        ],
        const SizedBox(height: AppSpace.md),
        if (canReview)
          Row(children: [
            Expanded(child: _ActionButton(
              label: 'Approuver', color: AppColors.conge, textColor: AppColors.congeText,
              onTap: () async {
                final err = await appState.reviewLeave(r.id, true);
                if (err != null && context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
                }
              },
            )),
            const SizedBox(width: AppSpace.sm),
            Expanded(child: _ActionButton(
              label: 'Refuser', color: AppColors.urg24h, textColor: AppColors.urg24hText,
              onTap: () async {
                final err = await appState.reviewLeave(r.id, false);
                if (err != null && context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
                }
              },
            )),
          ])
        else
          Row(children: [
            Expanded(child: Align(alignment: Alignment.centerLeft, child: _LeaveStatusPill(request: r))),
            if (canCancel) ...[
              const SizedBox(width: AppSpace.sm),
              TextButton(
                onPressed: () async {
                  final err = await appState.cancelLeave(r.id);
                  if (err != null && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
                  }
                },
                child: const Text('Annuler'),
              ),
            ],
          ]),
      ],
    );
  }
}

class _LeaveStatusPill extends StatelessWidget {
  final LeaveRequest request;
  const _LeaveStatusPill({required this.request});

  @override
  Widget build(BuildContext context) {
    late String text;
    late Color bg;
    late Color fg;
    switch (request.status) {
      case LeaveRequestStatus.pendingAdmin:
        text = 'En attente de l’admin'; bg = AppColors.serviceJour; fg = AppColors.serviceJourText; break;
      case LeaveRequestStatus.approved:
        text = 'Congé approuvé'; bg = AppColors.conge; fg = AppColors.congeText; break;
      case LeaveRequestStatus.rejectedAdmin:
        text = 'Congé refusé'; bg = AppColors.urg24h; fg = AppColors.urg24hText; break;
      case LeaveRequestStatus.cancelled:
        text = 'Annulé'; bg = AppColors.paperAlt; fg = AppColors.inkSoft; break;
    }
    return Pill(text: text, background: bg, foreground: fg, fontSize: 10.5);
  }
}

class _ActionButton extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;
  final VoidCallback onTap;
  const _ActionButton({required this.label, required this.color, required this.textColor, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: textColor,
        elevation: 0,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.smR),
      ),
      child: Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
    );
  }
}

class _StatusPill extends StatelessWidget {
  final ExchangeRequest ex;
  const _StatusPill({required this.ex});

  @override
  Widget build(BuildContext context) {
    late String text;
    late Color bg;
    late Color fg;
    switch (ex.status) {
      case ExchangeStatus.pendingB:
        text = 'En attente de ${ex.toName}';
        bg = AppColors.serviceJour; fg = AppColors.serviceJourText;
        break;
      case ExchangeStatus.pendingAdmin:
        text = 'En attente de l\u2019admin';
        bg = AppColors.serviceJour; fg = AppColors.serviceJourText;
        break;
      case ExchangeStatus.approved:
        text = ex.isServiceExchange ? 'Accepté · appliqué' : 'Approuvé';
        bg = AppColors.conge; fg = AppColors.congeText;
        break;
      case ExchangeStatus.declinedB:
        text = 'Refusé par ${ex.toName}';
        bg = AppColors.urg24h; fg = AppColors.urg24hText;
        break;
      case ExchangeStatus.rejectedAdmin:
        text = 'Rejeté par l\u2019admin';
        bg = AppColors.urg24h; fg = AppColors.urg24hText;
        break;
      case ExchangeStatus.cancelled:
        text = 'Annulé';
        bg = AppColors.paperAlt; fg = AppColors.inkSoft;
        break;
    }
    return Pill(text: text, background: bg, foreground: fg, fontSize: 10.5);
  }
}
