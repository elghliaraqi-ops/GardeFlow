import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';

import '../models/app_user.dart';
import '../models/shared_resource.dart';
import '../services/supabase_backend_service.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../theme/widgets.dart';

class AstreinteScreen extends StatefulWidget {
  const AstreinteScreen({super.key});

  @override
  State<AstreinteScreen> createState() => _AstreinteScreenState();
}

class _AstreinteScreenState extends State<AstreinteScreen> {
  final _backend = SupabaseBackendService.instance;
  final Map<String, Uint8List> _imageCache = <String, Uint8List>{};
  List<SharedResource> _photos = const [];
  bool _loading = true;
  bool _uploading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!_backend.enabled || _backend.client.auth.currentUser == null) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Connexion Supabase requise pour afficher les astreintes partagées.';
        });
      }
      return;
    }
    try {
      final rows = await _backend.fetchAstreintePhotos();
      if (!mounted) return;
      setState(() {
        _photos = rows;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Impossible de charger les astreintes : $e';
      });
    }
  }

  Future<void> _pickImage() async {
    if (_uploading) return;
    final picker = ImagePicker();
    final action = await showModalBottomSheet<_AstreintePickAction>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!kIsWeb)
              ListTile(
                leading: const Icon(Icons.photo_camera_outlined),
                title: const Text('Prendre une photo'),
                onTap: () => Navigator.pop(ctx, _AstreintePickAction.camera),
              ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: Text(kIsWeb ? 'Choisir plusieurs images' : 'Choisir plusieurs photos'),
              subtitle: const Text('Sélection multiple, sans limite imposée par GardeFlow'),
              onTap: () => Navigator.pop(ctx, _AstreintePickAction.gallery),
            ),
          ],
        ),
      ),
    );
    if (action == null || !mounted) return;

    final files = <XFile>[];
    if (action == _AstreintePickAction.camera) {
      final file = await picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 70,
        maxWidth: 1600,
      );
      if (file != null) files.add(file);
    } else {
      final selected = await picker.pickMultiImage(
        imageQuality: 70,
        maxWidth: 1600,
      );
      files.addAll(selected);
    }

    if (files.isEmpty || !mounted) return;

    setState(() => _uploading = true);
    var uploaded = 0;
    var failed = 0;
    try {
      for (final file in files) {
        try {
          final bytes = await file.readAsBytes();
          final mime = file.mimeType ?? _mimeForName(file.name);
          await _backend.uploadAstreintePhoto(
            bytes: bytes,
            fileName: file.name,
            mimeType: mime,
          );
          uploaded++;
        } catch (_) {
          failed++;
        }
      }

      _imageCache.clear();
      await _load();
      if (mounted) {
        final message = failed == 0
            ? (uploaded == 1
                ? 'Photo d’astreinte publiée pour tous les utilisateurs.'
                : '$uploaded photos d’astreinte publiées pour tous les utilisateurs.')
            : '$uploaded photo${uploaded > 1 ? 's' : ''} publiée${uploaded > 1 ? 's' : ''}, $failed échec${failed > 1 ? 's' : ''}.';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<Uint8List> _bytesFor(SharedResource resource) async {
    final cached = _imageCache[resource.id];
    if (cached != null) return cached;
    final bytes = await _backend.downloadSharedResource(resource.storagePath);
    _imageCache[resource.id] = bytes;
    return bytes;
  }

  Future<void> _delete(SharedResource resource) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer cette photo ?'),
        content: const Text('Elle disparaîtra de la galerie d’astreinte pour tous les utilisateurs.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await _backend.deleteSharedResource(resource);
      _imageCache.remove(resource.id);
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Suppression impossible : $e')));
      }
    }
  }

  void _openPhoto(SharedResource resource) {
    final initialIndex = _photos.indexWhere((p) => p.id == resource.id);
    showDialog<void>(
      context: context,
      barrierColor: Colors.black,
      builder: (ctx) => Dialog.fullscreen(
        backgroundColor: Colors.black,
        child: _AstreinteGalleryViewer(
          photos: List<SharedResource>.unmodifiable(_photos),
          initialIndex: initialIndex < 0 ? 0 : initialIndex,
          backend: _backend,
          onClose: () => Navigator.pop(ctx),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = context.watch<AppState>().currentUser?.role == UserRole.admin;

    return Scaffold(
      backgroundColor: AppColors.paper,
      appBar: AppBar(
        title: const GardeFlowTitle('Médecins Séniors de Garde / Astreinte'),
        actions: [
          IconButton(
            tooltip: 'Actualiser',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh_rounded),
          ),
          if (isAdmin)
            IconButton(
              tooltip: 'Ajouter une photo',
              onPressed: _uploading ? null : _pickImage,
              icon: _uploading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.add_photo_alternate_rounded),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _ErrorState(message: _error!, onRetry: _load)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final columns = constraints.maxWidth >= 900 ? 4 : constraints.maxWidth >= 600 ? 3 : 2;
                      return GridView.builder(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.lg, AppSpace.lg, 100),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: columns,
                          mainAxisSpacing: AppSpace.md,
                          crossAxisSpacing: AppSpace.md,
                          childAspectRatio: 0.78,
                        ),
                        itemCount: _photos.length + (isAdmin ? 1 : 0),
                        itemBuilder: (context, i) {
                          if (isAdmin && i == 0) {
                            return _AdminAddTile(uploading: _uploading, onTap: _pickImage);
                          }
                          final photo = _photos[i - (isAdmin ? 1 : 0)];
                          return _AstreintePhotoCard(
                            resource: photo,
                            imageFuture: _bytesFor(photo),
                            canDelete: isAdmin,
                            onTap: () => _openPhoto(photo),
                            onDelete: () => _delete(photo),
                          );
                        },
                      );
                    },
                  ),
                ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.sm, AppSpace.lg, AppSpace.md),
          child: Text(
            isAdmin
                ? 'Galerie Supabase partagée. En tant qu’administrateur, vous seul pouvez ajouter ou supprimer les photos.'
                : 'Galerie partagée par l’administration. Les photos sont visibles par tous les utilisateurs.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.inkSoft, height: 1.4),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}


class _AstreinteGalleryViewer extends StatefulWidget {
  final List<SharedResource> photos;
  final int initialIndex;
  final SupabaseBackendService backend;
  final VoidCallback onClose;

  const _AstreinteGalleryViewer({
    required this.photos,
    required this.initialIndex,
    required this.backend,
    required this.onClose,
  });

  @override
  State<_AstreinteGalleryViewer> createState() => _AstreinteGalleryViewerState();
}

class _AstreinteGalleryViewerState extends State<_AstreinteGalleryViewer> {
  late final PageController _pageController;
  late final Future<List<String>> _urlsFuture;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
    _urlsFuture = Future.wait(
      widget.photos.map(
        (photo) => widget.backend.signedSharedResourceUrl(photo.storagePath, expiresIn: 3600),
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: FutureBuilder<List<String>>(
        future: _urlsFuture,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Stack(
              children: [
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Impossible de charger la galerie.',
                      style: TextStyle(color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                Positioned(top: 10, right: 10, child: _GalleryCloseButton(onClose: widget.onClose)),
              ],
            );
          }

          final urls = snapshot.data;
          if (urls == null) {
            return Stack(
              children: [
                const Center(child: CircularProgressIndicator()),
                Positioned(top: 10, right: 10, child: _GalleryCloseButton(onClose: widget.onClose)),
              ],
            );
          }

          return Stack(
            children: [
              Positioned.fill(
                child: PhotoViewGallery.builder(
                  pageController: _pageController,
                  itemCount: widget.photos.length,
                  scrollPhysics: const BouncingScrollPhysics(),
                  backgroundDecoration: const BoxDecoration(color: Colors.black),
                  loadingBuilder: (context, event) => const Center(child: CircularProgressIndicator()),
                  onPageChanged: (index) => setState(() => _currentIndex = index),
                  builder: (context, index) => PhotoViewGalleryPageOptions(
                    imageProvider: NetworkImage(urls[index]),
                    initialScale: PhotoViewComputedScale.contained,
                    minScale: PhotoViewComputedScale.contained,
                    maxScale: PhotoViewComputedScale.covered * 4.0,
                    heroAttributes: PhotoViewHeroAttributes(tag: 'astreinte-photo-${widget.photos[index].id}'),
                    errorBuilder: (context, error, stackTrace) => const Center(
                      child: Text('Image indisponible', style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 10,
                left: 16,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.58),
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: Text(
                    '${_currentIndex + 1} / ${widget.photos.length}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
              Positioned(top: 10, right: 10, child: _GalleryCloseButton(onClose: widget.onClose)),
              if (widget.photos.length > 1)
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: 14,
                  child: IgnorePointer(
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.58),
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: const Text(
                          'Glissez à gauche ou à droite • pincez pour zoomer',
                          style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _GalleryCloseButton extends StatelessWidget {
  final VoidCallback onClose;
  const _GalleryCloseButton({required this.onClose});

  @override
  Widget build(BuildContext context) {
    return IconButton.filled(
      onPressed: onClose,
      icon: const Icon(Icons.close_rounded),
    );
  }
}

class _AstreintePhotoCard extends StatelessWidget {
  final SharedResource resource;
  final Future<Uint8List> imageFuture;
  final bool canDelete;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _AstreintePhotoCard({
    required this.resource,
    required this.imageFuture,
    required this.canDelete,
    required this.onTap,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.card,
      borderRadius: AppRadius.lgR,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Stack(
          children: [
            Positioned.fill(
              child: FutureBuilder<Uint8List>(
                future: imageFuture,
                builder: (context, snap) {
                  if (snap.hasData) return Image.memory(snap.data!, fit: BoxFit.cover);
                  if (snap.hasError) {
                    return const Center(child: Icon(Icons.broken_image_outlined, color: AppColors.inkSoft));
                  }
                  return const Center(child: CircularProgressIndicator(strokeWidth: 2));
                },
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.fromLTRB(10, 28, 10, 9),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xC8000000)],
                  ),
                ),
                child: Text(
                  resource.displayName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700),
                ),
              ),
            ),
            if (canDelete)
              Positioned(
                top: 7,
                right: 7,
                child: IconButton.filled(
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Supprimer',
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline_rounded, size: 18),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _AdminAddTile extends StatelessWidget {
  final bool uploading;
  final VoidCallback onTap;
  const _AdminAddTile({required this.uploading, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.paperAlt,
      borderRadius: AppRadius.lgR,
      child: InkWell(
        borderRadius: AppRadius.lgR,
        onTap: uploading ? null : onTap,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: AppRadius.lgR,
            border: Border.all(color: AppColors.line, width: 1.4),
          ),
          alignment: Alignment.center,
          padding: const EdgeInsets.all(AppSpace.md),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (uploading)
                const CircularProgressIndicator(strokeWidth: 2)
              else
                const Icon(Icons.cloud_upload_outlined, size: 34, color: AppColors.catService),
              const SizedBox(height: 8),
              Text(uploading ? 'Envoi…' : 'Publier des photos', textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.ink)),
              const SizedBox(height: 4),
              const Text('Visible par tous', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 10.5, color: AppColors.inkSoft)),
            ],
          ),
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final Future<void> Function() onRetry;
  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpace.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 40, color: AppColors.inkSoft),
            const SizedBox(height: 10),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh_rounded), label: const Text('Réessayer')),
          ],
        ),
      ),
    );
  }
}

String _mimeForName(String name) {
  final lower = name.toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.webp')) return 'image/webp';
  return 'image/jpeg';
}

enum _AstreintePickAction { camera, gallery }
