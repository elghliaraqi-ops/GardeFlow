import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/hospitals.dart';
import '../models/directory_contact.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import '../theme/widgets.dart';

const String _kAllHospitals = 'all';

class DirectoryScreen extends StatefulWidget {
  const DirectoryScreen({super.key});

  @override
  State<DirectoryScreen> createState() => _DirectoryScreenState();
}

class _DirectoryScreenState extends State<DirectoryScreen> {
  String _query = '';
  String? _activeCategory;
  String? _activeHospital;

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final sections = appState.directory;
    _activeCategory ??= sections.first.id;
    if (_activeHospital == null) {
      final userHospital = appState.currentUser?.hospital;
      _activeHospital = userHospital != null && kHospitals.contains(userHospital)
          ? userHospital
          : _kAllHospitals;
    }

    final section = sections.firstWhere((s) => s.id == _activeCategory);
    final query = _query.trim().toLowerCase();
    final contacts = section.contacts.where((c) {
      final matchesSearch = query.isEmpty ||
          c.name.toLowerCase().contains(query) ||
          c.phone.contains(query);
      final matchesHospital = _activeHospital == _kAllHospitals || c.hospital == _activeHospital;
      return matchesSearch && matchesHospital;
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.paper,
      appBar: AppBar(title: const GardeFlowTitle('Annuaire téléphonique')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.md, AppSpace.lg, AppSpace.sm),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Rechercher un contact',
                prefixIcon: Icon(Icons.search_rounded, size: 20),
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpace.lg),
            child: DropdownButtonFormField<String>(
              value: _activeHospital,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Établissement'),
              items: [
                const DropdownMenuItem(value: _kAllHospitals, child: Text('Tous les établissements')),
                ...kHospitals.toSet().map((h) => DropdownMenuItem(
                      value: h,
                      child: Text(hospitalDisplayName(h), style: const TextStyle(fontSize: 12.5), overflow: TextOverflow.ellipsis),
                    )),
              ],
              onChanged: (v) => setState(() => _activeHospital = v),
            ),
          ),
          const SizedBox(height: AppSpace.xs),
          Expanded(
            child: contacts.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.person_search_rounded, size: 34, color: AppColors.inkFaint),
                        const SizedBox(height: AppSpace.sm),
                        Text('Aucun contact ne correspond à cet établissement / cette recherche.',
                            textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.inkSoft)),
                      ]),
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(AppSpace.lg, 0, AppSpace.lg, AppSpace.lg),
                    itemCount: contacts.length,
                    separatorBuilder: (_, __) => const SizedBox(height: AppSpace.sm),
                    itemBuilder: (context, i) => _ContactRow(contact: contacts[i], color: section.color, textColor: section.textColor),
                  ),
          ),
          _CategoryBar(
            activeId: _activeCategory!,
            onSelect: (id) => setState(() => _activeCategory = id),
          ),
        ],
      ),
    );
  }
}

class _ContactRow extends StatelessWidget {
  final DirectoryContact contact;
  final Color color;
  final Color textColor;
  const _ContactRow({required this.contact, required this.color, required this.textColor});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: AppRadius.mdR,
        onTap: () => launchUrl(Uri.parse('tel:${contact.phone}')),
        child: AppCard(
          padding: const EdgeInsets.symmetric(horizontal: AppSpace.md, vertical: AppSpace.sm),
          child: Row(children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: color,
              child: Text(contact.initials, style: TextStyle(color: textColor, fontWeight: FontWeight.w800, fontSize: 12.5)),
            ),
            const SizedBox(width: AppSpace.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(contact.name, style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 2),
                  Text(contact.phone, style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
            Container(
              width: 36,
              height: 36,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: AppColors.conge, shape: BoxShape.circle),
              child: const Icon(Icons.call_rounded, size: 16, color: AppColors.congeText),
            ),
          ]),
        ),
      ),
    );
  }
}

class _CategoryBar extends StatelessWidget {
  final String activeId;
  final ValueChanged<String> onSelect;
  const _CategoryBar({required this.activeId, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final sections = context.watch<AppState>().directory;
    return Container(
      padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.sm, AppSpace.lg, AppSpace.md),
      decoration: BoxDecoration(color: AppColors.card, border: const Border(top: BorderSide(color: AppColors.line)), boxShadow: AppShadow.mid),
      child: SizedBox(
        height: 40,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: sections.length,
          separatorBuilder: (_, __) => const SizedBox(width: AppSpace.sm),
          itemBuilder: (context, i) {
            final s = sections[i];
            final active = s.id == activeId;
            return GestureDetector(
              onTap: () => onSelect(s.id),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding: const EdgeInsets.symmetric(horizontal: 14),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: active ? s.color : AppColors.paperAlt,
                  borderRadius: AppRadius.pillR,
                  border: Border.all(color: active ? Colors.transparent : AppColors.line),
                ),
                child: Text(s.label,
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                      color: active ? s.textColor : AppColors.inkSoft,
                    )),
              ),
            );
          },
        ),
      ),
    );
  }
}
