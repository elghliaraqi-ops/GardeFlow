import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/audit_event.dart';
import '../services/supabase_backend_service.dart';
import '../theme/app_theme.dart';
import '../theme/widgets.dart';

class AuditScreen extends StatefulWidget {
  const AuditScreen({super.key});

  @override
  State<AuditScreen> createState() => _AuditScreenState();
}

class _AuditScreenState extends State<AuditScreen> {
  late Future<List<AuditEvent>> _future;

  @override
  void initState() {
    super.initState();
    _future = SupabaseBackendService.instance.fetchAudit();
  }

  void _refresh() => setState(() => _future = SupabaseBackendService.instance.fetchAudit());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.paper,
      appBar: AppBar(
        title: const GardeFlowTitle('Journal des actions'),
        actions: [SoftIconButton(icon: Icons.refresh_rounded, onTap: _refresh, tooltip: 'Actualiser')],
      ),
      body: FutureBuilder<List<AuditEvent>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
                child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text('Impossible de charger le journal : ${snapshot.error}', textAlign: TextAlign.center),
            ));
          }
          final events = snapshot.data ?? const <AuditEvent>[];
          if (events.isEmpty) {
            return Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.history_rounded, size: 34, color: AppColors.inkFaint),
              const SizedBox(height: AppSpace.sm),
              const Text('Aucune action enregistrée.', style: TextStyle(color: AppColors.inkSoft)),
            ]));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(AppSpace.lg),
            itemCount: events.length,
            separatorBuilder: (_, __) => const SizedBox(height: AppSpace.sm),
            itemBuilder: (context, i) {
              final e = events[i];
              return AppCard(
                padding: const EdgeInsets.all(AppSpace.md),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: AppColors.paperAlt, borderRadius: AppRadius.smR),
                      child: const Icon(Icons.history_rounded, size: 17, color: AppColors.ink),
                    ),
                    const SizedBox(width: AppSpace.md),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_actionLabel(e.action), style: Theme.of(context).textTheme.titleSmall),
                          const SizedBox(height: 4),
                          Text(
                            [
                              if (e.subjectName != null && e.subjectName!.isNotEmpty) e.subjectName!,
                              'Par ${e.actorName}',
                              if (e.reason != null && e.reason!.isNotEmpty) 'Motif : ${e.reason}',
                            ].join(' · '),
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            DateFormat('dd/MM/yyyy · HH:mm', 'fr_FR').format(e.createdAt.toLocal()),
                            style: Theme.of(context).textTheme.labelSmall,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

String _actionLabel(String action) {
  switch (action) {
    case 'planning.assigned': return 'Garde affectée / modifiée';
    case 'planning.deleted': return 'Affectation supprimée';
    case 'exchange.accepted': return 'Demande acceptée par le destinataire';
    case 'exchange.declined': return 'Demande refusée par le destinataire';
    case 'exchange.approved': return 'Échange / transfert approuvé';
    case 'exchange.rejected': return 'Échange / transfert rejeté';
    case 'exchange.cancelled': return 'Demande annulée';
    case 'leave.created': return 'Demande de congé créée';
    case 'leave.approved': return 'Congé approuvé';
    case 'leave.rejected': return 'Congé refusé';
    case 'leave.cancelled': return 'Demande de congé annulée';
    case 'account.approved': return 'Compte médecin validé';
    case 'account.suspended': return 'Compte médecin suspendu';
    default: return action;
  }
}
