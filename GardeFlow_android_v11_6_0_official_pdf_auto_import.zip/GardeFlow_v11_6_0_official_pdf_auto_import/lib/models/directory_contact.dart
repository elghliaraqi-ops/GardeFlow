import 'package:flutter/material.dart';

class DirectoryContact {
  final String id;
  final String name;
  final String phone;
  final String hospital;
  final String? service;
  final String? gradeLabel;
  final bool isAdmin;

  DirectoryContact({
    this.id = '',
    required this.name,
    required this.phone,
    required this.hospital,
    this.service,
    this.gradeLabel,
    this.isAdmin = false,
  });

  String get initials {
    final cleaned = name.replaceFirst(RegExp(r'^Dr\.\s*'), '').trim();
    final parts = cleaned.split(RegExp(r'\s+'));
    final first = parts.isNotEmpty && parts[0].isNotEmpty ? parts[0][0] : '';
    final second = parts.length > 1 && parts[1].isNotEmpty ? parts[1][0] : '';
    return (first + second).toUpperCase();
  }
}

class DirectorySection {
  final String id;
  final String label;
  final Color color;
  final Color textColor;
  final List<DirectoryContact> contacts;

  DirectorySection({
    required this.id,
    required this.label,
    required this.color,
    required this.textColor,
    required this.contacts,
  });
}
