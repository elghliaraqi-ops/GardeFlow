import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

/// Encapsule flutter_local_notifications pour planifier/annuler les rappels
/// de garde. Un id stable est dérivé de la clé de date ("yyyy-MM-dd") pour
/// pouvoir annuler précisément le rappel d'une garde donnée.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  void Function(String kind)? onPushTap;
  String? pendingPushKind;
  static const pushChannelId = 'huim6_push';

  Future<void> init() async {
    if (_initialized) return;
    if (kIsWeb) {
      _initialized = true;
      return;
    }
    tz_data.initializeTimeZones();

    const androidInit = AndroidInitializationSettings('ic_stat_huim6');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );
    const settings = InitializationSettings(android: androidInit, iOS: iosInit);

    await _plugin.initialize(settings, onDidReceiveNotificationResponse: (response) {
      final payload = response.payload;
      if (payload != null && payload.startsWith('push:')) {
        final kind = payload.substring(5);
        if (onPushTap != null) { onPushTap!(kind); } else { pendingPushKind = kind; }
      }
    });
    final launch = await _plugin.getNotificationAppLaunchDetails();
    final payload = launch?.notificationResponse?.payload;
    if (launch?.didNotificationLaunchApp == true && payload != null && payload.startsWith('push:')) {
      pendingPushKind = payload.substring(5);
    }
    await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(const AndroidNotificationChannel(
          pushChannelId, 'Échanges et congés',
          description: 'Demandes, validations et événements du planning',
          importance: Importance.high,
        ));
    _initialized = true;
  }

  Future<void> showPush({required String title, required String body, required String kind}) async {
    if (kIsWeb) return;
    await init();
    await _plugin.show(
      (DateTime.now().microsecondsSinceEpoch & 0x3fffffff) | 0x40000000,
      title, body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          pushChannelId, 'Échanges et congés',
          channelDescription: 'Demandes, validations et événements du planning',
          icon: 'ic_stat_huim6', importance: Importance.high, priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      payload: 'push:$kind',
    );
  }

  Future<void> requestPermission() async {
    if (kIsWeb) return;
    await _plugin
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(alert: true, badge: true, sound: true);
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  int _idFor(String ownerPhone, String dateStr) {
    // Stable entre deux exécutions, dans une plage distincte des push.
    var hash = 0;
    for (final unit in '$ownerPhone|$dateStr'.codeUnits) {
      hash = ((hash * 31) + unit) & 0x3fffffff;
    }
    return hash;
  }

  Future<void> scheduleReminder({
    required String ownerPhone,
    required String dateStr,
    required String title,
    required String body,
    required DateTime fireAt,
  }) async {
    if (kIsWeb) return;
    if (fireAt.isBefore(DateTime.now())) return; // dans le passé, on ignore (démo)

    try {
      await _plugin.zonedSchedule(
        _idFor(ownerPhone, dateStr),
        title,
        body,
        tz.TZDateTime.from(fireAt, tz.local),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'gardes_rappels',
            'Rappels de garde',
            channelDescription: 'Rappel avant le début d\'une garde planifiée',
            importance: Importance.high,
            priority: Priority.high,
          ),
          iOS: DarwinNotificationDetails(),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    } catch (e) {
      // Sur certains émulateurs/plateformes sans service de notifications disponible,
      // on log simplement plutôt que de faire planter l'app.
      debugPrint('Impossible de planifier la notification: $e');
    }
  }

  Future<void> cancelReminder(String ownerPhone, String dateStr) async {
    if (kIsWeb) return;
    await _plugin.cancel(_idFor(ownerPhone, dateStr));
  }

  Future<void> cancelAll() async {
    if (kIsWeb) return;
    await _plugin.cancelAll();
  }
}
