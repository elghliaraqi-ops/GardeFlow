import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Persistance locale multiplateforme (Web, Android, iOS, desktop).
/// Les données métier sont stockées sous forme JSON dans SharedPreferences.
class LocalStorageService {
  LocalStorageService._();
  static const _stateKey = 'huim6_state_v5';
  static const _sessionKey = 'huim6_session_phone_v5';

  static Future<Map<String, dynamic>?> loadState() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_stateKey);
    if (raw == null || raw.isEmpty) return null;
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  static Future<void> saveState(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_stateKey, jsonEncode(data));
  }

  static Future<String?> loadSessionPhone() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sessionKey);
  }

  static Future<void> saveSessionPhone(String? phone) async {
    final prefs = await SharedPreferences.getInstance();
    if (phone == null) {
      await prefs.remove(_sessionKey);
    } else {
      await prefs.setString(_sessionKey, phone);
    }
  }
}
