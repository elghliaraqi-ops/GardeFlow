import 'package:flutter/material.dart';
import 'app_theme.dart';

/// Carte de surface standard : fond blanc, hairline, ombre très douce.
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final Color? color;
  final List<BoxShadow>? shadow;
  final Border? border;

  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(AppSpace.lg),
    this.radius = AppRadius.md,
    this.color,
    this.shadow,
    this.border,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? AppColors.card,
        borderRadius: BorderRadius.circular(radius),
        border: border ?? Border.all(color: AppColors.line),
        boxShadow: shadow ?? AppShadow.low,
      ),
      child: child,
    );
  }
}

/// Bouton icône rond, cohérent avec le reste de l'app (remplace les
/// implémentations ad hoc dupliquées dans chaque écran).
class SoftIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final double size;
  final Color? background;
  final Color? foreground;
  final String? tooltip;

  const SoftIconButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.size = 38,
    this.background,
    this.foreground,
    this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    final button = InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: background ?? AppColors.card,
          border: Border.all(color: AppColors.line),
        ),
        child: Icon(icon, size: size * 0.5, color: foreground ?? AppColors.ink),
      ),
    );
    if (tooltip == null) return button;
    return Tooltip(message: tooltip!, child: button);
  }
}

/// Étiquette pilule (statut, catégorie...) sur fond neutre ou coloré.
class Pill extends StatelessWidget {
  final String text;
  final IconData? icon;
  final Color background;
  final Color foreground;
  final double fontSize;

  const Pill({
    super.key,
    required this.text,
    this.icon,
    this.background = AppColors.paperAlt,
    this.foreground = AppColors.inkSoft,
    this.fontSize = 11,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: background, borderRadius: AppRadius.pillR),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: fontSize + 3, color: foreground),
            const SizedBox(width: 5),
          ],
          Text(text, style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w700, color: foreground)),
        ],
      ),
    );
  }
}

/// En-tête de section discret (remplace les libellés tout-en-majuscules
/// génériques par une typographie de titre plus posée).
class SectionLabel extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionLabel(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpace.sm),
      child: Row(
        children: [
          Expanded(
            child: Text(text, style: Theme.of(context).textTheme.titleSmall),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// Barre d'application partagée : fine, sans élévation, cohérente partout.
PreferredSizeWidget appBarOf(BuildContext context, String title, {List<Widget>? actions}) {
  return AppBar(title: Text(title), actions: actions);
}

/// Identité commune des écrans GardeFlow.
class GardeFlowTitle extends StatelessWidget {
  final String section;
  const GardeFlowTitle(this.section, {super.key});

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text('GardeFlow', maxLines: 1, overflow: TextOverflow.ellipsis,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
      Text(section, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: Theme.of(context).textTheme.bodySmall),
    ],
  );
}

class GardeFlowLogo extends StatelessWidget {
  final double size;
  const GardeFlowLogo({super.key, this.size = 44});

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(size * 0.22),
    child: Image.asset('assets/branding/gardeflow_logo.png',
      width: size, height: size, fit: BoxFit.contain,
      semanticLabel: 'Logo GardeFlow'),
  );
}
