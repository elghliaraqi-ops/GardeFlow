import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// ---------------------------------------------------------------------
/// SYSTÈME DE DESIGN — HUIM6 Planning
/// ---------------------------------------------------------------------
/// Palette centrale de l'application.
/// Règle de code couleur (inchangée, c'est la grammaire fonctionnelle de
/// l'app) : la teinte encode la catégorie (bleu = Service, rouge/orange =
/// Urgences), la luminosité encode le moment (clair = jour, moyen = 24h,
/// foncé = nuit). Congé reste vert, à part.
///
/// Le reste (neutres, surfaces, ombres, typographie) a été repensé pour un
/// rendu plus contemporain : fond neutre froid, encre quasi-noire, cartes
/// nettes avec ombres très douces, coins sur une échelle cohérente.
class AppColors {
  AppColors._();

  // Neutres — fond de scène.
  static const paper = Color(0xFFF5F5F2); // fond global de l'app
  static const paperAlt = Color(0xFFEFEEE9); // recessed / tray
  static const ink = Color(0xFF13161A); // texte principal, quasi-noir froid
  static const inkSoft = Color(0xFF676F76); // texte secondaire
  static const inkFaint = Color(0xFF9AA0A6); // texte tertiaire / placeholders
  static const line = Color(0xFFE3E1DA); // hairlines
  static const card = Color(0xFFFFFFFF);

  // Accent de marque (chrome, focus, CTA neutres).
  static const brand = Color(0xFF2C4A73);
  static const brandSoft = Color(0xFFDEE8F5);

  // Sémantique métier — Service (bleu).
  static const serviceJour = Color(0xFF9CC0E8);
  static const serviceJourText = Color(0xFF0F3A63);
  static const service24h = Color(0xFF3D6EA8);
  static const service24hText = Color(0xFFEAF1FB);
  static const serviceNuit = Color(0xFF16294A);
  static const serviceNuitText = Color(0xFFC7D8F2);

  // Sémantique métier — Urgences (rouge/orange).
  static const urgJour = Color(0xFFF0B18E);
  static const urgJourText = Color(0xFF6B2E10);
  static const urg24h = Color(0xFFC1503B);
  static const urg24hText = Color(0xFFFCE9E4);
  static const urgNuit = Color(0xFF551616);
  static const urgNuitText = Color(0xFFF2CFCF);

  // Sémantique métier — Congé (vert).
  static const conge = Color(0xFF7FA582);
  static const congeText = Color(0xFF173420);

  static const catService = Color(0xFF3D6EA8);
  static const catUrgence = Color(0xFFC1503B);

  // États.
  static const danger = Color(0xFFB33F3F);
  static const success = Color(0xFF3F8A5C);
}

/// Échelle d'espacement — toujours multiple de 4.
class AppSpace {
  AppSpace._();
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const xxl = 28.0;
  static const xxxl = 40.0;
}

/// Échelle de rayons — cohérente sur toute l'app.
class AppRadius {
  AppRadius._();
  static const sm = 10.0;
  static const md = 16.0;
  static const lg = 22.0;
  static const xl = 28.0;
  static const pill = 999.0;

  static BorderRadius get smR => BorderRadius.circular(sm);
  static BorderRadius get mdR => BorderRadius.circular(md);
  static BorderRadius get lgR => BorderRadius.circular(lg);
  static BorderRadius get xlR => BorderRadius.circular(xl);
  static BorderRadius get pillR => BorderRadius.circular(pill);
}

/// Ombres — une seule échelle, très douce, jamais de gris lourd générique.
class AppShadow {
  AppShadow._();
  static List<BoxShadow> get low => [
        BoxShadow(color: AppColors.ink.withOpacity(0.045), blurRadius: 10, offset: const Offset(0, 3)),
      ];
  static List<BoxShadow> get mid => [
        BoxShadow(color: AppColors.ink.withOpacity(0.07), blurRadius: 20, offset: const Offset(0, 8)),
      ];
  static List<BoxShadow> get high => [
        BoxShadow(color: AppColors.ink.withOpacity(0.14), blurRadius: 32, offset: const Offset(0, 14)),
      ];
}

class AppTheme {
  AppTheme._();

  static ThemeData light() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: AppColors.brand,
      brightness: Brightness.light,
      surface: AppColors.paper,
      primary: AppColors.brand,
      error: AppColors.danger,
    );

    final base = ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.paper,
      colorScheme: colorScheme,
      splashFactory: InkSparkle.splashFactory,
      fontFamily: 'Inter',
    );

    const display = TextStyle(fontFamily: 'SpaceGrotesk', color: AppColors.ink, height: 1.05);

    final textTheme = base.textTheme.copyWith(
      displayLarge: display.copyWith(fontSize: 34, fontWeight: FontWeight.w600, letterSpacing: -0.6),
      displayMedium: display.copyWith(fontSize: 26, fontWeight: FontWeight.w600, letterSpacing: -0.4),
      displaySmall: display.copyWith(fontSize: 21, fontWeight: FontWeight.w600, letterSpacing: -0.2),
      titleLarge: display.copyWith(fontSize: 18, fontWeight: FontWeight.w600, height: 1.15),
      titleMedium: const TextStyle(fontFamily: 'Inter', fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.ink, height: 1.2),
      titleSmall: const TextStyle(fontFamily: 'Inter', fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.ink, height: 1.2),
      bodyLarge: const TextStyle(fontFamily: 'Inter', fontSize: 15, fontWeight: FontWeight.w500, color: AppColors.ink, height: 1.4),
      bodyMedium: const TextStyle(fontFamily: 'Inter', fontSize: 13, fontWeight: FontWeight.w500, color: AppColors.ink, height: 1.4),
      bodySmall: const TextStyle(fontFamily: 'Inter', fontSize: 11.5, fontWeight: FontWeight.w500, color: AppColors.inkSoft, height: 1.35),
      labelLarge: const TextStyle(fontFamily: 'Inter', fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.ink),
      labelMedium: const TextStyle(fontFamily: 'Inter', fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.inkSoft, letterSpacing: 0.2),
      labelSmall: const TextStyle(fontFamily: 'Inter', fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.inkSoft, letterSpacing: 0.3),
    );

    return base.copyWith(
      textTheme: textTheme,
      primaryTextTheme: textTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.paper,
        foregroundColor: AppColors.ink,
        elevation: 0,
        centerTitle: false,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: textTheme.titleLarge,
        systemOverlayStyle: SystemUiOverlayStyle.dark,
      ),
      dividerTheme: const DividerThemeData(color: AppColors.line, thickness: 1, space: 1),
      cardTheme: CardThemeData(
        color: AppColors.card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.mdR, side: const BorderSide(color: AppColors.line)),
        margin: EdgeInsets.zero,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.card,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        hintStyle: const TextStyle(color: AppColors.inkFaint, fontWeight: FontWeight.w500),
        labelStyle: const TextStyle(color: AppColors.inkSoft, fontWeight: FontWeight.w600),
        border: OutlineInputBorder(borderRadius: AppRadius.mdR, borderSide: const BorderSide(color: AppColors.line)),
        enabledBorder: OutlineInputBorder(borderRadius: AppRadius.mdR, borderSide: const BorderSide(color: AppColors.line)),
        focusedBorder: OutlineInputBorder(borderRadius: AppRadius.mdR, borderSide: const BorderSide(color: AppColors.ink, width: 1.6)),
        errorBorder: OutlineInputBorder(borderRadius: AppRadius.mdR, borderSide: const BorderSide(color: AppColors.danger)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.ink,
          foregroundColor: Colors.white,
          disabledBackgroundColor: AppColors.ink.withOpacity(0.3),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: AppRadius.mdR),
          textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 14.5),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.ink,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.mdR),
          textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 13.5),
        ).copyWith(
          backgroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.disabled)) return AppColors.line;
            return null;
          }),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.ink,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.smR),
          textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 13.5),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.ink,
          side: const BorderSide(color: AppColors.line, width: 1.4),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.mdR),
          textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 13.5),
        ),
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(
          backgroundColor: AppColors.card,
          foregroundColor: AppColors.ink,
          side: const BorderSide(color: AppColors.line),
          shape: const CircleBorder(),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.paperAlt,
        selectedColor: AppColors.ink,
        labelStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 11.5, color: AppColors.ink),
        secondaryLabelStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 11.5, color: Colors.white),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.pillR, side: const BorderSide(color: AppColors.line)),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: AppColors.card,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.lgR),
        titleTextStyle: textTheme.titleLarge,
        contentTextStyle: textTheme.bodyMedium,
        elevation: 0,
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: AppColors.card,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        showDragHandle: true,
        dragHandleColor: AppColors.line,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl))),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.ink,
        contentTextStyle: const TextStyle(fontFamily: 'Inter', color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.smR),
        insetPadding: const EdgeInsets.all(14),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: const WidgetStatePropertyAll(Colors.white),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return AppColors.ink;
          return AppColors.line;
        }),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(color: AppColors.ink),
      tabBarTheme: TabBarThemeData(
        labelColor: AppColors.ink,
        unselectedLabelColor: AppColors.inkFaint,
        indicatorColor: AppColors.ink,
        labelStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 13),
        dividerColor: Colors.transparent,
      ),
      listTileTheme: ListTileThemeData(
        shape: RoundedRectangleBorder(borderRadius: AppRadius.mdR),
        tileColor: AppColors.card,
      ),
    );
  }
}
