# Migration V11.1.6

Depuis V11.1.5, exécuter une seule fois dans **Supabase > SQL Editor** :

`supabase/patch_v11_1_6_admin_self_reopen.sql`

Aucune mise à jour de `send-push`, Firebase, VAPID ou `FCM_SERVICE_ACCOUNT_JSON` n’est nécessaire.
