# GardeFlow — Android + notifications push — V11.1.5

**Commencer par [DEMARRAGE_ANDROID.md](DEMARRAGE_ANDROID.md).**
Le guide ci-dessous est l’historique du projet ; pour Android, utiliser désormais
`tool/android.ps1`, qui configure Firebase, Gradle et les notifications.

# HUIM6 Planning des gardes — V5 consolidée

Application Flutter de planning des gardes : comptes médecins/admin, calendrier,
annuaire, gardes Service/Urgences, congés, échanges avec règles métier par type de garde,
photos d'astreinte, rappels et vue administrateur par médecin.

## Lancement

Cette archive contient le code applicatif. Si les dossiers `android/`, `ios/` et
`web/` ne sont pas encore présents, crée d'abord le squelette Flutter :

```powershell
flutter create --org com.huim6 .
flutter pub get
flutter run -d chrome
```

Pour préparer ensuite Android/iOS :

```powershell
powershell -ExecutionPolicy Bypass -File .\tool\configure_native.ps1
```

Puis relancer `flutter pub get`.

## Compte administrateur de démonstration

- Téléphone : `0600000090`
- Mot de passe initial : `HUIM6-Admin#2026`

Le mot de passe n'est pas stocké dans `AppUser` en clair : l'état persistant
conserve un hash SHA-256 salé. Pour une mise en production connectée à un
serveur, l'authentification devra naturellement être assurée côté backend.

## Corrections fonctionnelles de la V5

- **Persistance locale multiplateforme** : comptes, planning, rappels, échanges,
  paramètres et photos d'astreinte survivent à la fermeture/reprise de
  l'application grâce à `shared_preferences`.
- **Session restaurée** : le dernier compte connecté est restauré au redémarrage
  jusqu'à une déconnexion explicite.
- **Connexion** : l'établissement n'est plus demandé au login. Il est récupéré
  automatiquement depuis le compte. Le choix d'établissement existe uniquement
  à la création du compte.
- **Gardes individualisées** : plusieurs médecins peuvent avoir une affectation
  le même jour ; une modification ne touche que la garde du médecin concerné.
- **Notifications individualisées** : un compte ne voit et ne programme que ses
  propres rappels de garde. Les demandes d'échange admin restent séparées.
- **Échanges sécurisés métier** : une garde ne peut pas avoir deux demandes
  actives ; le destinataire ne peut pas accepter s'il a déjà une affectation ce
  jour-là ; l'admin revalide le conflit avant approbation ; une demande encore
  en attente du destinataire peut être annulée par son auteur.
- **Vue admin** : toutes les gardes sont regroupées par médecin, avec filtres et
  informations d'établissement/service.
- **Photos d'astreinte** : bytes persistants et galerie propre à chaque compte,
  compatible Web (plus de `dart:io/File`). Pour limiter le stockage navigateur,
  les images sont redimensionnées/compressées à la sélection et les 8 plus
  récentes par compte sont conservées.
- **Notifications natives** : demande de permission intégrée. Android utilise un
  mode d'alarme inexact afin de ne pas dépendre de `SCHEDULE_EXACT_ALARM`.
- **Permissions natives** : le script `tool/configure_native.ps1` ajoute CAMERA
  et POST_NOTIFICATIONS sur Android et les descriptions caméra/photothèque sur
  iOS après génération des plateformes.
- **Splash** : écran de démarrage complet sans asset manquant ; plus besoin de
  décommenter une image inexistante pour que l'écran soit correct.

## Important : persistance locale vs serveur

La V5 est désormais réellement persistante **sur l'appareil/navigateur qui
l'exécute**. Elle peut donc être testée correctement avec plusieurs comptes dans
le même navigateur. En revanche, deux téléphones/ordinateurs différents ne
partagent pas encore automatiquement leur base locale.

Pour un déploiement hospitalier multi-appareils, l'étape suivante n'est pas une
correction de bug mais un changement d'infrastructure : brancher le dépôt de
données sur Firebase/Supabase ou une API REST + PostgreSQL. La logique métier
V5 (propriétaire de garde, échanges, conflits, rôles) est déjà structurée pour
être déplacée vers ce backend.

## Planning personnel de l’administrateur

Le compte administrateur possède également un planning personnel. Il peut déposer
Service, Urgences ou Congé (Jour, Nuit, 24 h) sur son propre calendrier exactement
comme un médecin. Ses rappels de garde restent privés à son compte. La vue
« Admin — toutes les gardes » est une vue supplémentaire de supervision et ne
remplace pas son planning personnel.


### Vue administrateur — calendrier par médecin (V7)
Dans « Vue Admin — gardes par médecin », l'administrateur choisit d'abord un établissement, puis un médecin appartenant à cet établissement. Le calendrier mensuel du médecin sélectionné affiche ensuite toutes ses affectations (Service, Urgences, Congé) avec le même code couleur que le planning personnel. L'administrateur, qui possède également son propre planning, apparaît dans la sélection lorsque « Tous les établissements » est choisi.

Le bouton précédemment nommé « Astreinte » porte désormais le libellé « Médecins Séniors de Garde / Astreinte ».


## V8 — Transferts et échanges de gardes

Deux workflows distincts sont désormais disponibles depuis l'icône ↔ d'une garde :

- **Transfert** : le propriétaire donne une garde à un autre médecin. Le destinataire accepte/refuse, puis l'administrateur approuve/rejette. Après approbation, une seule garde change de propriétaire.
- **Échange** : le propriétaire choisit un médecin puis une garde précise de ce médecin. Le destinataire accepte/refuse, puis l'administrateur approuve/rejette. Après approbation, les deux gardes permutent de propriétaire.

Les demandes sont visibles dans **Notifications > Transferts / Échanges**. L'administrateur voit toutes les demandes, y compris celles encore en attente du médecin et l'historique. Les boutons d'approbation admin n'apparaissent qu'après acceptation du destinataire.

Contrôles : une garde engagée dans une demande active est verrouillée ; une même garde ne peut pas être utilisée dans deux demandes ; les conflits de planning sont vérifiés à la création, à l'acceptation et à l'approbation admin ; les rappels suivent les nouveaux propriétaires après validation.

## V9 — Backend Supabase

La V9 ajoute un vrai backend multi-appareils pour les comptes, profils, gardes, transferts et échanges.

Le backend est activé uniquement quand l'application est lancée avec :

```powershell
flutter run -d chrome --dart-define=SUPABASE_URL=https://VOTRE-PROJET.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=VOTRE_CLE_PUBLIQUE
```

Installation détaillée : `supabase/README_SETUP.md`.
Schéma SQL/RLS/RPC : `supabase/schema.sql`.

Les règles critiques ne sont plus seulement côté Flutter : même établissement obligatoire, garde verrouillée pendant une demande, réponse réservée au destinataire, approbation réservée à l'admin et permutation transactionnelle des deux gardes pour un échange.

Les rappels locaux restent sur chaque appareil. Les photos d'astreinte sont encore locales en V9 et seront migrées vers Supabase Storage séparément.

## V9.4 — Supabase préconfiguré

Le projet HUIM6 Supabase est désormais configuré par défaut dans `lib/config/backend_config.dart`.

Lancement normal :

```powershell
flutter run -d chrome
```

Il n'est plus nécessaire de répéter l'URL et la publishable key à chaque lancement.

Les variables `--dart-define` restent prioritaires si vous souhaitez ponctuellement lancer l'application contre un autre projet Supabase :

```powershell
flutter run -d chrome --dart-define=SUPABASE_URL=https://AUTRE-PROJET.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=AUTRE_CLE_PUBLIQUE
```

La clé embarquée est une **publishable key**, conçue pour les applications clientes. Ne jamais embarquer une `service_role` key.

### Plusieurs sessions de test

Plusieurs lancements Chrome peuvent être utilisés pour tester différents médecins. Chaque serveur de développement Flutter utilise généralement une origine/port distinct, ce qui permet aux stockages de session web d'être séparés. Si deux fenêtres partagent exactement la même origine, la session Supabase peut également être partagée ; dans ce cas utilisez un autre profil Chrome, une fenêtre privée, ou un autre lancement Flutter sur un port différent.


## V9.5 — échanges le même jour

Les échanges peuvent désormais porter sur deux gardes de la même date, par exemple une garde **Jour** de Hind contre une garde **Nuit** de Lina le 26 septembre.

Pour un projet Supabase déjà installé avec une V9 antérieure, exécuter **une fois** `supabase/patch_v9_5_same_day_exchange.sql` dans **Supabase > SQL Editor**.


## V9.6 — suppression des gardes par l'administrateur

Depuis la **Vue Admin — gardes par médecin**, une icône de suppression apparaît sur chaque garde. L'admin peut supprimer toute affectation, y compris une garde transférée ou échangée.

Pour un projet Supabase déjà installé, exécuter une seule fois `supabase/patch_v9_6_admin_delete.sql` dans le SQL Editor. Les suppressions sont archivées avec `deleted_at` afin de conserver l'historique des transferts/échanges.

## V9.7 — Validation administrative des congés

Le dépôt de `Congé` crée désormais une demande à valider par l'administrateur au lieu d'insérer immédiatement un congé définitif.

Flux :

```text
Médecin pose Congé
      ↓
En attente admin
      ↓
Admin : Approuver / Refuser
      ↓
Approuvé → Congé ajouté au planning
Refusé   → aucune modification du planning
```

L'administrateur retrouve les demandes dans `Notifications > Congés`. Un congé déjà approuvé peut ensuite être supprimé depuis `Vue Admin — gardes par médecin`, comme n'importe quelle autre affectation.

### Mise à jour depuis V9.5

Si `patch_v9_6_admin_delete.sql` n'a pas encore été exécuté, ne l'exécutez pas séparément. Exécutez uniquement :

`supabase/patch_v9_7_leave_approval_and_admin_delete.sql`

Ce patch contient aussi les changements V9.6.


## V9.7.2 — Admin participant aux transferts/échanges

Les comptes `admin` sont inclus dans la liste des destinataires de transferts et d'échanges au même titre que les médecins, sous réserve d'appartenir au même établissement.

## V9.8 — Notifications push Firebase Cloud Messaging

La V9.8 ajoute les notifications push Web via Firebase Cloud Messaging (FCM) pour :
- nouvelle demande de transfert ou d'échange ;
- acceptation/refus du médecin destinataire ;
- demande en attente de validation administrateur ;
- approbation/refus administrateur ;
- nouvelle demande de congé ;
- congé approuvé/refusé ;
- suppression admin d'une garde ou d'un congé.

La configuration Firebase Web et la clé VAPID publique du projet `planninghm6` sont déjà intégrées côté client. Les secrets Firebase privés ne sont jamais embarqués dans Flutter.

### 1. Base Supabase

Exécuter une fois `supabase/patch_v9_8_push_notifications.sql` dans **Supabase > SQL Editor**.

### 2. Secret Firebase côté Supabase

Dans Firebase : **Project settings > Service accounts > Generate new private key**. Conserver le fichier JSON en lieu sûr et ne jamais le mettre dans Flutter ni Git.

Dans Supabase : **Edge Functions > Secrets**, créer :

`FCM_SERVICE_ACCOUNT_JSON`

et coller comme valeur le contenu complet du JSON du compte de service Firebase.

### 3. Edge Function

Créer/déployer une fonction nommée exactement `send-push` depuis **Supabase > Edge Functions > Deploy a new function > Via Editor**, en utilisant le fichier :

`supabase/functions/send-push/index.ts`

La fonction valide l'utilisateur connecté, détermine elle-même les vrais destinataires à partir de Supabase puis appelle l'API FCM HTTP v1. Le client Flutter ne choisit donc pas arbitrairement les numéros à notifier.

### 4. Web service worker

Le fichier `web/firebase-messaging-sw.js` doit être présent à la racine Web de l'application. Il affiche les notifications lorsque HUIM6 est en arrière-plan.

Sur Chrome, le navigateur demandera l'autorisation d'afficher les notifications lors de la connexion. Le push Web nécessite un contexte sécurisé HTTPS ; `localhost` est accepté pour le développement.

### 5. Lancement

```powershell
flutter clean
flutter pub get
flutter run -d chrome
```

Les rappels horaires de gardes restent des notifications locales programmées sur l'appareil ; FCM est utilisé pour les événements collaboratifs et administratifs.


## V9.8.2 — échange entre dates différentes
Après une installation V9.7/V9.8 existante, exécuter `supabase/patch_v9_8_2_cross_date_exchange.sql` une fois dans le SQL Editor Supabase.

## V10.2 — concept final : tuiles + validation définitive par le médecin

Le médecin construit son propre calendrier mensuel en déposant les tuiles **Service Jour / 24H / Nuit**, **Urgences Jour / 24H / Nuit** et **Congé**. Tant que le mois n'est pas validé, il peut déplacer/remplacer/retirer ses tuiles.

Le bouton **Valider** fige ensuite le calendrier **définitivement** : il n'existe aucun retour en brouillon. Après validation, le médecin ne peut plus modifier directement ses gardes. Il peut seulement utiliser les workflows de **transfert** ou **échange** ; une garde validée ne peut être supprimée que par un administrateur.

Les tuiles **Congé** sont transformées automatiquement en demandes de congé au moment de la validation du mois. L'admin approuve ou refuse ces congés. Un refus retire uniquement les tuiles Congé concernées et ne rouvre jamais le calendrier.

L'administrateur ne valide **pas** les calendriers mensuels. Dans le planning, ses validations concernent uniquement **transferts, échanges et congés**. Sa vue calendrier est en lecture seule, à l'exception de la suppression d'une garde/congé déjà validé avec motif obligatoire.

Le statut **Admin** est totalement indépendant du grade médical : **Junior** et **Senior** sont purement informatifs. Un médecin **Junior + Admin** possède exactement les mêmes permissions administratives qu'un médecin Senior + Admin.

L'écran **Notifications** possède un bouton **Nettoyer** qui supprime les rappels passés de l'appareil et masque les transferts/échanges/congés terminés pour le compte courant, sans supprimer l'historique métier Supabase. Les demandes encore à traiter restent visibles.

### Mise à jour depuis V10 / V10.0.1

Exécuter une seule fois dans le SQL Editor :

`supabase/patch_v10_2_self_validation_tiles_notifications.sql`

Ce patch est cumulatif par rapport à V10 : **ne lancez pas `patch_v10_1_tiles_calendar_validation.sql` avant**. S'il avait déjà été exécuté, le patch V10.2 sait aussi convertir les anciens états `submitted/rejected` vers le nouveau fonctionnement.

Aucune modification du secret Firebase/FCM n'est nécessaire pour cette mise à jour.

## V10.3 — dévalidation admin + tuiles agrandies

La V10.3 conserve le principe V10.2 : le médecin construit son propre calendrier avec les tuiles puis le valide lui-même. Un administrateur peut désormais **dévalider / rouvrir le calendrier validé d’un autre médecin** lorsqu’une correction est nécessaire. Ce droit dépend uniquement de `profiles.role='admin'` et jamais du grade Junior/Senior.

Après dévalidation, le médecin peut modifier les gardes futures du mois puis doit valider le calendrier à nouveau. Les demandes de transfert/échange encore actives sur ce mois sont annulées. Les congés encore en attente sont annulés puis seront recréés à la prochaine validation. Un congé déjà approuvé reste protégé et nécessite une suppression administrateur explicite.

Pour migrer depuis V10.2, exécuter uniquement :

```text
supabase/patch_v10_3_admin_reopen_and_tile_ui.sql
```

La Edge Function `send-push` ne change pas en V10.3.


## V11.1.6 — dévalidation de son propre calendrier par un admin

Un utilisateur ayant `role='admin'` peut désormais dévalider son propre calendrier validé depuis la Vue Admin. Le mois repasse en brouillon et redevient modifiable dans **Mon planning**, puis doit être validé à nouveau. Le grade Junior/Senior ne change toujours aucun droit. Le motif de dévalidation reste obligatoire et l’action est auditée.

Migration : `supabase/patch_v11_1_6_admin_self_reopen.sql`. Aucune mise à jour de la Edge Function n’est nécessaire.


## V11.1.7 — Vue Admin calendrier sans défilement horizontal

Le calendrier du médecin sélectionné dans la Vue Admin tient désormais entièrement dans la largeur disponible avec ses 7 colonnes visibles en même temps, comme le calendrier principal. Aucun changement Supabase n’est requis.

## V11.2.0 — Splash & connexion institutionnels

Le splash et l'écran de connexion utilisent désormais l'identité visuelle GardeFlow avec les logos HUI Mohammed VI Rabat, HUI Cheikh Khalifa, HUI Mohammed VI Bouskoura et AMIUM6. La photo des Urgences devient l'arrière-plan de la connexion avec un flou progressif animé au chargement. Aucune migration Supabase n'est nécessaire pour cette mise à jour.

## V11.2.1 — identité GardeFlow
Le nouveau logo GardeFlow est utilisé dans l'application, le launcher Android, le favicon Web et les icônes PWA. La procédure `BUILD_APK_RELEASE.ps1` conserve ces ressources lors de la régénération Android.

## V11.3.0 — Astreintes partagées et Planning de Garde Officiel

Les photos de **Médecins Séniors de Garde / Astreinte** sont désormais stockées dans Supabase Storage et partagées entre tous les utilisateurs connectés. Seuls les administrateurs peuvent les publier ou les supprimer.

Un nouvel accès **Planning de Garde Officiel** est visible par tous dans la barre supérieure. L'administration peut y publier/remplacer trois PDF : **HM6 Bouskoura**, **HM6 Rabat** et **HCK Casa**. Tous les utilisateurs peuvent ouvrir le dernier document publié.

Pour une base Supabase existante, exécuter une fois :
`supabase/patch_v11_3_0_shared_astreinte_official_pdfs.sql`.


## V11.3.1 — correctif compilation Android
Voir `CORRECTIF_BUILD_ANDROID_V11_3_1.md`.

## V11.4.0 — iPhone / iOS

Le projet est maintenant préparé pour iOS. Voir `IOS_SETUP.md`.

Sur macOS :

```bash
./tool/ios.sh Prepare
./BUILD_IOS_UNSIGNED.sh
# ou, après configuration de la signature Apple :
./BUILD_IOS_IPA.sh
```

Bundle ID iOS : `com.huim6.gardeflow`.

## V11.5.0 — Juniors d’astreinte

Avant d’utiliser la nouvelle page réseau, exécuter une seule fois dans Supabase SQL Editor :

`supabase/patch_v11_5_0_junior_oncall_roster.sql`

Cette fonction expose uniquement les gardes de Service validées des médecins Juniors nécessaires à la nouvelle page.

## V11.6.0 — Transposition automatique des plannings Urgences

Après application de `PATCH_SUPABASE_V11_6_0_OFFICIAL_PDF_AUTO_IMPORT.sql`, les PDF du bouton **Planning de Garde Officiel** sont analysés automatiquement par l'application. Les cases 08h–20h, 20h–08h et les grandes cases 24H sont converties respectivement en `urg-jour`, `urg-nuit` et `urg-24h` dans les calendriers individuels des médecins reconnus.

Les PDF déjà stockés dans Supabase sont repris automatiquement au premier passage d'un administrateur sur cette page ; aucun nouvel upload n'est requis.
