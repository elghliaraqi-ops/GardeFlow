# HUIM6 Planning V9 — Backend Supabase

- Ajout de `supabase_flutter`.
- Initialisation conditionnelle via `SUPABASE_URL` + `SUPABASE_PUBLISHABLE_KEY`.
- Conservation automatique du mode local si les clés ne sont pas fournies.
- Authentification Supabase par téléphone + mot de passe.
- Numéros marocains normalisés en E.164 (`+212...`).
- Profils centralisés dans PostgreSQL.
- Planning synchronisé avec PostgreSQL.
- Transferts et échanges synchronisés avec PostgreSQL.
- Realtime sur planning et demandes.
- RLS par établissement : les médecins ne travaillent qu'avec leur établissement.
- Admin réseau : visibilité globale et validation finale.
- Validation transfert/échange via fonctions PostgreSQL `security definer`.
- Échange de deux gardes effectué de manière transactionnelle.
- Verrouillage serveur d'une garde liée à une demande active.
- Contrôles serveur contre les conflits de planning et les échanges inter-établissements.
- Écran Paramètres : indication `Supabase connecté` / `Mode local` et bouton de synchronisation.
- SQL prêt à exécuter dans `supabase/schema.sql`.

À suivre : migration des photos d'astreinte vers Supabase Storage et écran OTP si la confirmation téléphone est activée en production.
