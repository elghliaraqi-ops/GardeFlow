# Migration vers GardeFlow 11.1.4

1. Dans Supabase → SQL Editor, exécuter une seule fois :
   `supabase/patch_v11_1_4_service_exchange_no_admin.sql`
2. Dans Supabase → Edge Functions → `send-push`, remplacer le code par :
   `supabase/functions/send-push/index.ts`
   puis **Deploy / Update**.
3. Aucun changement Firebase / VAPID / secret `FCM_SERVICE_ACCOUNT_JSON`.

Le patch ne touche pas aux gardes existantes. Il modifie uniquement le traitement d’une acceptation d’échange Service ↔ Service.
