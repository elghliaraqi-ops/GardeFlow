# GardeFlow V11.4.1 — Visualisation des plannings officiels

## Planning de Garde Officiel
- Le bouton et l’écran **Planning de Garde Officiel** déjà existants sont conservés.
- Le système d’upload/remplacement/suppression PDF existant est conservé tel quel.
- Aucun second espace PDF n’est ajouté dans Astreinte.
- Les PDF s’ouvrent désormais **directement dans GardeFlow**.
- Tous les utilisateurs connectés peuvent consulter les PDF publiés.
- Zoom tactile par pincement, avec boutons `+` / `−` dans la barre supérieure.
- La gestion des PDF (publier, remplacer, retirer) reste réservée aux administrateurs.

## Astreinte
- La galerie Astreinte reste dédiée uniquement aux photos.
- Ajout et suppression réservés aux administrateurs.
- Tous les médecins peuvent consulter et zoomer les photos.
- Sélection multiple conservée, sans limite imposée par GardeFlow.
- Compression avant envoi conservée : qualité 70 %, largeur maximale 1600 px.

## Backend
- Aucun nouveau patch Supabase n’est requis si le système `shared_resources` / `gardeflow-shared` de la V11.3.0 est déjà installé et fonctionnel.
- Aucun changement Firebase ou `send-push`.

Version : `11.4.1+141`.

## V11.4.3 - correctif build Android resources
- Restauration explicite des themes Android et du launch background.
- Verification pre-build des ressources Android critiques.
- Retry automatique apres nettoyage des caches Gradle de transformation en cas d echec AAPT.
