# GardeFlow V11.5.0

- Retrait de la liste des services : Proctologie, Unité obstétricale, Néonatologie, Néphropédiatrie, PMA et Trauma Center.
- Le bouton `Astreinte` devient `Séniors d’astreinte` ; la page existante reste inchangée.
- Nouveau bouton `Juniors d’astreinte` dans les accès rapides.
- Nouvelle vue mensuelle en lecture seule des gardes de Service des Juniors, regroupées par date, établissement puis service.
- Seuls les calendriers validés apparaissent dans cette vue.
- Nouveau RPC Supabase `junior_oncall_roster` pour une vue réseau limitée à ces données.
- Patch à appliquer : `supabase/patch_v11_5_0_junior_oncall_roster.sql`.
