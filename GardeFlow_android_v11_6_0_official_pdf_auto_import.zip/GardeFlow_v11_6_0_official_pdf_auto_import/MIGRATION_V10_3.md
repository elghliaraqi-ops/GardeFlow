# Migration V10.2 → V10.3

1. Conserver la base Supabase existante.
2. Ouvrir **Supabase → SQL Editor → New query**.
3. Exécuter intégralement :
   `supabase/patch_v10_3_admin_reopen_and_tile_ui.sql`
4. Ne pas rejouer les anciens patches V10.1/V10.2.
5. La fonction Edge `send-push` ne change pas en V10.3.
6. Relancer l’application avec la V10.3.

### Test conseillé
- Médecin A valide son mois.
- Admin B ouvre **Vue Admin — gardes par médecin**, sélectionne A puis le mois.
- Cliquer **Dévalider**, saisir un motif.
- A voit le mois rouvert et peut modifier ses tuiles futures, puis le valider à nouveau.
- Vérifier qu’un congé déjà approuvé reste non modifiable par A.
