# V9.8.1 — correction sélection échange

- Corrige l'assertion Flutter du `DropdownButtonFormField` lors de la sélection d'un médecin pour un transfert/échange.
- Les menus utilisent désormais des identifiants stables (`phone` et `planningEntry.id`) au lieu d'instances d'objets recréées par les mises à jour Realtime.
- Si le médecin destinataire ne possède aucune garde échangeable, l'interface affiche simplement un message explicite et aucune demande d'échange n'est créée.
- Aucun patch SQL/Supabase supplémentaire n'est requis.
