# Migration vers GardeFlow 11.1.5

Si la base est déjà en V11.1.4, exécuter une seule fois dans **Supabase → SQL Editor** :

`supabase/patch_v11_1_5_exchange_scope_rules.sql`

Ce patch remplace uniquement la policy de création des demandes d’échange/transfert et la RPC `respond_shift_request`.

Aucune table n’est supprimée et les historiques existants sont conservés.

## Edge Function

Aucune mise à jour de `send-push` n’est nécessaire pour V11.1.5 : la V11.1.4 sait déjà distinguer un échange Service ↔ Service approuvé immédiatement d’une demande devant passer par l’admin.
