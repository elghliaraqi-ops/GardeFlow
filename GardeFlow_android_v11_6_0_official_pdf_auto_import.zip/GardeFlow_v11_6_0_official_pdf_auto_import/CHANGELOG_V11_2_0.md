# GardeFlow V11.2.0 — Splash & connexion institutionnels

Cette version ne modifie aucune règle métier, Supabase, échange, transfert, congé ou calendrier.

## Splash screen
- Nouvelle identité visuelle GardeFlow inspirée de la maquette validée.
- Logos institutionnels raffinés et intégrés :
  - Hôpital Universitaire International Mohammed VI Rabat ;
  - Hôpital Universitaire International Cheikh Khalifa ;
  - Hôpital Universitaire International Mohammed VI Bouskoura ;
  - AMIUM6.
- Photo des Urgences utilisée de façon très légère dans le bas de la composition.
- Animation d'entrée douce et transition en fondu vers l'application.

## Login / inscription
- Photo des Urgences en plein écran en arrière-plan.
- Flou progressif animé au chargement de la page (0 → 8,5 px environ en 1,25 s).
- Voile lumineux et carte de connexion glassmorphism.
- En-tête GardeFlow vert/rouge, sous-titre et signature visuelle.
- Champs téléphone/mot de passe raffinés et bouton de connexion vert en dégradé.
- Affichage/masquage du mot de passe.
- Lien "Mot de passe oublié ?" indiquant de contacter un administrateur, cohérent avec l'authentification actuelle sans SMS/e-mail de récupération.
- Bandeau des quatre logos institutionnels en bas de l'écran.
- Formulaire d'inscription conservé avec toutes ses fonctions, redessiné dans le même style.

## Assets
Les logos fournis ont été recadrés, nettoyés et légèrement renforcés pour une meilleure lisibilité dans l'application.
