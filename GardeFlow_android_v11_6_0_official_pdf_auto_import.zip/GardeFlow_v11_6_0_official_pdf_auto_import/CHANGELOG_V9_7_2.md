# HUIM6 Planning V9.7.2

- Les administrateurs sont désormais proposés comme destinataires des transferts et échanges.
- Un admin peut également initier un transfert/échange depuis ses propres gardes.
- La règle du même établissement reste obligatoire.
- Aucun changement SQL n'est nécessaire : les fonctions Supabase n'excluent pas le rôle admin des participants.
