# V9.8.2

- Correction des échanges de gardes sur deux dates différentes.
- Exemple supporté : Jour le 16 contre Nuit le 27.
- Lors de l’approbation, les médecins gardent leurs lignes de planning et les valeurs date + type de garde sont permutées.
- Les contrôles de conflit continuent d’interdire une deuxième affectation au même médecin le même jour.
- Le correctif SQL ignore explicitement les anciennes lignes archivées (`deleted_at`).
