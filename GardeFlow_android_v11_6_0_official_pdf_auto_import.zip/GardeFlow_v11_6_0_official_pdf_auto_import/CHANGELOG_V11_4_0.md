# V11.4.0 — Compatibilité iPhone / iOS

- Support iOS ajouté au service Firebase Messaging.
- Les tokens iPhone sont enregistrés dans Supabase avec `platform = ios`.
- Attente du token APNs avant l'enregistrement FCM pour fiabiliser le premier lancement.
- Notifications foreground/locales adaptées à iOS.
- Rappels locaux iOS conservés.
- La permission de notifications n'est plus demandée automatiquement au démarrage iOS.
- Générateur iOS automatique `tool/ios.sh` ajouté.
- Scripts `BUILD_IOS_UNSIGNED.sh` et `BUILD_IOS_IPA.sh` ajoutés.
- Bundle ID iOS prévu : `com.huim6.gardeflow`.
- iOS 13.0 minimum.
- Icônes iPhone/iPad générées à partir du nouveau logo GardeFlow.
- Permissions caméra/photothèque ajoutées pour la publication admin des astreintes.
- Background remote notifications préparé.
- Privacy manifest ajouté.
- Compatibilité maintenue avec Android et Web.

La réception de push sur iPhone nécessite l'application Firebase iOS (`GoogleService-Info.plist`) et une configuration APNs Apple/Firebase.
