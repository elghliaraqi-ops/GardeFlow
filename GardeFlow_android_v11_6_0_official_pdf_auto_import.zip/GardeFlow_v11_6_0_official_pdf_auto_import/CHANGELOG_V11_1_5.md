# GardeFlow 11.1.5+116

## Règles d’échange consolidées

Les échanges suivent désormais exactement ces règles :

- **Toujours le même hôpital** : aucun échange inter-hôpitaux.
- **Urgences ↔ Urgences** : possible entre tous les médecins actifs du même hôpital, quel que soit leur service ; après acceptation du destinataire, **validation ADMIN obligatoire**.
- **Service ↔ Service** : uniquement entre médecins du **même service** ; après acceptation du destinataire, l’échange est **appliqué immédiatement sans validation ADMIN**.
- **Échange mixte Service ↔ Urgences** : autorisé uniquement si les deux médecins sont du **même service**, et **validation ADMIN obligatoire** parce qu’une garde Urgences intervient.
- Les transferts ne changent pas dans cette version.

## Sécurité

Les mêmes règles sont contrôlées à la fois :

- dans l’interface Flutter ;
- dans `AppState` avant création/acceptation ;
- dans la policy RLS d’insertion Supabase ;
- dans la RPC `respond_shift_request` au moment de l’acceptation.

Ainsi, une requête client modifiée manuellement ne permet pas de contourner les règles de service ou d’hôpital.
