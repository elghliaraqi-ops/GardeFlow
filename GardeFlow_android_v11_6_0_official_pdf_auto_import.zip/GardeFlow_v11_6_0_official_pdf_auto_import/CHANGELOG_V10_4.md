# HUIM6 Planning V10.4

## Accueil du jour
- Nouvelle barre d’accueil en haut de l’écran avec « Bonjour Dr … » ou « Bonsoir Dr … » selon l’heure locale.
- Affichage de la date complète en français et de l’heure, actualisée automatiquement.
- Résumé de la journée avec iconographie et code couleur : garde de Jour, Nuit, 24H, aucune garde, congé ou congé en attente.
- Le résumé précise Service ou Urgences ainsi que l’horaire de la garde.
- Le badge ADMIN est affiché indépendamment du grade Junior/Senior.

## Navigation supérieure
- Les anciens ActionChip sont remplacés par de vraies cartes-boutons plus lisibles et plus tactiles.
- Icône colorée, titre et sous-titre pour Notifications, Annuaire, Astreinte, Réglages et Administration.
- Défilement horizontal sur petit écran pour éviter les boutons tassés ou les libellés tronqués.
- Badge de notifications plus visible.

## Backend
- Aucun changement Supabase.
- Aucun nouveau patch SQL.
- Aucune mise à jour de la Edge Function `send-push`.
