# HUIM6 Planning V10.1 — tuiles + validation mensuelle

Cette version revient au concept central de HUIM6 : **le médecin construit lui-même son planning mensuel en déposant des tuiles sur son propre calendrier**, puis envoie le mois complet à l'administration pour validation.

## Planning personnel

- Tuiles **SERVICE** : Jour / 24H / Nuit.
- Tuiles **URGENCES** : Jour / 24H / Nuit.
- Tuile **Congé** distincte avec son code couleur.
- Une seule tuile par médecin et par date.
- Le mois reste modifiable en état `draft` ou après un refus (`rejected`).
- Le bouton de validation envoie **tout le mois** à l'administration.
- Dès l'envoi, le calendrier est verrouillé (`submitted`).
- Après validation admin (`approved`), le planning devient officiel : rappels, transferts et échanges sont autorisés.
- En cas de refus, le motif est affiché au médecin et le mois redevient modifiable.

## Validation administrateur

- Nouvelle table `planning_months`.
- Vue et onglet **Calendriers** pour les mois à valider.
- Validation/refus du mois entier, avec motif obligatoire en cas de refus.
- Les brouillons d'un médecin ne sont pas visibles par les autres médecins : seul le médecin concerné et les admins les voient avant validation.
- Un admin peut toujours corriger un planning depuis la vue admin ; toute demande de transfert/échange active liée à une tuile corrigée est annulée pour éviter un état incohérent.

## Junior / Senior / Admin

- **Junior** et **Senior** sont uniquement des grades médicaux/informatifs.
- Aucun droit applicatif n'est accordé par le grade.
- Tous les droits administratifs dépendent exclusivement de `profiles.role = 'admin'`.
- Un médecin peut donc être **Junior + Admin** et disposer de tous les droits d'administration.
- `promote_admin.sql` ne modifie plus le grade médical.

## Notifications

- Ajout d'un bouton **Nettoyer** dans l'écran Notifications.
- Il retire localement les rappels déjà envoyés et masque les demandes/calendriers terminés.
- Les éléments encore à traiter restent visibles.
- Les données métier et l'historique Supabase ne sont pas supprimés.

## Supabase

Pour une base déjà migrée en V10, exécuter une seule fois :

`supabase/patch_v10_1_tiles_calendar_validation.sql`

Puis redéployer :

`supabase/functions/send-push/index.ts`

La fonction push gère aussi l'envoi d'un calendrier et sa validation/refus.
