# V5 — corrections consolidées

- Persistance locale de l'état complet + restauration de session.
- Hash salé des mots de passe ; hash admin pré-calculé dans le code.
- Établissement retiré du formulaire de connexion ; conservé à l'inscription.
- Photos d'astreinte persistantes, privées par compte, compressées et compatibles Web.
- Rappels filtrés/programmés par compte et persistants.
- Permissions notifications demandées au bon moment.
- Alarme Android inexacte : pas de dépendance à SCHEDULE_EXACT_ALARM.
- Script Windows de configuration CAMERA/POST_NOTIFICATIONS et Info.plist iOS.
- Splash autonome sans asset manquant.
- Échanges : anti-doublon, contrôle conflit destinataire, revalidation admin, annulation.
- Admin : garde la vue par médecin de V4 et dispose aussi de son planning personnel avec la palette de création de gardes.
- Corrections V2/V3/V4 conservées : plusieurs gardes par date, Dropdown annuaire admin, notifications par propriétaire.

## V7 — Vue admin calendrier par médecin
- Bouton « Astreinte » renommé en « Médecins Séniors de Garde / Astreinte ».
- Le titre de l'écran d'astreinte utilise le même libellé.
- La Vue Admin conserve d'abord le filtre par établissement.
- Ajout d'une seconde liste déroulante « Médecin », alimentée uniquement avec les comptes de l'établissement sélectionné.
- La liste des gardes est remplacée par un calendrier mensuel du médecin sélectionné.
- Les gardes Service, Urgences et Congé apparaissent directement dans les cases du calendrier avec le code couleur existant.
- Navigation mois précédent / suivant et bouton « Aujourd'hui ».
- Résumé du nombre d'affectations du médecin sur le mois et au total.
- L'administrateur reste sélectionnable dans « Tous les établissements » puisqu'il peut lui aussi avoir ses propres gardes.
