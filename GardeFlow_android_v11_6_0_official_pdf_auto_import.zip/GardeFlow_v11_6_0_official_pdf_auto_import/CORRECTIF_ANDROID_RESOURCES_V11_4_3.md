# Correctif Android V11.4.3

Cette version corrige le build Android lorsque AAPT signale simultanement des ressources introuvables :

- `@mipmap/ic_launcher`
- `@drawable/ic_stat_huim6`
- `@style/LaunchTheme`
- `@style/NormalTheme`
- `@integer/google_play_services_version`

Modifications :

1. Les themes `LaunchTheme` et `NormalTheme` ainsi que `launch_background.xml` sont conserves dans `tool/android-res` et restaures apres chaque regeneration Android.
2. Le script verifie explicitement les ressources essentielles avant de lancer Gradle.
3. Le cache Gradle local du projet est nettoye avant compilation.
4. En cas d echec du premier build APK, un seul retry automatique est effectue apres arret des daemons Gradle et purge des caches de transformation AAR Gradle, puis `flutter clean` / `flutter pub get`.
5. Aucune modification fonctionnelle de GardeFlow, Supabase, galerie photo ou visionneuse PDF.
