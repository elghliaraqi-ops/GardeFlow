# GardeFlow V11.4.2

- Affichage raccourci des établissements : HUIM6 de Bouskoura, HUIM6 de Rabat, HUICK de Casa.
- Les valeurs historiques d'établissement restent inchangées en interne pour préserver la compatibilité avec les comptes Supabase existants.
- Galerie d'astreinte plein écran avec balayage horizontal entre les photos, zoom tactile et compteur de position.
- Ajout de `photo_view 0.15.0` pour la navigation et le zoom de galerie.
