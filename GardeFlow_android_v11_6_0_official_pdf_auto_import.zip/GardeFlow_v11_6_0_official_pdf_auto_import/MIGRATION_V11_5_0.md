# Migration GardeFlow V11.5.0

## 1. Supabase

Dans **Supabase > SQL Editor**, exécuter une seule fois :

`supabase/patch_v11_5_0_junior_oncall_roster.sql`

Ce patch crée le RPC `junior_oncall_roster` utilisé par le nouveau bouton **Juniors d’astreinte**.
Il renvoie uniquement :
- les médecins dont le grade est `junior` ;
- les gardes `service-jour`, `service-24h` ou `service-nuit` ;
- les mois déjà validés ;
- le nom, le service et l’établissement nécessaires à cette page.

Les brouillons, congés et gardes Urgences ne sont pas exposés par cette fonction.

## 2. Application

Compiler normalement avec `BUILD_APK_RELEASE.ps1`.
