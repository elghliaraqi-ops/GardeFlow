# Correctif pdfrx — V11.4.1

Le paquet `pdfrx` a été mis à jour de `1.3.5` vers `2.4.8`.

Motif : `pdfrx 1.3.5` échoue avec les versions récentes de Dart/Flutter dans `pdf_file_cache.dart` sur des accès à un cache nullable (`cache.blockSize`, `cache.read`, etc.).

Après extraction du projet :

```powershell
flutter clean
Remove-Item -Recurse -Force .dart_tool -ErrorAction SilentlyContinue
flutter pub get
powershell -ExecutionPolicy Bypass -File .\BUILD_APK_RELEASE.ps1
```

APK attendu :

`build\app\outputs\flutter-apk\app-release.apk`
