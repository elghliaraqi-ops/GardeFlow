# GardeFlow V11.1.6

- Un administrateur peut désormais dévalider **son propre calendrier** depuis la Vue Admin, comme celui des autres médecins.
- Après dévalidation, son mois repasse en brouillon et il retrouve l’édition normale par tuiles dans **Mon planning**.
- Le motif reste obligatoire et l’action reste tracée dans le journal d’audit.
- Les mois passés restent verrouillés.
- Les demandes de transfert/échange actives du mois sont annulées lors de la réouverture.
- Les congés en attente sont annulés puis recréés à la prochaine validation ; les congés déjà approuvés restent protégés et peuvent être supprimés par l’action admin dédiée.
- Aucun changement sur les règles d’échange V11.1.5.
- Aucun changement de Firebase/FCM/Edge Function.
