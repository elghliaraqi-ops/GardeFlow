# GardeFlow 11.1.4+115

## Règle métier — échanges Service

- Un **échange** dont les deux gardes sont des gardes **Service** (`service-jour`, `service-nuit`, `service-24h`) n’attend plus l’approbation ADMIN.
- Le destinataire accepte : l’échange est appliqué immédiatement et passe à `approved`.
- Les **transferts** restent soumis à validation ADMIN.
- Tout échange qui implique au moins une garde **Urgences** reste soumis à validation ADMIN.
- Les contrôles existants restent inchangés : même établissement, calendriers validés, gardes non commencées, absence de conflit de date.
- L’historique d’audit est conservé.

## Vue Admin

- Calendrier médecin agrandi et moins condensé.
- Sur Android portrait, le calendrier garde sept vraies colonnes avec une largeur minimale lisible et un défilement horizontal local.
- Les en-têtes Lun → Dim défilent avec le calendrier et restent alignés.
- Tuiles, icônes, libellés et numéros de jour agrandis.
- Sur tablette / web, le calendrier exploite davantage la largeur disponible.

## Supabase

Exécuter `supabase/patch_v11_1_4_service_exchange_no_admin.sql`, puis redéployer la fonction Edge `send-push` avec le fichier `supabase/functions/send-push/index.ts` de cette version.
