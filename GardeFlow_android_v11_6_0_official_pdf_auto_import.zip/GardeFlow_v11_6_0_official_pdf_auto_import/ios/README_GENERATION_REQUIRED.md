# iOS

Le projet Xcode complet est généré sur macOS avec le Flutter réellement installé sur le Mac afin d'éviter les incompatibilités de template/Xcode.

À la racine du projet :

```bash
./tool/ios.sh Prepare
```

Ce script remplace ce dossier par le projet iOS Flutter complet et applique automatiquement les réglages GardeFlow.

Voir `../IOS_SETUP.md`.
