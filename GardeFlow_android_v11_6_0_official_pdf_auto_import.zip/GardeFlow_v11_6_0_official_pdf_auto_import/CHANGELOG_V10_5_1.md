# V10.5.1 — correctif boucle de layout

- Corrige le `RenderBox ... has never been laid out` de l'écran principal.
- Supprime le `CrossAxisAlignment.stretch` utilisé dans un contexte de hauteur non bornée.
- La barre d'actions reste sur une seule ligne sur desktop afin de préserver la hauteur du calendrier.
- Sur petite largeur, la barre d'actions défile horizontalement sans créer de scroll vertical de la page.
- Sécurise le calcul du ratio de la grille quand la hauteur disponible devient très faible.
- Aucun changement Supabase / Edge Function.
