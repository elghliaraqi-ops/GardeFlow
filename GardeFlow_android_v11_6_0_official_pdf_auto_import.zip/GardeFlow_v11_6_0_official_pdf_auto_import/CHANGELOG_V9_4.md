# HUIM6 Planning V9.4

- URL Supabase intégrée comme configuration par défaut.
- Publishable key Supabase intégrée comme configuration par défaut.
- `flutter run -d chrome` suffit désormais pour se connecter au backend HUIM6.
- Les `--dart-define=SUPABASE_URL=...` et `--dart-define=SUPABASE_PUBLISHABLE_KEY=...` restent disponibles pour remplacer temporairement la configuration (test / staging / autre projet).
- Aucune clé `service_role` ou secrète n'est embarquée.
- Authentification visible inchangée : numéro de téléphone + mot de passe, sans OTP/SMS.
