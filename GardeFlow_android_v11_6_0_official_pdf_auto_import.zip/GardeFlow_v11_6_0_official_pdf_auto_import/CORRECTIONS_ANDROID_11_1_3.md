# GardeFlow 11.1.3+114 — calendrier et saisie Android

- Mois complet sur une ligne dédiée entre les flèches ; statut et validation
  déplacés dessous, pour ne plus tronquer « Septembre » en « Se… ».
- Accueil défilant quand la hauteur disponible est insuffisante, plutôt que
  d'écraser la grille.
- Page administrateur entièrement défilante : filtres, médecin, statut et toutes
  les semaines du mois sont accessibles avec un seul défilement vertical.
- Navigation mensuelle administrateur sur une ligne dédiée.
- Action Dévalider sous le texte de statut pour les écrans étroits.
- Fenêtres de motif communes à la dévalidation et à la suppression : contenu
  défilant avec le clavier, validation visible (au moins 3 caractères).
- Contrôleur du champ géré par le State de la fenêtre et libéré au démontage
  effectif ; suppression de la libération anticipée après showDialog.
- Protection contre les doubles ouvertures et capture du mois avant la saisie.
- Toucher une case administrateur supprimable ouvre sa confirmation ; l'icône
  de suppression ne recouvre plus le numéro du jour.

## Vérification sur le poste Flutter

```powershell
flutter pub get
flutter test test/mobile_layout_test.dart
powershell -ExecutionPolicy Bypass -File .\tool\android.ps1 -Action Apk
```

Installer l'APK sur le même appareil, avec la même clé de signature, par-dessus
l'ancienne version. La version Web utilise les mêmes correctifs Dart :
`flutter build web --release`, puis redéployer build/web.

Tests de widgets ajoutés pour une largeur de 320 px, du texte agrandi, les deux
fenêtres avec clavier simulé, la saisie, la confirmation et la réouverture.
Ils n'ont pas pu être exécutés ici : ni Flutter ni Dart ne sont installés.
La compilation et la reproduction de l'erreur rouge sur appareil restent à
vérifier. La capture montre une assertion Flutter `_dependents.isEmpty` ; elle
ne fournit pas la première exception complète. Le correctif traite le cycle de
vie risqué du champ, mais ne permet pas à lui seul de certifier cette cause.

À vérifier sur téléphone : parcourir jusqu'au dernier jour d'un mois de six
semaines ; dévalider avec un motif long et clavier ouvert ; recommencer en
annulant ; supprimer une affectation avec motif puis annuler une autre demande.
Aucune migration SQL ni modification des règles de validation n'est nécessaire.
